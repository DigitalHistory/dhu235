var networks = {"les mis": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.7.1",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "les mis",
    "name" : "les mis",
    "SUID" : 81749,
    "__Annotations" : [ ],
    "selected" : false
  },
  "elements" : {
    "nodes" : [ ],
    "edges" : [ ]
  }
},"lesmis.txt": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.7.1",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "lesmis.txt",
    "name" : "lesmis.txt",
    "SUID" : 80919,
    "__Annotations" : [ ],
    "selected" : false
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "81255",
        "shared_name" : "MademoiselleVaubois",
        "name" : "MademoiselleVaubois",
        "SUID" : 81255,
        "selected" : false
      },
      "position" : {
        "x" : 261.9346096076015,
        "y" : -26.22205364188565
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81249",
        "shared_name" : "MadameDeR",
        "name" : "MadameDeR",
        "SUID" : 81249,
        "selected" : false
      },
      "position" : {
        "x" : 177.6973354376796,
        "y" : 108.33916843453036
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81247",
        "shared_name" : "JacquinLabarre",
        "name" : "JacquinLabarre",
        "SUID" : 81247,
        "selected" : false
      },
      "position" : {
        "x" : 178.10532493963274,
        "y" : 169.65401065865146
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81216",
        "shared_name" : "Boulatruelle",
        "name" : "Boulatruelle",
        "SUID" : 81216,
        "selected" : false
      },
      "position" : {
        "x" : 154.6252834357265,
        "y" : 7.266290550619232
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81208",
        "shared_name" : "SisterPerpetue",
        "name" : "SisterPerpetue",
        "SUID" : 81208,
        "selected" : false
      },
      "position" : {
        "x" : -262.14638404474226,
        "y" : 124.96308506050693
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81204",
        "shared_name" : "Cravatte",
        "name" : "Cravatte",
        "SUID" : 81204,
        "selected" : false
      },
      "position" : {
        "x" : -83.8443668328282,
        "y" : 497.66122806587805
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81195",
        "shared_name" : "Gribier",
        "name" : "Gribier",
        "SUID" : 81195,
        "selected" : false
      },
      "position" : {
        "x" : 206.94887657537492,
        "y" : 278.94150150337805
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81189",
        "shared_name" : "Magnon",
        "name" : "Magnon",
        "SUID" : 81189,
        "selected" : false
      },
      "position" : {
        "x" : -207.76312903985945,
        "y" : -145.93896114310635
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81172",
        "shared_name" : "Champtercier",
        "name" : "Champtercier",
        "SUID" : 81172,
        "selected" : false
      },
      "position" : {
        "x" : 105.38688011541399,
        "y" : 497.2200354389249
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81166",
        "shared_name" : "Monsieur Geborand",
        "name" : "Monsieur Geborand",
        "SUID" : 81166,
        "selected" : false
      },
      "position" : {
        "x" : -45.94651298150984,
        "y" : 551.2327917865812
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81161",
        "shared_name" : "Jondrette",
        "name" : "Jondrette",
        "SUID" : 81161,
        "selected" : false
      },
      "position" : {
        "x" : 301.62961693182024,
        "y" : -407.5291405864657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81152",
        "shared_name" : "Woman1",
        "name" : "Woman1",
        "SUID" : 81152,
        "selected" : false
      },
      "position" : {
        "x" : 110.17080803289446,
        "y" : 116.04135501900302
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81143",
        "shared_name" : "MadamePontmercy",
        "name" : "MadamePontmercy",
        "SUID" : 81143,
        "selected" : false
      },
      "position" : {
        "x" : 229.4679653204921,
        "y" : 24.36453903236972
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81141",
        "shared_name" : "BaptistineMyrie",
        "name" : "BaptistineMyrie",
        "SUID" : 81141,
        "selected" : false
      },
      "position" : {
        "x" : -28.7263248406407,
        "y" : 290.3680762104093
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81138",
        "shared_name" : "Woman2",
        "name" : "Woman2",
        "SUID" : 81138,
        "selected" : false
      },
      "position" : {
        "x" : 84.94875450506242,
        "y" : 66.12136066475497
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81127",
        "shared_name" : "Child1",
        "name" : "Child1",
        "SUID" : 81127,
        "selected" : false
      },
      "position" : {
        "x" : 269.391518787289,
        "y" : -119.14736568412198
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81120",
        "shared_name" : "MadameMagloire",
        "name" : "MadameMagloire",
        "SUID" : 81120,
        "selected" : false
      },
      "position" : {
        "x" : 48.01997108831438,
        "y" : 276.8893164447843
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81106",
        "shared_name" : "Napoleon",
        "name" : "Napoleon",
        "SUID" : 81106,
        "selected" : false
      },
      "position" : {
        "x" : 135.3978206671718,
        "y" : 444.4147375873624
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81104",
        "shared_name" : "CountessDeLo",
        "name" : "CountessDeLo",
        "SUID" : 81104,
        "selected" : false
      },
      "position" : {
        "x" : 68.79684181585344,
        "y" : 549.6361731342374
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81098",
        "shared_name" : "Anzelma",
        "name" : "Anzelma",
        "SUID" : 81098,
        "selected" : false
      },
      "position" : {
        "x" : -145.70859412775008,
        "y" : -126.80805599173917
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81095",
        "shared_name" : "MotherPlutarch",
        "name" : "MotherPlutarch",
        "SUID" : 81095,
        "selected" : false
      },
      "position" : {
        "x" : -80.0217349968907,
        "y" : -368.7342492290438
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81085",
        "shared_name" : "BaronessDeThenard",
        "name" : "BaronessDeThenard",
        "SUID" : 81085,
        "selected" : false
      },
      "position" : {
        "x" : -120.48570899591414,
        "y" : -203.30268489798917
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81074",
        "shared_name" : "MotherInnocent",
        "name" : "MotherInnocent",
        "SUID" : 81074,
        "selected" : false
      },
      "position" : {
        "x" : 99.84816856756242,
        "y" : 253.48076236763583
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81070",
        "shared_name" : "Favourite",
        "name" : "Favourite",
        "SUID" : 81070,
        "selected" : false
      },
      "position" : {
        "x" : -362.5194614373204,
        "y" : -21.25127422294034
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81061",
        "shared_name" : "MadameThenardier",
        "name" : "MadameThenardier",
        "SUID" : 81061,
        "selected" : false
      },
      "position" : {
        "x" : -118.45838813409773,
        "y" : -29.657447928995026
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81052",
        "shared_name" : "Chenildieu",
        "name" : "Chenildieu",
        "SUID" : 81052,
        "selected" : false
      },
      "position" : {
        "x" : -64.1705387078282,
        "y" : 246.34048831978427
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81045",
        "shared_name" : "Champmathieu",
        "name" : "Champmathieu",
        "SUID" : 81045,
        "selected" : false
      },
      "position" : {
        "x" : -5.11757354364363,
        "y" : 216.1193274311124
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81043",
        "shared_name" : "Enjolras",
        "name" : "Enjolras",
        "SUID" : 81043,
        "selected" : false
      },
      "position" : {
        "x" : 57.50508613958391,
        "y" : -116.56991207084073
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81041",
        "shared_name" : "Eponine",
        "name" : "Eponine",
        "SUID" : 81041,
        "selected" : false
      },
      "position" : {
        "x" : -64.06383399591414,
        "y" : -135.83315669974698
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81031",
        "shared_name" : "Cochepaille",
        "name" : "Cochepaille",
        "SUID" : 81031,
        "selected" : false
      },
      "position" : {
        "x" : -134.78177528009383,
        "y" : 227.28801334419833
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81027",
        "shared_name" : "MadameBurgon",
        "name" : "MadameBurgon",
        "SUID" : 81027,
        "selected" : false
      },
      "position" : {
        "x" : 233.0424282111171,
        "y" : -290.9605065532626
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81025",
        "shared_name" : "LieutenantTheoduleGillenormand",
        "name" : "LieutenantTheoduleGillenormand",
        "SUID" : 81025,
        "selected" : false
      },
      "position" : {
        "x" : 21.663047031307542,
        "y" : -58.92030727347745
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81023",
        "shared_name" : "MademoiselleGillenormand",
        "name" : "MademoiselleGillenormand",
        "SUID" : 81023,
        "selected" : false
      },
      "position" : {
        "x" : 91.85485954656633,
        "y" : -3.53231155356778
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81021",
        "shared_name" : "Gervais",
        "name" : "Gervais",
        "SUID" : 81021,
        "selected" : false
      },
      "position" : {
        "x" : -179.0861423455235,
        "y" : 96.97252262154208
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81018",
        "shared_name" : "Fauchelevent",
        "name" : "Fauchelevent",
        "SUID" : 81018,
        "selected" : false
      },
      "position" : {
        "x" : 86.0064632452968,
        "y" : 164.89514530220615
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81015",
        "shared_name" : "MaubertIsabeau",
        "name" : "MaubertIsabeau",
        "SUID" : 81015,
        "selected" : false
      },
      "position" : {
        "x" : 129.83525963201555,
        "y" : 202.43309391060458
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81013",
        "shared_name" : "Marguerite",
        "name" : "Marguerite",
        "SUID" : 81013,
        "selected" : false
      },
      "position" : {
        "x" : -179.888266368961,
        "y" : 147.24655521431552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81008",
        "shared_name" : "SisterSimplice",
        "name" : "SisterSimplice",
        "SUID" : 81008,
        "selected" : false
      },
      "position" : {
        "x" : -124.49326209650008,
        "y" : 76.66149509468661
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81003",
        "shared_name" : "Child2",
        "name" : "Child2",
        "SUID" : 81003,
        "selected" : false
      },
      "position" : {
        "x" : 264.4816829718593,
        "y" : -209.10328304252042
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81001",
        "shared_name" : "LAigleDeMeauxBossuet ",
        "name" : "LAigleDeMeauxBossuet ",
        "SUID" : 81001,
        "selected" : false
      },
      "position" : {
        "x" : 57.514855579281175,
        "y" : -158.1277886577548
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80998",
        "shared_name" : "Fameuil",
        "name" : "Fameuil",
        "SUID" : 80998,
        "selected" : false
      },
      "position" : {
        "x" : -276.3222263298985,
        "y" : -91.97511684378995
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80995",
        "shared_name" : "Toussaint",
        "name" : "Toussaint",
        "SUID" : 80995,
        "selected" : false
      },
      "position" : {
        "x" : 13.227597907924974,
        "y" : 154.30578983345615
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80993",
        "shared_name" : "Babet",
        "name" : "Babet",
        "SUID" : 80993,
        "selected" : false
      },
      "position" : {
        "x" : 34.12473030462297,
        "y" : -19.74123775443448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80992",
        "shared_name" : "Brujon",
        "name" : "Brujon",
        "SUID" : 80992,
        "selected" : false
      },
      "position" : {
        "x" : 0.8867132224086163,
        "y" : -152.04381954154385
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80990",
        "shared_name" : "OldMan",
        "name" : "OldMan",
        "SUID" : 80990,
        "selected" : false
      },
      "position" : {
        "x" : -123.92983131036726,
        "y" : 439.11313236275305
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80988",
        "shared_name" : "FelixTholomyes",
        "name" : "FelixTholomyes",
        "SUID" : 80988,
        "selected" : false
      },
      "position" : {
        "x" : -204.22634009942976,
        "y" : -50.265533561319245
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80984",
        "shared_name" : "Gueulemer",
        "name" : "Gueulemer",
        "SUID" : 80984,
        "selected" : false
      },
      "position" : {
        "x" : -23.692065044498122,
        "y" : -83.13357936820401
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80981",
        "shared_name" : "Mabeuf",
        "name" : "Mabeuf",
        "SUID" : 80981,
        "selected" : false
      },
      "position" : {
        "x" : -24.29605369195906,
        "y" : -232.51708614310635
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80979",
        "shared_name" : "JeanProuvaire",
        "name" : "JeanProuvaire",
        "SUID" : 80979,
        "selected" : false
      },
      "position" : {
        "x" : 166.35535545721086,
        "y" : -229.18696224173917
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80977",
        "shared_name" : "Bahorel",
        "name" : "Bahorel",
        "SUID" : 80977,
        "selected" : false
      },
      "position" : {
        "x" : 76.73396416082414,
        "y" : -269.67239009818445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80975",
        "shared_name" : "Combeferre",
        "name" : "Combeferre",
        "SUID" : 80975,
        "selected" : false
      },
      "position" : {
        "x" : 123.5649578131679,
        "y" : -183.53590023002042
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80973",
        "shared_name" : "Thenardier",
        "name" : "Thenardier",
        "SUID" : 80973,
        "selected" : false
      },
      "position" : {
        "x" : -11.280796810245192,
        "y" : -33.28549587211026
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80972",
        "shared_name" : "Pontmercy",
        "name" : "Pontmercy",
        "SUID" : 80972,
        "selected" : false
      },
      "position" : {
        "x" : 140.52987022771867,
        "y" : -63.76932155570401
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80970",
        "shared_name" : "Grantaire",
        "name" : "Grantaire",
        "SUID" : 80970,
        "selected" : false
      },
      "position" : {
        "x" : 133.4569255866054,
        "y" : -277.0064355083407
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80967",
        "shared_name" : "Claquesous",
        "name" : "Claquesous",
        "SUID" : 80967,
        "selected" : false
      },
      "position" : {
        "x" : -57.80780677423445,
        "y" : -23.824318046182526
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80966",
        "shared_name" : "Montparnasse",
        "name" : "Montparnasse",
        "SUID" : 80966,
        "selected" : false
      },
      "position" : {
        "x" : 65.72879906072649,
        "y" : -60.1248360820712
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80963",
        "shared_name" : "Scaufflaire",
        "name" : "Scaufflaire",
        "SUID" : 80963,
        "selected" : false
      },
      "position" : {
        "x" : -108.6552570305821,
        "y" : 270.1649206928312
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80961",
        "shared_name" : "Blacheville",
        "name" : "Blacheville",
        "SUID" : 80961,
        "selected" : false
      },
      "position" : {
        "x" : -338.70812110528914,
        "y" : -79.94602596244229
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80958",
        "shared_name" : "Cosette",
        "name" : "Cosette",
        "SUID" : 80958,
        "selected" : false
      },
      "position" : {
        "x" : -57.84686164483992,
        "y" : 30.64341152229892
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80957",
        "shared_name" : "Marius",
        "name" : "Marius",
        "SUID" : 80957,
        "selected" : false
      },
      "position" : {
        "x" : -4.702258869266188,
        "y" : -116.53995906791104
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80955",
        "shared_name" : "Fantine",
        "name" : "Fantine",
        "SUID" : 80955,
        "selected" : false
      },
      "position" : {
        "x" : -190.95690040216414,
        "y" : 23.30374229469882
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80953",
        "shared_name" : "Dahlia",
        "name" : "Dahlia",
        "SUID" : 80953,
        "selected" : false
      },
      "position" : {
        "x" : -284.98229102716414,
        "y" : -30.123024100870026
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80951",
        "shared_name" : "BishopCharles-Francois-BienvenuMyriel",
        "name" : "BishopCharles-Francois-BienvenuMyriel",
        "SUID" : 80951,
        "selected" : false
      },
      "position" : {
        "x" : 8.78170247449907,
        "y" : 399.0539892963468
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80950",
        "shared_name" : "Count",
        "name" : "Count",
        "SUID" : 80950,
        "selected" : false
      },
      "position" : {
        "x" : 11.2340445078853,
        "y" : 528.1589392475187
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80948",
        "shared_name" : "Javert",
        "name" : "Javert",
        "SUID" : 80948,
        "selected" : false
      },
      "position" : {
        "x" : 5.522417739773118,
        "y" : 32.64796054878818
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80946",
        "shared_name" : "Courfeyrac",
        "name" : "Courfeyrac",
        "SUID" : 80946,
        "selected" : false
      },
      "position" : {
        "x" : 31.575753406429612,
        "y" : -209.48397457084073
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80945",
        "shared_name" : "MadameHucheloup",
        "name" : "MadameHucheloup",
        "SUID" : 80945,
        "selected" : false
      },
      "position" : {
        "x" : 173.20879478826555,
        "y" : -181.26102840384854
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80943",
        "shared_name" : "Gavroche",
        "name" : "Gavroche",
        "SUID" : 80943,
        "selected" : false
      },
      "position" : {
        "x" : 109.41187401189836,
        "y" : -125.85978328666104
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80941",
        "shared_name" : "Bamatabois",
        "name" : "Bamatabois",
        "SUID" : 80941,
        "selected" : false
      },
      "position" : {
        "x" : -87.58170203790633,
        "y" : 116.9004324726163
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80939",
        "shared_name" : "Judge",
        "name" : "Judge",
        "SUID" : 80939,
        "selected" : false
      },
      "position" : {
        "x" : -53.65138892755476,
        "y" : 176.24197757759677
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80938",
        "shared_name" : "Brevet",
        "name" : "Brevet",
        "SUID" : 80938,
        "selected" : false
      },
      "position" : {
        "x" : -129.82408790216414,
        "y" : 171.7416418842374
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80936",
        "shared_name" : "Feuilly",
        "name" : "Feuilly",
        "SUID" : 80936,
        "selected" : false
      },
      "position" : {
        "x" : 29.927020267391526,
        "y" : -264.03628169974695
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80935",
        "shared_name" : "Joly",
        "name" : "Joly",
        "SUID" : 80935,
        "selected" : false
      },
      "position" : {
        "x" : 81.40666313543352,
        "y" : -218.9414635845126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80933",
        "shared_name" : "Listolier",
        "name" : "Listolier",
        "SUID" : 80933,
        "selected" : false
      },
      "position" : {
        "x" : -281.55773048028914,
        "y" : 34.06445491829501
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80932",
        "shared_name" : "Zephine",
        "name" : "Zephine",
        "SUID" : 80932,
        "selected" : false
      },
      "position" : {
        "x" : -339.7418735466954,
        "y" : 35.70956790962802
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80930",
        "shared_name" : "JeanValjean",
        "name" : "JeanValjean",
        "SUID" : 80930,
        "selected" : false
      },
      "position" : {
        "x" : -5.499981685733474,
        "y" : 92.92405307808505
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80929",
        "shared_name" : "Gillenormand",
        "name" : "Gillenormand",
        "SUID" : 80929,
        "selected" : false
      },
      "position" : {
        "x" : -84.54015235528914,
        "y" : -70.5694161601962
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "81256",
        "source" : "81255",
        "target" : "81023",
        "shared_name" : "MademoiselleVaubois (interacts with) MademoiselleGillenormand",
        "shared_interaction" : "interacts with",
        "name" : "MademoiselleVaubois (interacts with) MademoiselleGillenormand",
        "interaction" : "interacts with",
        "SUID" : 81256,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81250",
        "source" : "81249",
        "target" : "80930",
        "shared_name" : "MadameDeR (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "MadameDeR (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81250,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81217",
        "source" : "81216",
        "target" : "80973",
        "shared_name" : "Boulatruelle (interacts with) Thenardier",
        "shared_interaction" : "interacts with",
        "name" : "Boulatruelle (interacts with) Thenardier",
        "interaction" : "interacts with",
        "SUID" : 81217,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81209",
        "source" : "81208",
        "target" : "80955",
        "shared_name" : "SisterPerpetue (interacts with) Fantine",
        "shared_interaction" : "interacts with",
        "name" : "SisterPerpetue (interacts with) Fantine",
        "interaction" : "interacts with",
        "SUID" : 81209,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81205",
        "source" : "81204",
        "target" : "80951",
        "shared_name" : "Cravatte (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "shared_interaction" : "interacts with",
        "name" : "Cravatte (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "interaction" : "interacts with",
        "SUID" : 81205,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81196",
        "source" : "81195",
        "target" : "81018",
        "shared_name" : "Gribier (interacts with) Fauchelevent",
        "shared_interaction" : "interacts with",
        "name" : "Gribier (interacts with) Fauchelevent",
        "interaction" : "interacts with",
        "SUID" : 81196,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81227",
        "source" : "81189",
        "target" : "80929",
        "shared_name" : "Magnon (interacts with) Gillenormand",
        "shared_interaction" : "interacts with",
        "name" : "Magnon (interacts with) Gillenormand",
        "interaction" : "interacts with",
        "SUID" : 81227,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81190",
        "source" : "81189",
        "target" : "81061",
        "shared_name" : "Magnon (interacts with) MadameThenardier",
        "shared_interaction" : "interacts with",
        "name" : "Magnon (interacts with) MadameThenardier",
        "interaction" : "interacts with",
        "SUID" : 81190,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81173",
        "source" : "81172",
        "target" : "80951",
        "shared_name" : "Champtercier (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "shared_interaction" : "interacts with",
        "name" : "Champtercier (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "interaction" : "interacts with",
        "SUID" : 81173,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81167",
        "source" : "81166",
        "target" : "80951",
        "shared_name" : "Monsieur Geborand (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "shared_interaction" : "interacts with",
        "name" : "Monsieur Geborand (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "interaction" : "interacts with",
        "SUID" : 81167,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81239",
        "source" : "81152",
        "target" : "80948",
        "shared_name" : "Woman1 (interacts with) Javert",
        "shared_interaction" : "interacts with",
        "name" : "Woman1 (interacts with) Javert",
        "interaction" : "interacts with",
        "SUID" : 81239,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81153",
        "source" : "81152",
        "target" : "80930",
        "shared_name" : "Woman1 (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Woman1 (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81153,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81160",
        "source" : "81143",
        "target" : "80972",
        "shared_name" : "MadamePontmercy (interacts with) Pontmercy",
        "shared_interaction" : "interacts with",
        "name" : "MadamePontmercy (interacts with) Pontmercy",
        "interaction" : "interacts with",
        "SUID" : 81160,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81144",
        "source" : "81143",
        "target" : "81023",
        "shared_name" : "MadamePontmercy (interacts with) MademoiselleGillenormand",
        "shared_interaction" : "interacts with",
        "name" : "MadamePontmercy (interacts with) MademoiselleGillenormand",
        "interaction" : "interacts with",
        "SUID" : 81144,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81171",
        "source" : "81141",
        "target" : "80951",
        "shared_name" : "BaptistineMyrie (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "shared_interaction" : "interacts with",
        "name" : "BaptistineMyrie (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "interaction" : "interacts with",
        "SUID" : 81171,
        "Strength" : 8,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81235",
        "source" : "81138",
        "target" : "80948",
        "shared_name" : "Woman2 (interacts with) Javert",
        "shared_interaction" : "interacts with",
        "name" : "Woman2 (interacts with) Javert",
        "interaction" : "interacts with",
        "SUID" : 81235,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81146",
        "source" : "81138",
        "target" : "80930",
        "shared_name" : "Woman2 (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Woman2 (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81146,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81139",
        "source" : "81138",
        "target" : "80958",
        "shared_name" : "Woman2 (interacts with) Cosette",
        "shared_interaction" : "interacts with",
        "name" : "Woman2 (interacts with) Cosette",
        "interaction" : "interacts with",
        "SUID" : 81139,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81128",
        "source" : "81127",
        "target" : "80943",
        "shared_name" : "Child1 (interacts with) Gavroche",
        "shared_interaction" : "interacts with",
        "name" : "Child1 (interacts with) Gavroche",
        "interaction" : "interacts with",
        "SUID" : 81128,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81237",
        "source" : "81120",
        "target" : "80951",
        "shared_name" : "MadameMagloire (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "shared_interaction" : "interacts with",
        "name" : "MadameMagloire (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "interaction" : "interacts with",
        "SUID" : 81237,
        "Strength" : 10,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81234",
        "source" : "81120",
        "target" : "81141",
        "shared_name" : "MadameMagloire (interacts with) BaptistineMyrie",
        "shared_interaction" : "interacts with",
        "name" : "MadameMagloire (interacts with) BaptistineMyrie",
        "interaction" : "interacts with",
        "SUID" : 81234,
        "Strength" : 6,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81107",
        "source" : "81106",
        "target" : "80951",
        "shared_name" : "Napoleon (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "shared_interaction" : "interacts with",
        "name" : "Napoleon (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "interaction" : "interacts with",
        "SUID" : 81107,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81105",
        "source" : "81104",
        "target" : "80951",
        "shared_name" : "CountessDeLo (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "shared_interaction" : "interacts with",
        "name" : "CountessDeLo (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "interaction" : "interacts with",
        "SUID" : 81105,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81257",
        "source" : "81098",
        "target" : "81061",
        "shared_name" : "Anzelma (interacts with) MadameThenardier",
        "shared_interaction" : "interacts with",
        "name" : "Anzelma (interacts with) MadameThenardier",
        "interaction" : "interacts with",
        "SUID" : 81257,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81198",
        "source" : "81098",
        "target" : "81041",
        "shared_name" : "Anzelma (interacts with) Eponine",
        "shared_interaction" : "interacts with",
        "name" : "Anzelma (interacts with) Eponine",
        "interaction" : "interacts with",
        "SUID" : 81198,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81099",
        "source" : "81098",
        "target" : "80973",
        "shared_name" : "Anzelma (interacts with) Thenardier",
        "shared_interaction" : "interacts with",
        "name" : "Anzelma (interacts with) Thenardier",
        "interaction" : "interacts with",
        "SUID" : 81099,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81096",
        "source" : "81095",
        "target" : "80981",
        "shared_name" : "MotherPlutarch (interacts with) Mabeuf",
        "shared_interaction" : "interacts with",
        "name" : "MotherPlutarch (interacts with) Mabeuf",
        "interaction" : "interacts with",
        "SUID" : 81096,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81117",
        "source" : "81085",
        "target" : "80929",
        "shared_name" : "BaronessDeThenard (interacts with) Gillenormand",
        "shared_interaction" : "interacts with",
        "name" : "BaronessDeThenard (interacts with) Gillenormand",
        "interaction" : "interacts with",
        "SUID" : 81117,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81086",
        "source" : "81085",
        "target" : "80957",
        "shared_name" : "BaronessDeThenard (interacts with) Marius",
        "shared_interaction" : "interacts with",
        "name" : "BaronessDeThenard (interacts with) Marius",
        "interaction" : "interacts with",
        "SUID" : 81086,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81192",
        "source" : "81074",
        "target" : "81018",
        "shared_name" : "MotherInnocent (interacts with) Fauchelevent",
        "shared_interaction" : "interacts with",
        "name" : "MotherInnocent (interacts with) Fauchelevent",
        "interaction" : "interacts with",
        "SUID" : 81192,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81075",
        "source" : "81074",
        "target" : "80930",
        "shared_name" : "MotherInnocent (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "MotherInnocent (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81075,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81224",
        "source" : "81070",
        "target" : "80988",
        "shared_name" : "Favourite (interacts with) FelixTholomyes",
        "shared_interaction" : "interacts with",
        "name" : "Favourite (interacts with) FelixTholomyes",
        "interaction" : "interacts with",
        "SUID" : 81224,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81149",
        "source" : "81070",
        "target" : "80933",
        "shared_name" : "Favourite (interacts with) Listolier",
        "shared_interaction" : "interacts with",
        "name" : "Favourite (interacts with) Listolier",
        "interaction" : "interacts with",
        "SUID" : 81149,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81115",
        "source" : "81070",
        "target" : "80998",
        "shared_name" : "Favourite (interacts with) Fameuil",
        "shared_interaction" : "interacts with",
        "name" : "Favourite (interacts with) Fameuil",
        "interaction" : "interacts with",
        "SUID" : 81115,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81071",
        "source" : "81070",
        "target" : "80961",
        "shared_name" : "Favourite (interacts with) Blacheville",
        "shared_interaction" : "interacts with",
        "name" : "Favourite (interacts with) Blacheville",
        "interaction" : "interacts with",
        "SUID" : 81071,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81225",
        "source" : "81061",
        "target" : "80955",
        "shared_name" : "MadameThenardier (interacts with) Fantine",
        "shared_interaction" : "interacts with",
        "name" : "MadameThenardier (interacts with) Fantine",
        "interaction" : "interacts with",
        "SUID" : 81225,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81088",
        "source" : "81061",
        "target" : "80930",
        "shared_name" : "MadameThenardier (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "MadameThenardier (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81088,
        "Strength" : 7,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81259",
        "source" : "81052",
        "target" : "80939",
        "shared_name" : "Chenildieu (interacts with) Judge",
        "shared_interaction" : "interacts with",
        "name" : "Chenildieu (interacts with) Judge",
        "interaction" : "interacts with",
        "SUID" : 81259,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81211",
        "source" : "81052",
        "target" : "80938",
        "shared_name" : "Chenildieu (interacts with) Brevet",
        "shared_interaction" : "interacts with",
        "name" : "Chenildieu (interacts with) Brevet",
        "interaction" : "interacts with",
        "SUID" : 81211,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81210",
        "source" : "81052",
        "target" : "80930",
        "shared_name" : "Chenildieu (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Chenildieu (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81210,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81159",
        "source" : "81052",
        "target" : "81045",
        "shared_name" : "Chenildieu (interacts with) Champmathieu",
        "shared_interaction" : "interacts with",
        "name" : "Chenildieu (interacts with) Champmathieu",
        "interaction" : "interacts with",
        "SUID" : 81159,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81053",
        "source" : "81052",
        "target" : "80941",
        "shared_name" : "Chenildieu (interacts with) Bamatabois",
        "shared_interaction" : "interacts with",
        "name" : "Chenildieu (interacts with) Bamatabois",
        "interaction" : "interacts with",
        "SUID" : 81053,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81231",
        "source" : "81045",
        "target" : "80941",
        "shared_name" : "Champmathieu (interacts with) Bamatabois",
        "shared_interaction" : "interacts with",
        "name" : "Champmathieu (interacts with) Bamatabois",
        "interaction" : "interacts with",
        "SUID" : 81231,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81223",
        "source" : "81045",
        "target" : "80939",
        "shared_name" : "Champmathieu (interacts with) Judge",
        "shared_interaction" : "interacts with",
        "name" : "Champmathieu (interacts with) Judge",
        "interaction" : "interacts with",
        "SUID" : 81223,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81168",
        "source" : "81045",
        "target" : "80930",
        "shared_name" : "Champmathieu (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Champmathieu (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81168,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81177",
        "source" : "81043",
        "target" : "80981",
        "shared_name" : "Enjolras (interacts with) Mabeuf",
        "shared_interaction" : "interacts with",
        "name" : "Enjolras (interacts with) Mabeuf",
        "interaction" : "interacts with",
        "SUID" : 81177,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81135",
        "source" : "81043",
        "target" : "80943",
        "shared_name" : "Enjolras (interacts with) Gavroche",
        "shared_interaction" : "interacts with",
        "name" : "Enjolras (interacts with) Gavroche",
        "interaction" : "interacts with",
        "SUID" : 81135,
        "Strength" : 7,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81093",
        "source" : "81043",
        "target" : "80948",
        "shared_name" : "Enjolras (interacts with) Javert",
        "shared_interaction" : "interacts with",
        "name" : "Enjolras (interacts with) Javert",
        "interaction" : "interacts with",
        "SUID" : 81093,
        "Strength" : 6,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81090",
        "source" : "81043",
        "target" : "80930",
        "shared_name" : "Enjolras (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Enjolras (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81090,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81069",
        "source" : "81043",
        "target" : "80957",
        "shared_name" : "Enjolras (interacts with) Marius",
        "shared_interaction" : "interacts with",
        "name" : "Enjolras (interacts with) Marius",
        "interaction" : "interacts with",
        "SUID" : 81069,
        "Strength" : 7,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81114",
        "source" : "81041",
        "target" : "81061",
        "shared_name" : "Eponine (interacts with) MadameThenardier",
        "shared_interaction" : "interacts with",
        "name" : "Eponine (interacts with) MadameThenardier",
        "interaction" : "interacts with",
        "SUID" : 81114,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81068",
        "source" : "81041",
        "target" : "80973",
        "shared_name" : "Eponine (interacts with) Thenardier",
        "shared_interaction" : "interacts with",
        "name" : "Eponine (interacts with) Thenardier",
        "interaction" : "interacts with",
        "SUID" : 81068,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81233",
        "source" : "81031",
        "target" : "80930",
        "shared_name" : "Cochepaille (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Cochepaille (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81233,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81140",
        "source" : "81031",
        "target" : "80938",
        "shared_name" : "Cochepaille (interacts with) Brevet",
        "shared_interaction" : "interacts with",
        "name" : "Cochepaille (interacts with) Brevet",
        "interaction" : "interacts with",
        "SUID" : 81140,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81129",
        "source" : "81031",
        "target" : "80939",
        "shared_name" : "Cochepaille (interacts with) Judge",
        "shared_interaction" : "interacts with",
        "name" : "Cochepaille (interacts with) Judge",
        "interaction" : "interacts with",
        "SUID" : 81129,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81113",
        "source" : "81031",
        "target" : "81052",
        "shared_name" : "Cochepaille (interacts with) Chenildieu",
        "shared_interaction" : "interacts with",
        "name" : "Cochepaille (interacts with) Chenildieu",
        "interaction" : "interacts with",
        "SUID" : 81113,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81046",
        "source" : "81031",
        "target" : "81045",
        "shared_name" : "Cochepaille (interacts with) Champmathieu",
        "shared_interaction" : "interacts with",
        "name" : "Cochepaille (interacts with) Champmathieu",
        "interaction" : "interacts with",
        "SUID" : 81046,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81032",
        "source" : "81031",
        "target" : "80941",
        "shared_name" : "Cochepaille (interacts with) Bamatabois",
        "shared_interaction" : "interacts with",
        "name" : "Cochepaille (interacts with) Bamatabois",
        "interaction" : "interacts with",
        "SUID" : 81032,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81162",
        "source" : "81027",
        "target" : "81161",
        "shared_name" : "MadameBurgon (interacts with) Jondrette",
        "shared_interaction" : "interacts with",
        "name" : "MadameBurgon (interacts with) Jondrette",
        "interaction" : "interacts with",
        "SUID" : 81162,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81102",
        "source" : "81025",
        "target" : "81023",
        "shared_name" : "LieutenantTheoduleGillenormand (interacts with) MademoiselleGillenormand",
        "shared_interaction" : "interacts with",
        "name" : "LieutenantTheoduleGillenormand (interacts with) MademoiselleGillenormand",
        "interaction" : "interacts with",
        "SUID" : 81102,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81033",
        "source" : "81025",
        "target" : "80958",
        "shared_name" : "LieutenantTheoduleGillenormand (interacts with) Cosette",
        "shared_interaction" : "interacts with",
        "name" : "LieutenantTheoduleGillenormand (interacts with) Cosette",
        "interaction" : "interacts with",
        "SUID" : 81033,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81026",
        "source" : "81025",
        "target" : "80929",
        "shared_name" : "LieutenantTheoduleGillenormand (interacts with) Gillenormand",
        "shared_interaction" : "interacts with",
        "name" : "LieutenantTheoduleGillenormand (interacts with) Gillenormand",
        "interaction" : "interacts with",
        "SUID" : 81026,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81254",
        "source" : "81023",
        "target" : "80930",
        "shared_name" : "MademoiselleGillenormand (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "MademoiselleGillenormand (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81254,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81203",
        "source" : "81023",
        "target" : "80929",
        "shared_name" : "MademoiselleGillenormand (interacts with) Gillenormand",
        "shared_interaction" : "interacts with",
        "name" : "MademoiselleGillenormand (interacts with) Gillenormand",
        "interaction" : "interacts with",
        "SUID" : 81203,
        "Strength" : 9,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81024",
        "source" : "81023",
        "target" : "80958",
        "shared_name" : "MademoiselleGillenormand (interacts with) Cosette",
        "shared_interaction" : "interacts with",
        "name" : "MademoiselleGillenormand (interacts with) Cosette",
        "interaction" : "interacts with",
        "SUID" : 81024,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81022",
        "source" : "81021",
        "target" : "80930",
        "shared_name" : "Gervais (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Gervais (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81022,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81213",
        "source" : "81018",
        "target" : "80930",
        "shared_name" : "Fauchelevent (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Fauchelevent (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81213,
        "Strength" : 8,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81019",
        "source" : "81018",
        "target" : "80948",
        "shared_name" : "Fauchelevent (interacts with) Javert",
        "shared_interaction" : "interacts with",
        "name" : "Fauchelevent (interacts with) Javert",
        "interaction" : "interacts with",
        "SUID" : 81019,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81016",
        "source" : "81015",
        "target" : "80930",
        "shared_name" : "MaubertIsabeau (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "MaubertIsabeau (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81016,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81246",
        "source" : "81013",
        "target" : "80930",
        "shared_name" : "Marguerite (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Marguerite (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81246,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81251",
        "source" : "81008",
        "target" : "81208",
        "shared_name" : "SisterSimplice (interacts with) SisterPerpetue",
        "shared_interaction" : "interacts with",
        "name" : "SisterSimplice (interacts with) SisterPerpetue",
        "interaction" : "interacts with",
        "SUID" : 81251,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81222",
        "source" : "81008",
        "target" : "80930",
        "shared_name" : "SisterSimplice (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "SisterSimplice (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81222,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81051",
        "source" : "81008",
        "target" : "80948",
        "shared_name" : "SisterSimplice (interacts with) Javert",
        "shared_interaction" : "interacts with",
        "name" : "SisterSimplice (interacts with) Javert",
        "interaction" : "interacts with",
        "SUID" : 81051,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81009",
        "source" : "81008",
        "target" : "80955",
        "shared_name" : "SisterSimplice (interacts with) Fantine",
        "shared_interaction" : "interacts with",
        "name" : "SisterSimplice (interacts with) Fantine",
        "interaction" : "interacts with",
        "SUID" : 81009,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81207",
        "source" : "81003",
        "target" : "81127",
        "shared_name" : "Child2 (interacts with) Child1",
        "shared_interaction" : "interacts with",
        "name" : "Child2 (interacts with) Child1",
        "interaction" : "interacts with",
        "SUID" : 81207,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81004",
        "source" : "81003",
        "target" : "80943",
        "shared_name" : "Child2 (interacts with) Gavroche",
        "shared_interaction" : "interacts with",
        "name" : "Child2 (interacts with) Gavroche",
        "interaction" : "interacts with",
        "SUID" : 81004,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81252",
        "source" : "81001",
        "target" : "80943",
        "shared_name" : "LAigleDeMeauxBossuet  (interacts with) Gavroche",
        "shared_interaction" : "interacts with",
        "name" : "LAigleDeMeauxBossuet  (interacts with) Gavroche",
        "interaction" : "interacts with",
        "SUID" : 81252,
        "Strength" : 5,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81242",
        "source" : "81001",
        "target" : "80975",
        "shared_name" : "LAigleDeMeauxBossuet  (interacts with) Combeferre",
        "shared_interaction" : "interacts with",
        "name" : "LAigleDeMeauxBossuet  (interacts with) Combeferre",
        "interaction" : "interacts with",
        "SUID" : 81242,
        "Strength" : 9,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81201",
        "source" : "81001",
        "target" : "80936",
        "shared_name" : "LAigleDeMeauxBossuet  (interacts with) Feuilly",
        "shared_interaction" : "interacts with",
        "name" : "LAigleDeMeauxBossuet  (interacts with) Feuilly",
        "interaction" : "interacts with",
        "SUID" : 81201,
        "Strength" : 6,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81187",
        "source" : "81001",
        "target" : "81043",
        "shared_name" : "LAigleDeMeauxBossuet  (interacts with) Enjolras",
        "shared_interaction" : "interacts with",
        "name" : "LAigleDeMeauxBossuet  (interacts with) Enjolras",
        "interaction" : "interacts with",
        "SUID" : 81187,
        "Strength" : 10,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81185",
        "source" : "81001",
        "target" : "80981",
        "shared_name" : "LAigleDeMeauxBossuet  (interacts with) Mabeuf",
        "shared_interaction" : "interacts with",
        "name" : "LAigleDeMeauxBossuet  (interacts with) Mabeuf",
        "interaction" : "interacts with",
        "SUID" : 81185,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81148",
        "source" : "81001",
        "target" : "80979",
        "shared_name" : "LAigleDeMeauxBossuet  (interacts with) JeanProuvaire",
        "shared_interaction" : "interacts with",
        "name" : "LAigleDeMeauxBossuet  (interacts with) JeanProuvaire",
        "interaction" : "interacts with",
        "SUID" : 81148,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81097",
        "source" : "81001",
        "target" : "80946",
        "shared_name" : "LAigleDeMeauxBossuet  (interacts with) Courfeyrac",
        "shared_interaction" : "interacts with",
        "name" : "LAigleDeMeauxBossuet  (interacts with) Courfeyrac",
        "interaction" : "interacts with",
        "SUID" : 81097,
        "Strength" : 12,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81077",
        "source" : "81001",
        "target" : "80977",
        "shared_name" : "LAigleDeMeauxBossuet  (interacts with) Bahorel",
        "shared_interaction" : "interacts with",
        "name" : "LAigleDeMeauxBossuet  (interacts with) Bahorel",
        "interaction" : "interacts with",
        "SUID" : 81077,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81029",
        "source" : "81001",
        "target" : "80930",
        "shared_name" : "LAigleDeMeauxBossuet  (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "LAigleDeMeauxBossuet  (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81029,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81002",
        "source" : "81001",
        "target" : "80957",
        "shared_name" : "LAigleDeMeauxBossuet  (interacts with) Marius",
        "shared_interaction" : "interacts with",
        "name" : "LAigleDeMeauxBossuet  (interacts with) Marius",
        "interaction" : "interacts with",
        "SUID" : 81002,
        "Strength" : 5,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81155",
        "source" : "80998",
        "target" : "80988",
        "shared_name" : "Fameuil (interacts with) FelixTholomyes",
        "shared_interaction" : "interacts with",
        "name" : "Fameuil (interacts with) FelixTholomyes",
        "interaction" : "interacts with",
        "SUID" : 81155,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80999",
        "source" : "80998",
        "target" : "80933",
        "shared_name" : "Fameuil (interacts with) Listolier",
        "shared_interaction" : "interacts with",
        "name" : "Fameuil (interacts with) Listolier",
        "interaction" : "interacts with",
        "SUID" : 80999,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81183",
        "source" : "80995",
        "target" : "80930",
        "shared_name" : "Toussaint (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Toussaint (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81183,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81067",
        "source" : "80995",
        "target" : "80958",
        "shared_name" : "Toussaint (interacts with) Cosette",
        "shared_interaction" : "interacts with",
        "name" : "Toussaint (interacts with) Cosette",
        "interaction" : "interacts with",
        "SUID" : 81067,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80996",
        "source" : "80995",
        "target" : "80948",
        "shared_name" : "Toussaint (interacts with) Javert",
        "shared_interaction" : "interacts with",
        "name" : "Toussaint (interacts with) Javert",
        "interaction" : "interacts with",
        "SUID" : 80996,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81258",
        "source" : "80993",
        "target" : "80984",
        "shared_name" : "Babet (interacts with) Gueulemer",
        "shared_interaction" : "interacts with",
        "name" : "Babet (interacts with) Gueulemer",
        "interaction" : "interacts with",
        "SUID" : 81258,
        "Strength" : 6,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81230",
        "source" : "80993",
        "target" : "81041",
        "shared_name" : "Babet (interacts with) Eponine",
        "shared_interaction" : "interacts with",
        "name" : "Babet (interacts with) Eponine",
        "interaction" : "interacts with",
        "SUID" : 81230,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81175",
        "source" : "80993",
        "target" : "80943",
        "shared_name" : "Babet (interacts with) Gavroche",
        "shared_interaction" : "interacts with",
        "name" : "Babet (interacts with) Gavroche",
        "interaction" : "interacts with",
        "SUID" : 81175,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81145",
        "source" : "80993",
        "target" : "81061",
        "shared_name" : "Babet (interacts with) MadameThenardier",
        "shared_interaction" : "interacts with",
        "name" : "Babet (interacts with) MadameThenardier",
        "interaction" : "interacts with",
        "SUID" : 81145,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81116",
        "source" : "80993",
        "target" : "80948",
        "shared_name" : "Babet (interacts with) Javert",
        "shared_interaction" : "interacts with",
        "name" : "Babet (interacts with) Javert",
        "interaction" : "interacts with",
        "SUID" : 81116,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81048",
        "source" : "80993",
        "target" : "80973",
        "shared_name" : "Babet (interacts with) Thenardier",
        "shared_interaction" : "interacts with",
        "name" : "Babet (interacts with) Thenardier",
        "interaction" : "interacts with",
        "SUID" : 81048,
        "Strength" : 6,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81036",
        "source" : "80993",
        "target" : "80930",
        "shared_name" : "Babet (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Babet (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81036,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81214",
        "source" : "80992",
        "target" : "80943",
        "shared_name" : "Brujon (interacts with) Gavroche",
        "shared_interaction" : "interacts with",
        "name" : "Brujon (interacts with) Gavroche",
        "interaction" : "interacts with",
        "SUID" : 81214,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81084",
        "source" : "80992",
        "target" : "80967",
        "shared_name" : "Brujon (interacts with) Claquesous",
        "shared_interaction" : "interacts with",
        "name" : "Brujon (interacts with) Claquesous",
        "interaction" : "interacts with",
        "SUID" : 81084,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81073",
        "source" : "80992",
        "target" : "80984",
        "shared_name" : "Brujon (interacts with) Gueulemer",
        "shared_interaction" : "interacts with",
        "name" : "Brujon (interacts with) Gueulemer",
        "interaction" : "interacts with",
        "SUID" : 81073,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81066",
        "source" : "80992",
        "target" : "80966",
        "shared_name" : "Brujon (interacts with) Montparnasse",
        "shared_interaction" : "interacts with",
        "name" : "Brujon (interacts with) Montparnasse",
        "interaction" : "interacts with",
        "SUID" : 81066,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81059",
        "source" : "80992",
        "target" : "80973",
        "shared_name" : "Brujon (interacts with) Thenardier",
        "shared_interaction" : "interacts with",
        "name" : "Brujon (interacts with) Thenardier",
        "interaction" : "interacts with",
        "SUID" : 81059,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81042",
        "source" : "80992",
        "target" : "81041",
        "shared_name" : "Brujon (interacts with) Eponine",
        "shared_interaction" : "interacts with",
        "name" : "Brujon (interacts with) Eponine",
        "interaction" : "interacts with",
        "SUID" : 81042,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80994",
        "source" : "80992",
        "target" : "80993",
        "shared_name" : "Brujon (interacts with) Babet",
        "shared_interaction" : "interacts with",
        "name" : "Brujon (interacts with) Babet",
        "interaction" : "interacts with",
        "SUID" : 80994,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80991",
        "source" : "80990",
        "target" : "80951",
        "shared_name" : "OldMan (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "shared_interaction" : "interacts with",
        "name" : "OldMan (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "interaction" : "interacts with",
        "SUID" : 80991,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81215",
        "source" : "80984",
        "target" : "81041",
        "shared_name" : "Gueulemer (interacts with) Eponine",
        "shared_interaction" : "interacts with",
        "name" : "Gueulemer (interacts with) Eponine",
        "interaction" : "interacts with",
        "SUID" : 81215,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81119",
        "source" : "80984",
        "target" : "80943",
        "shared_name" : "Gueulemer (interacts with) Gavroche",
        "shared_interaction" : "interacts with",
        "name" : "Gueulemer (interacts with) Gavroche",
        "interaction" : "interacts with",
        "SUID" : 81119,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81089",
        "source" : "80984",
        "target" : "81061",
        "shared_name" : "Gueulemer (interacts with) MadameThenardier",
        "shared_interaction" : "interacts with",
        "name" : "Gueulemer (interacts with) MadameThenardier",
        "interaction" : "interacts with",
        "SUID" : 81089,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81030",
        "source" : "80984",
        "target" : "80948",
        "shared_name" : "Gueulemer (interacts with) Javert",
        "shared_interaction" : "interacts with",
        "name" : "Gueulemer (interacts with) Javert",
        "interaction" : "interacts with",
        "SUID" : 81030,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81006",
        "source" : "80984",
        "target" : "80973",
        "shared_name" : "Gueulemer (interacts with) Thenardier",
        "shared_interaction" : "interacts with",
        "name" : "Gueulemer (interacts with) Thenardier",
        "interaction" : "interacts with",
        "SUID" : 81006,
        "Strength" : 5,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80985",
        "source" : "80984",
        "target" : "80930",
        "shared_name" : "Gueulemer (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Gueulemer (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 80985,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81164",
        "source" : "80981",
        "target" : "81041",
        "shared_name" : "Mabeuf (interacts with) Eponine",
        "shared_interaction" : "interacts with",
        "name" : "Mabeuf (interacts with) Eponine",
        "interaction" : "interacts with",
        "SUID" : 81164,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81020",
        "source" : "80981",
        "target" : "80943",
        "shared_name" : "Mabeuf (interacts with) Gavroche",
        "shared_interaction" : "interacts with",
        "name" : "Mabeuf (interacts with) Gavroche",
        "interaction" : "interacts with",
        "SUID" : 81020,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81005",
        "source" : "80981",
        "target" : "80957",
        "shared_name" : "Mabeuf (interacts with) Marius",
        "shared_interaction" : "interacts with",
        "name" : "Mabeuf (interacts with) Marius",
        "interaction" : "interacts with",
        "SUID" : 81005,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81130",
        "source" : "80979",
        "target" : "80975",
        "shared_name" : "JeanProuvaire (interacts with) Combeferre",
        "shared_interaction" : "interacts with",
        "name" : "JeanProuvaire (interacts with) Combeferre",
        "interaction" : "interacts with",
        "SUID" : 81130,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81109",
        "source" : "80979",
        "target" : "80943",
        "shared_name" : "JeanProuvaire (interacts with) Gavroche",
        "shared_interaction" : "interacts with",
        "name" : "JeanProuvaire (interacts with) Gavroche",
        "interaction" : "interacts with",
        "SUID" : 81109,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81057",
        "source" : "80979",
        "target" : "81043",
        "shared_name" : "JeanProuvaire (interacts with) Enjolras",
        "shared_interaction" : "interacts with",
        "name" : "JeanProuvaire (interacts with) Enjolras",
        "interaction" : "interacts with",
        "SUID" : 81057,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81244",
        "source" : "80977",
        "target" : "80957",
        "shared_name" : "Bahorel (interacts with) Marius",
        "shared_interaction" : "interacts with",
        "name" : "Bahorel (interacts with) Marius",
        "interaction" : "interacts with",
        "SUID" : 81244,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81174",
        "source" : "80977",
        "target" : "80943",
        "shared_name" : "Bahorel (interacts with) Gavroche",
        "shared_interaction" : "interacts with",
        "name" : "Bahorel (interacts with) Gavroche",
        "interaction" : "interacts with",
        "SUID" : 81174,
        "Strength" : 5,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81087",
        "source" : "80977",
        "target" : "80975",
        "shared_name" : "Bahorel (interacts with) Combeferre",
        "shared_interaction" : "interacts with",
        "name" : "Bahorel (interacts with) Combeferre",
        "interaction" : "interacts with",
        "SUID" : 81087,
        "Strength" : 5,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81083",
        "source" : "80977",
        "target" : "80946",
        "shared_name" : "Bahorel (interacts with) Courfeyrac",
        "shared_interaction" : "interacts with",
        "name" : "Bahorel (interacts with) Courfeyrac",
        "interaction" : "interacts with",
        "SUID" : 81083,
        "Strength" : 6,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81079",
        "source" : "80977",
        "target" : "81043",
        "shared_name" : "Bahorel (interacts with) Enjolras",
        "shared_interaction" : "interacts with",
        "name" : "Bahorel (interacts with) Enjolras",
        "interaction" : "interacts with",
        "SUID" : 81079,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81064",
        "source" : "80977",
        "target" : "80979",
        "shared_name" : "Bahorel (interacts with) JeanProuvaire",
        "shared_interaction" : "interacts with",
        "name" : "Bahorel (interacts with) JeanProuvaire",
        "interaction" : "interacts with",
        "SUID" : 81064,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80983",
        "source" : "80977",
        "target" : "80981",
        "shared_name" : "Bahorel (interacts with) Mabeuf",
        "shared_interaction" : "interacts with",
        "name" : "Bahorel (interacts with) Mabeuf",
        "interaction" : "interacts with",
        "SUID" : 80983,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80978",
        "source" : "80977",
        "target" : "80936",
        "shared_name" : "Bahorel (interacts with) Feuilly",
        "shared_interaction" : "interacts with",
        "name" : "Bahorel (interacts with) Feuilly",
        "interaction" : "interacts with",
        "SUID" : 80978,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81150",
        "source" : "80975",
        "target" : "80943",
        "shared_name" : "Combeferre (interacts with) Gavroche",
        "shared_interaction" : "interacts with",
        "name" : "Combeferre (interacts with) Gavroche",
        "interaction" : "interacts with",
        "SUID" : 81150,
        "Strength" : 6,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81118",
        "source" : "80975",
        "target" : "81043",
        "shared_name" : "Combeferre (interacts with) Enjolras",
        "shared_interaction" : "interacts with",
        "name" : "Combeferre (interacts with) Enjolras",
        "interaction" : "interacts with",
        "SUID" : 81118,
        "Strength" : 15,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80982",
        "source" : "80975",
        "target" : "80981",
        "shared_name" : "Combeferre (interacts with) Mabeuf",
        "shared_interaction" : "interacts with",
        "name" : "Combeferre (interacts with) Mabeuf",
        "interaction" : "interacts with",
        "SUID" : 80982,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80976",
        "source" : "80975",
        "target" : "80957",
        "shared_name" : "Combeferre (interacts with) Marius",
        "shared_interaction" : "interacts with",
        "name" : "Combeferre (interacts with) Marius",
        "interaction" : "interacts with",
        "SUID" : 80976,
        "Strength" : 5,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81165",
        "source" : "80973",
        "target" : "80955",
        "shared_name" : "Thenardier (interacts with) Fantine",
        "shared_interaction" : "interacts with",
        "name" : "Thenardier (interacts with) Fantine",
        "interaction" : "interacts with",
        "SUID" : 81165,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81126",
        "source" : "80973",
        "target" : "81061",
        "shared_name" : "Thenardier (interacts with) MadameThenardier",
        "shared_interaction" : "interacts with",
        "name" : "Thenardier (interacts with) MadameThenardier",
        "interaction" : "interacts with",
        "SUID" : 81126,
        "Strength" : 13,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81038",
        "source" : "80973",
        "target" : "80930",
        "shared_name" : "Thenardier (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Thenardier (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81038,
        "Strength" : 12,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80974",
        "source" : "80972",
        "target" : "80973",
        "shared_name" : "Pontmercy (interacts with) Thenardier",
        "shared_interaction" : "interacts with",
        "name" : "Pontmercy (interacts with) Thenardier",
        "interaction" : "interacts with",
        "SUID" : 80974,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81193",
        "source" : "80970",
        "target" : "80943",
        "shared_name" : "Grantaire (interacts with) Gavroche",
        "shared_interaction" : "interacts with",
        "name" : "Grantaire (interacts with) Gavroche",
        "interaction" : "interacts with",
        "SUID" : 81193,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81191",
        "source" : "80970",
        "target" : "80946",
        "shared_name" : "Grantaire (interacts with) Courfeyrac",
        "shared_interaction" : "interacts with",
        "name" : "Grantaire (interacts with) Courfeyrac",
        "interaction" : "interacts with",
        "SUID" : 81191,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81131",
        "source" : "80970",
        "target" : "80977",
        "shared_name" : "Grantaire (interacts with) Bahorel",
        "shared_interaction" : "interacts with",
        "name" : "Grantaire (interacts with) Bahorel",
        "interaction" : "interacts with",
        "SUID" : 81131,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81080",
        "source" : "80970",
        "target" : "80979",
        "shared_name" : "Grantaire (interacts with) JeanProuvaire",
        "shared_interaction" : "interacts with",
        "name" : "Grantaire (interacts with) JeanProuvaire",
        "interaction" : "interacts with",
        "SUID" : 81080,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81076",
        "source" : "80970",
        "target" : "81001",
        "shared_name" : "Grantaire (interacts with) LAigleDeMeauxBossuet ",
        "shared_interaction" : "interacts with",
        "name" : "Grantaire (interacts with) LAigleDeMeauxBossuet ",
        "interaction" : "interacts with",
        "SUID" : 81076,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81058",
        "source" : "80970",
        "target" : "80936",
        "shared_name" : "Grantaire (interacts with) Feuilly",
        "shared_interaction" : "interacts with",
        "name" : "Grantaire (interacts with) Feuilly",
        "interaction" : "interacts with",
        "SUID" : 81058,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81044",
        "source" : "80970",
        "target" : "81043",
        "shared_name" : "Grantaire (interacts with) Enjolras",
        "shared_interaction" : "interacts with",
        "name" : "Grantaire (interacts with) Enjolras",
        "interaction" : "interacts with",
        "SUID" : 81044,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81037",
        "source" : "80970",
        "target" : "80935",
        "shared_name" : "Grantaire (interacts with) Joly",
        "shared_interaction" : "interacts with",
        "name" : "Grantaire (interacts with) Joly",
        "interaction" : "interacts with",
        "SUID" : 81037,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81000",
        "source" : "80970",
        "target" : "80975",
        "shared_name" : "Grantaire (interacts with) Combeferre",
        "shared_interaction" : "interacts with",
        "name" : "Grantaire (interacts with) Combeferre",
        "interaction" : "interacts with",
        "SUID" : 81000,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81220",
        "source" : "80967",
        "target" : "80993",
        "shared_name" : "Claquesous (interacts with) Babet",
        "shared_interaction" : "interacts with",
        "name" : "Claquesous (interacts with) Babet",
        "interaction" : "interacts with",
        "SUID" : 81220,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81206",
        "source" : "80967",
        "target" : "80948",
        "shared_name" : "Claquesous (interacts with) Javert",
        "shared_interaction" : "interacts with",
        "name" : "Claquesous (interacts with) Javert",
        "interaction" : "interacts with",
        "SUID" : 81206,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81182",
        "source" : "80967",
        "target" : "80984",
        "shared_name" : "Claquesous (interacts with) Gueulemer",
        "shared_interaction" : "interacts with",
        "name" : "Claquesous (interacts with) Gueulemer",
        "interaction" : "interacts with",
        "SUID" : 81182,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81181",
        "source" : "80967",
        "target" : "80973",
        "shared_name" : "Claquesous (interacts with) Thenardier",
        "shared_interaction" : "interacts with",
        "name" : "Claquesous (interacts with) Thenardier",
        "interaction" : "interacts with",
        "SUID" : 81181,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81180",
        "source" : "80967",
        "target" : "81043",
        "shared_name" : "Claquesous (interacts with) Enjolras",
        "shared_interaction" : "interacts with",
        "name" : "Claquesous (interacts with) Enjolras",
        "interaction" : "interacts with",
        "SUID" : 81180,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81103",
        "source" : "80967",
        "target" : "81041",
        "shared_name" : "Claquesous (interacts with) Eponine",
        "shared_interaction" : "interacts with",
        "name" : "Claquesous (interacts with) Eponine",
        "interaction" : "interacts with",
        "SUID" : 81103,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81094",
        "source" : "80967",
        "target" : "80930",
        "shared_name" : "Claquesous (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Claquesous (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81094,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81062",
        "source" : "80967",
        "target" : "81061",
        "shared_name" : "Claquesous (interacts with) MadameThenardier",
        "shared_interaction" : "interacts with",
        "name" : "Claquesous (interacts with) MadameThenardier",
        "interaction" : "interacts with",
        "SUID" : 81062,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81221",
        "source" : "80966",
        "target" : "81041",
        "shared_name" : "Montparnasse (interacts with) Eponine",
        "shared_interaction" : "interacts with",
        "name" : "Montparnasse (interacts with) Eponine",
        "interaction" : "interacts with",
        "SUID" : 81221,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81178",
        "source" : "80966",
        "target" : "80930",
        "shared_name" : "Montparnasse (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Montparnasse (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81178,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81154",
        "source" : "80966",
        "target" : "80993",
        "shared_name" : "Montparnasse (interacts with) Babet",
        "shared_interaction" : "interacts with",
        "name" : "Montparnasse (interacts with) Babet",
        "interaction" : "interacts with",
        "SUID" : 81154,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81147",
        "source" : "80966",
        "target" : "80948",
        "shared_name" : "Montparnasse (interacts with) Javert",
        "shared_interaction" : "interacts with",
        "name" : "Montparnasse (interacts with) Javert",
        "interaction" : "interacts with",
        "SUID" : 81147,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81136",
        "source" : "80966",
        "target" : "80973",
        "shared_name" : "Montparnasse (interacts with) Thenardier",
        "shared_interaction" : "interacts with",
        "name" : "Montparnasse (interacts with) Thenardier",
        "interaction" : "interacts with",
        "SUID" : 81136,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81132",
        "source" : "80966",
        "target" : "80984",
        "shared_name" : "Montparnasse (interacts with) Gueulemer",
        "shared_interaction" : "interacts with",
        "name" : "Montparnasse (interacts with) Gueulemer",
        "interaction" : "interacts with",
        "SUID" : 81132,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81047",
        "source" : "80966",
        "target" : "80943",
        "shared_name" : "Montparnasse (interacts with) Gavroche",
        "shared_interaction" : "interacts with",
        "name" : "Montparnasse (interacts with) Gavroche",
        "interaction" : "interacts with",
        "SUID" : 81047,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80968",
        "source" : "80966",
        "target" : "80967",
        "shared_name" : "Montparnasse (interacts with) Claquesous",
        "shared_interaction" : "interacts with",
        "name" : "Montparnasse (interacts with) Claquesous",
        "interaction" : "interacts with",
        "SUID" : 80968,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80964",
        "source" : "80963",
        "target" : "80930",
        "shared_name" : "Scaufflaire (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Scaufflaire (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 80964,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81228",
        "source" : "80961",
        "target" : "80998",
        "shared_name" : "Blacheville (interacts with) Fameuil",
        "shared_interaction" : "interacts with",
        "name" : "Blacheville (interacts with) Fameuil",
        "interaction" : "interacts with",
        "SUID" : 81228,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81212",
        "source" : "80961",
        "target" : "80988",
        "shared_name" : "Blacheville (interacts with) FelixTholomyes",
        "shared_interaction" : "interacts with",
        "name" : "Blacheville (interacts with) FelixTholomyes",
        "interaction" : "interacts with",
        "SUID" : 81212,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80962",
        "source" : "80961",
        "target" : "80933",
        "shared_name" : "Blacheville (interacts with) Listolier",
        "shared_interaction" : "interacts with",
        "name" : "Blacheville (interacts with) Listolier",
        "interaction" : "interacts with",
        "SUID" : 80962,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81197",
        "source" : "80958",
        "target" : "80930",
        "shared_name" : "Cosette (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Cosette (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81197,
        "Strength" : 31,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81125",
        "source" : "80958",
        "target" : "80973",
        "shared_name" : "Cosette (interacts with) Thenardier",
        "shared_interaction" : "interacts with",
        "name" : "Cosette (interacts with) Thenardier",
        "interaction" : "interacts with",
        "SUID" : 81125,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81122",
        "source" : "80958",
        "target" : "81061",
        "shared_name" : "Cosette (interacts with) MadameThenardier",
        "shared_interaction" : "interacts with",
        "name" : "Cosette (interacts with) MadameThenardier",
        "interaction" : "interacts with",
        "SUID" : 81122,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81010",
        "source" : "80958",
        "target" : "80988",
        "shared_name" : "Cosette (interacts with) FelixTholomyes",
        "shared_interaction" : "interacts with",
        "name" : "Cosette (interacts with) FelixTholomyes",
        "interaction" : "interacts with",
        "SUID" : 81010,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81200",
        "source" : "80957",
        "target" : "80943",
        "shared_name" : "Marius (interacts with) Gavroche",
        "shared_interaction" : "interacts with",
        "name" : "Marius (interacts with) Gavroche",
        "interaction" : "interacts with",
        "SUID" : 81200,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81157",
        "source" : "80957",
        "target" : "81041",
        "shared_name" : "Marius (interacts with) Eponine",
        "shared_interaction" : "interacts with",
        "name" : "Marius (interacts with) Eponine",
        "interaction" : "interacts with",
        "SUID" : 81157,
        "Strength" : 5,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81133",
        "source" : "80957",
        "target" : "80973",
        "shared_name" : "Marius (interacts with) Thenardier",
        "shared_interaction" : "interacts with",
        "name" : "Marius (interacts with) Thenardier",
        "interaction" : "interacts with",
        "SUID" : 81133,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81123",
        "source" : "80957",
        "target" : "80988",
        "shared_name" : "Marius (interacts with) FelixTholomyes",
        "shared_interaction" : "interacts with",
        "name" : "Marius (interacts with) FelixTholomyes",
        "interaction" : "interacts with",
        "SUID" : 81123,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81082",
        "source" : "80957",
        "target" : "81023",
        "shared_name" : "Marius (interacts with) MademoiselleGillenormand",
        "shared_interaction" : "interacts with",
        "name" : "Marius (interacts with) MademoiselleGillenormand",
        "interaction" : "interacts with",
        "SUID" : 81082,
        "Strength" : 6,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81078",
        "source" : "80957",
        "target" : "80972",
        "shared_name" : "Marius (interacts with) Pontmercy",
        "shared_interaction" : "interacts with",
        "name" : "Marius (interacts with) Pontmercy",
        "interaction" : "interacts with",
        "SUID" : 81078,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81065",
        "source" : "80957",
        "target" : "80929",
        "shared_name" : "Marius (interacts with) Gillenormand",
        "shared_interaction" : "interacts with",
        "name" : "Marius (interacts with) Gillenormand",
        "interaction" : "interacts with",
        "SUID" : 81065,
        "Strength" : 12,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81060",
        "source" : "80957",
        "target" : "81025",
        "shared_name" : "Marius (interacts with) LieutenantTheoduleGillenormand",
        "shared_interaction" : "interacts with",
        "name" : "Marius (interacts with) LieutenantTheoduleGillenormand",
        "interaction" : "interacts with",
        "SUID" : 81060,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81035",
        "source" : "80957",
        "target" : "80930",
        "shared_name" : "Marius (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Marius (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81035,
        "Strength" : 19,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80959",
        "source" : "80957",
        "target" : "80958",
        "shared_name" : "Marius (interacts with) Cosette",
        "shared_interaction" : "interacts with",
        "name" : "Marius (interacts with) Cosette",
        "interaction" : "interacts with",
        "SUID" : 80959,
        "Strength" : 21,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81238",
        "source" : "80955",
        "target" : "80988",
        "shared_name" : "Fantine (interacts with) FelixTholomyes",
        "shared_interaction" : "interacts with",
        "name" : "Fantine (interacts with) FelixTholomyes",
        "interaction" : "interacts with",
        "SUID" : 81238,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81232",
        "source" : "80955",
        "target" : "81070",
        "shared_name" : "Fantine (interacts with) Favourite",
        "shared_interaction" : "interacts with",
        "name" : "Fantine (interacts with) Favourite",
        "interaction" : "interacts with",
        "SUID" : 81232,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81169",
        "source" : "80955",
        "target" : "80961",
        "shared_name" : "Fantine (interacts with) Blacheville",
        "shared_interaction" : "interacts with",
        "name" : "Fantine (interacts with) Blacheville",
        "interaction" : "interacts with",
        "SUID" : 81169,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81054",
        "source" : "80955",
        "target" : "80933",
        "shared_name" : "Fantine (interacts with) Listolier",
        "shared_interaction" : "interacts with",
        "name" : "Fantine (interacts with) Listolier",
        "interaction" : "interacts with",
        "SUID" : 81054,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81017",
        "source" : "80955",
        "target" : "80998",
        "shared_name" : "Fantine (interacts with) Fameuil",
        "shared_interaction" : "interacts with",
        "name" : "Fantine (interacts with) Fameuil",
        "interaction" : "interacts with",
        "SUID" : 81017,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81014",
        "source" : "80955",
        "target" : "81013",
        "shared_name" : "Fantine (interacts with) Marguerite",
        "shared_interaction" : "interacts with",
        "name" : "Fantine (interacts with) Marguerite",
        "interaction" : "interacts with",
        "SUID" : 81014,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80997",
        "source" : "80955",
        "target" : "80953",
        "shared_name" : "Fantine (interacts with) Dahlia",
        "shared_interaction" : "interacts with",
        "name" : "Fantine (interacts with) Dahlia",
        "interaction" : "interacts with",
        "SUID" : 80997,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80969",
        "source" : "80955",
        "target" : "80932",
        "shared_name" : "Fantine (interacts with) Zephine",
        "shared_interaction" : "interacts with",
        "name" : "Fantine (interacts with) Zephine",
        "interaction" : "interacts with",
        "SUID" : 80969,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80956",
        "source" : "80955",
        "target" : "80930",
        "shared_name" : "Fantine (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Fantine (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 80956,
        "Strength" : 9,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81236",
        "source" : "80953",
        "target" : "81070",
        "shared_name" : "Dahlia (interacts with) Favourite",
        "shared_interaction" : "interacts with",
        "name" : "Dahlia (interacts with) Favourite",
        "interaction" : "interacts with",
        "SUID" : 81236,
        "Strength" : 5,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81112",
        "source" : "80953",
        "target" : "80998",
        "shared_name" : "Dahlia (interacts with) Fameuil",
        "shared_interaction" : "interacts with",
        "name" : "Dahlia (interacts with) Fameuil",
        "interaction" : "interacts with",
        "SUID" : 81112,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81081",
        "source" : "80953",
        "target" : "80961",
        "shared_name" : "Dahlia (interacts with) Blacheville",
        "shared_interaction" : "interacts with",
        "name" : "Dahlia (interacts with) Blacheville",
        "interaction" : "interacts with",
        "SUID" : 81081,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80989",
        "source" : "80953",
        "target" : "80988",
        "shared_name" : "Dahlia (interacts with) FelixTholomyes",
        "shared_interaction" : "interacts with",
        "name" : "Dahlia (interacts with) FelixTholomyes",
        "interaction" : "interacts with",
        "SUID" : 80989,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80954",
        "source" : "80953",
        "target" : "80933",
        "shared_name" : "Dahlia (interacts with) Listolier",
        "shared_interaction" : "interacts with",
        "name" : "Dahlia (interacts with) Listolier",
        "interaction" : "interacts with",
        "SUID" : 80954,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80952",
        "source" : "80950",
        "target" : "80951",
        "shared_name" : "Count (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "shared_interaction" : "interacts with",
        "name" : "Count (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "interaction" : "interacts with",
        "SUID" : 80952,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81179",
        "source" : "80948",
        "target" : "81061",
        "shared_name" : "Javert (interacts with) MadameThenardier",
        "shared_interaction" : "interacts with",
        "name" : "Javert (interacts with) MadameThenardier",
        "interaction" : "interacts with",
        "SUID" : 81179,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81101",
        "source" : "80948",
        "target" : "80955",
        "shared_name" : "Javert (interacts with) Fantine",
        "shared_interaction" : "interacts with",
        "name" : "Javert (interacts with) Fantine",
        "interaction" : "interacts with",
        "SUID" : 81101,
        "Strength" : 5,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81100",
        "source" : "80948",
        "target" : "80973",
        "shared_name" : "Javert (interacts with) Thenardier",
        "shared_interaction" : "interacts with",
        "name" : "Javert (interacts with) Thenardier",
        "interaction" : "interacts with",
        "SUID" : 81100,
        "Strength" : 5,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81049",
        "source" : "80948",
        "target" : "80958",
        "shared_name" : "Javert (interacts with) Cosette",
        "shared_interaction" : "interacts with",
        "name" : "Javert (interacts with) Cosette",
        "interaction" : "interacts with",
        "SUID" : 81049,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81034",
        "source" : "80948",
        "target" : "80930",
        "shared_name" : "Javert (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Javert (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81034,
        "Strength" : 17,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81186",
        "source" : "80946",
        "target" : "80943",
        "shared_name" : "Courfeyrac (interacts with) Gavroche",
        "shared_interaction" : "interacts with",
        "name" : "Courfeyrac (interacts with) Gavroche",
        "interaction" : "interacts with",
        "SUID" : 81186,
        "Strength" : 7,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81156",
        "source" : "80946",
        "target" : "81043",
        "shared_name" : "Courfeyrac (interacts with) Enjolras",
        "shared_interaction" : "interacts with",
        "name" : "Courfeyrac (interacts with) Enjolras",
        "interaction" : "interacts with",
        "SUID" : 81156,
        "Strength" : 17,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81134",
        "source" : "80946",
        "target" : "80975",
        "shared_name" : "Courfeyrac (interacts with) Combeferre",
        "shared_interaction" : "interacts with",
        "name" : "Courfeyrac (interacts with) Combeferre",
        "interaction" : "interacts with",
        "SUID" : 81134,
        "Strength" : 13,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81111",
        "source" : "80946",
        "target" : "80981",
        "shared_name" : "Courfeyrac (interacts with) Mabeuf",
        "shared_interaction" : "interacts with",
        "name" : "Courfeyrac (interacts with) Mabeuf",
        "interaction" : "interacts with",
        "SUID" : 81111,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81063",
        "source" : "80946",
        "target" : "81041",
        "shared_name" : "Courfeyrac (interacts with) Eponine",
        "shared_interaction" : "interacts with",
        "name" : "Courfeyrac (interacts with) Eponine",
        "interaction" : "interacts with",
        "SUID" : 81063,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81040",
        "source" : "80946",
        "target" : "80936",
        "shared_name" : "Courfeyrac (interacts with) Feuilly",
        "shared_interaction" : "interacts with",
        "name" : "Courfeyrac (interacts with) Feuilly",
        "interaction" : "interacts with",
        "SUID" : 81040,
        "Strength" : 6,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81007",
        "source" : "80946",
        "target" : "80957",
        "shared_name" : "Courfeyrac (interacts with) Marius",
        "shared_interaction" : "interacts with",
        "name" : "Courfeyrac (interacts with) Marius",
        "interaction" : "interacts with",
        "SUID" : 81007,
        "Strength" : 9,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80980",
        "source" : "80946",
        "target" : "80979",
        "shared_name" : "Courfeyrac (interacts with) JeanProuvaire",
        "shared_interaction" : "interacts with",
        "name" : "Courfeyrac (interacts with) JeanProuvaire",
        "interaction" : "interacts with",
        "SUID" : 80980,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81241",
        "source" : "80945",
        "target" : "80977",
        "shared_name" : "MadameHucheloup (interacts with) Bahorel",
        "shared_interaction" : "interacts with",
        "name" : "MadameHucheloup (interacts with) Bahorel",
        "interaction" : "interacts with",
        "SUID" : 81241,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81240",
        "source" : "80945",
        "target" : "81001",
        "shared_name" : "MadameHucheloup (interacts with) LAigleDeMeauxBossuet ",
        "shared_interaction" : "interacts with",
        "name" : "MadameHucheloup (interacts with) LAigleDeMeauxBossuet ",
        "interaction" : "interacts with",
        "SUID" : 81240,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81176",
        "source" : "80945",
        "target" : "81043",
        "shared_name" : "MadameHucheloup (interacts with) Enjolras",
        "shared_interaction" : "interacts with",
        "name" : "MadameHucheloup (interacts with) Enjolras",
        "interaction" : "interacts with",
        "SUID" : 81176,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80971",
        "source" : "80945",
        "target" : "80970",
        "shared_name" : "MadameHucheloup (interacts with) Grantaire",
        "shared_interaction" : "interacts with",
        "name" : "MadameHucheloup (interacts with) Grantaire",
        "interaction" : "interacts with",
        "SUID" : 80971,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80965",
        "source" : "80945",
        "target" : "80943",
        "shared_name" : "MadameHucheloup (interacts with) Gavroche",
        "shared_interaction" : "interacts with",
        "name" : "MadameHucheloup (interacts with) Gavroche",
        "interaction" : "interacts with",
        "SUID" : 80965,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80960",
        "source" : "80945",
        "target" : "80935",
        "shared_name" : "MadameHucheloup (interacts with) Joly",
        "shared_interaction" : "interacts with",
        "name" : "MadameHucheloup (interacts with) Joly",
        "interaction" : "interacts with",
        "SUID" : 80960,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80947",
        "source" : "80945",
        "target" : "80946",
        "shared_name" : "MadameHucheloup (interacts with) Courfeyrac",
        "shared_interaction" : "interacts with",
        "name" : "MadameHucheloup (interacts with) Courfeyrac",
        "interaction" : "interacts with",
        "SUID" : 80947,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81229",
        "source" : "80943",
        "target" : "80973",
        "shared_name" : "Gavroche (interacts with) Thenardier",
        "shared_interaction" : "interacts with",
        "name" : "Gavroche (interacts with) Thenardier",
        "interaction" : "interacts with",
        "SUID" : 81229,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81028",
        "source" : "80943",
        "target" : "81027",
        "shared_name" : "Gavroche (interacts with) MadameBurgon",
        "shared_interaction" : "interacts with",
        "name" : "Gavroche (interacts with) MadameBurgon",
        "interaction" : "interacts with",
        "SUID" : 81028,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80949",
        "source" : "80943",
        "target" : "80948",
        "shared_name" : "Gavroche (interacts with) Javert",
        "shared_interaction" : "interacts with",
        "name" : "Gavroche (interacts with) Javert",
        "interaction" : "interacts with",
        "SUID" : 80949,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80944",
        "source" : "80943",
        "target" : "80930",
        "shared_name" : "Gavroche (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Gavroche (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 80944,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81218",
        "source" : "80941",
        "target" : "80955",
        "shared_name" : "Bamatabois (interacts with) Fantine",
        "shared_interaction" : "interacts with",
        "name" : "Bamatabois (interacts with) Fantine",
        "interaction" : "interacts with",
        "SUID" : 81218,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81184",
        "source" : "80941",
        "target" : "80948",
        "shared_name" : "Bamatabois (interacts with) Javert",
        "shared_interaction" : "interacts with",
        "name" : "Bamatabois (interacts with) Javert",
        "interaction" : "interacts with",
        "SUID" : 81184,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80942",
        "source" : "80941",
        "target" : "80930",
        "shared_name" : "Bamatabois (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Bamatabois (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 80942,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81243",
        "source" : "80939",
        "target" : "80941",
        "shared_name" : "Judge (interacts with) Bamatabois",
        "shared_interaction" : "interacts with",
        "name" : "Judge (interacts with) Bamatabois",
        "interaction" : "interacts with",
        "SUID" : 81243,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81011",
        "source" : "80939",
        "target" : "80930",
        "shared_name" : "Judge (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Judge (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81011,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81199",
        "source" : "80938",
        "target" : "80941",
        "shared_name" : "Brevet (interacts with) Bamatabois",
        "shared_interaction" : "interacts with",
        "name" : "Brevet (interacts with) Bamatabois",
        "interaction" : "interacts with",
        "SUID" : 81199,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81194",
        "source" : "80938",
        "target" : "81045",
        "shared_name" : "Brevet (interacts with) Champmathieu",
        "shared_interaction" : "interacts with",
        "name" : "Brevet (interacts with) Champmathieu",
        "interaction" : "interacts with",
        "SUID" : 81194,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80986",
        "source" : "80938",
        "target" : "80930",
        "shared_name" : "Brevet (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Brevet (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 80986,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80940",
        "source" : "80938",
        "target" : "80939",
        "shared_name" : "Brevet (interacts with) Judge",
        "shared_interaction" : "interacts with",
        "name" : "Brevet (interacts with) Judge",
        "interaction" : "interacts with",
        "SUID" : 80940,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81202",
        "source" : "80936",
        "target" : "80957",
        "shared_name" : "Feuilly (interacts with) Marius",
        "shared_interaction" : "interacts with",
        "name" : "Feuilly (interacts with) Marius",
        "interaction" : "interacts with",
        "SUID" : 81202,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81170",
        "source" : "80936",
        "target" : "81043",
        "shared_name" : "Feuilly (interacts with) Enjolras",
        "shared_interaction" : "interacts with",
        "name" : "Feuilly (interacts with) Enjolras",
        "interaction" : "interacts with",
        "SUID" : 81170,
        "Strength" : 6,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81163",
        "source" : "80936",
        "target" : "80943",
        "shared_name" : "Feuilly (interacts with) Gavroche",
        "shared_interaction" : "interacts with",
        "name" : "Feuilly (interacts with) Gavroche",
        "interaction" : "interacts with",
        "SUID" : 81163,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81151",
        "source" : "80936",
        "target" : "80981",
        "shared_name" : "Feuilly (interacts with) Mabeuf",
        "shared_interaction" : "interacts with",
        "name" : "Feuilly (interacts with) Mabeuf",
        "interaction" : "interacts with",
        "SUID" : 81151,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81124",
        "source" : "80936",
        "target" : "80975",
        "shared_name" : "Feuilly (interacts with) Combeferre",
        "shared_interaction" : "interacts with",
        "name" : "Feuilly (interacts with) Combeferre",
        "interaction" : "interacts with",
        "SUID" : 81124,
        "Strength" : 5,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81039",
        "source" : "80936",
        "target" : "80979",
        "shared_name" : "Feuilly (interacts with) JeanProuvaire",
        "shared_interaction" : "interacts with",
        "name" : "Feuilly (interacts with) JeanProuvaire",
        "interaction" : "interacts with",
        "SUID" : 81039,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81253",
        "source" : "80935",
        "target" : "81043",
        "shared_name" : "Joly (interacts with) Enjolras",
        "shared_interaction" : "interacts with",
        "name" : "Joly (interacts with) Enjolras",
        "interaction" : "interacts with",
        "SUID" : 81253,
        "Strength" : 5,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81245",
        "source" : "80935",
        "target" : "80946",
        "shared_name" : "Joly (interacts with) Courfeyrac",
        "shared_interaction" : "interacts with",
        "name" : "Joly (interacts with) Courfeyrac",
        "interaction" : "interacts with",
        "SUID" : 81245,
        "Strength" : 5,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81188",
        "source" : "80935",
        "target" : "80975",
        "shared_name" : "Joly (interacts with) Combeferre",
        "shared_interaction" : "interacts with",
        "name" : "Joly (interacts with) Combeferre",
        "interaction" : "interacts with",
        "SUID" : 81188,
        "Strength" : 5,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81137",
        "source" : "80935",
        "target" : "80977",
        "shared_name" : "Joly (interacts with) Bahorel",
        "shared_interaction" : "interacts with",
        "name" : "Joly (interacts with) Bahorel",
        "interaction" : "interacts with",
        "SUID" : 81137,
        "Strength" : 5,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81110",
        "source" : "80935",
        "target" : "80943",
        "shared_name" : "Joly (interacts with) Gavroche",
        "shared_interaction" : "interacts with",
        "name" : "Joly (interacts with) Gavroche",
        "interaction" : "interacts with",
        "SUID" : 81110,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81092",
        "source" : "80935",
        "target" : "81001",
        "shared_name" : "Joly (interacts with) LAigleDeMeauxBossuet ",
        "shared_interaction" : "interacts with",
        "name" : "Joly (interacts with) LAigleDeMeauxBossuet ",
        "interaction" : "interacts with",
        "SUID" : 81092,
        "Strength" : 7,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81056",
        "source" : "80935",
        "target" : "80981",
        "shared_name" : "Joly (interacts with) Mabeuf",
        "shared_interaction" : "interacts with",
        "name" : "Joly (interacts with) Mabeuf",
        "interaction" : "interacts with",
        "SUID" : 81056,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81050",
        "source" : "80935",
        "target" : "80957",
        "shared_name" : "Joly (interacts with) Marius",
        "shared_interaction" : "interacts with",
        "name" : "Joly (interacts with) Marius",
        "interaction" : "interacts with",
        "SUID" : 81050,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80987",
        "source" : "80935",
        "target" : "80979",
        "shared_name" : "Joly (interacts with) JeanProuvaire",
        "shared_interaction" : "interacts with",
        "name" : "Joly (interacts with) JeanProuvaire",
        "interaction" : "interacts with",
        "SUID" : 80987,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80937",
        "source" : "80935",
        "target" : "80936",
        "shared_name" : "Joly (interacts with) Feuilly",
        "shared_interaction" : "interacts with",
        "name" : "Joly (interacts with) Feuilly",
        "interaction" : "interacts with",
        "SUID" : 80937,
        "Strength" : 5,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81108",
        "source" : "80933",
        "target" : "80988",
        "shared_name" : "Listolier (interacts with) FelixTholomyes",
        "shared_interaction" : "interacts with",
        "name" : "Listolier (interacts with) FelixTholomyes",
        "interaction" : "interacts with",
        "SUID" : 81108,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81219",
        "source" : "80932",
        "target" : "80998",
        "shared_name" : "Zephine (interacts with) Fameuil",
        "shared_interaction" : "interacts with",
        "name" : "Zephine (interacts with) Fameuil",
        "interaction" : "interacts with",
        "SUID" : 81219,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81158",
        "source" : "80932",
        "target" : "80988",
        "shared_name" : "Zephine (interacts with) FelixTholomyes",
        "shared_interaction" : "interacts with",
        "name" : "Zephine (interacts with) FelixTholomyes",
        "interaction" : "interacts with",
        "SUID" : 81158,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81091",
        "source" : "80932",
        "target" : "80961",
        "shared_name" : "Zephine (interacts with) Blacheville",
        "shared_interaction" : "interacts with",
        "name" : "Zephine (interacts with) Blacheville",
        "interaction" : "interacts with",
        "SUID" : 81091,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81072",
        "source" : "80932",
        "target" : "81070",
        "shared_name" : "Zephine (interacts with) Favourite",
        "shared_interaction" : "interacts with",
        "name" : "Zephine (interacts with) Favourite",
        "interaction" : "interacts with",
        "SUID" : 81072,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81055",
        "source" : "80932",
        "target" : "80953",
        "shared_name" : "Zephine (interacts with) Dahlia",
        "shared_interaction" : "interacts with",
        "name" : "Zephine (interacts with) Dahlia",
        "interaction" : "interacts with",
        "SUID" : 81055,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80934",
        "source" : "80932",
        "target" : "80933",
        "shared_name" : "Zephine (interacts with) Listolier",
        "shared_interaction" : "interacts with",
        "name" : "Zephine (interacts with) Listolier",
        "interaction" : "interacts with",
        "SUID" : 80934,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81248",
        "source" : "80930",
        "target" : "81247",
        "shared_name" : "JeanValjean (interacts with) JacquinLabarre",
        "shared_interaction" : "interacts with",
        "name" : "JeanValjean (interacts with) JacquinLabarre",
        "interaction" : "interacts with",
        "SUID" : 81248,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81226",
        "source" : "80930",
        "target" : "80951",
        "shared_name" : "JeanValjean (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "shared_interaction" : "interacts with",
        "name" : "JeanValjean (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "interaction" : "interacts with",
        "SUID" : 81226,
        "Strength" : 5,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81142",
        "source" : "80930",
        "target" : "81141",
        "shared_name" : "JeanValjean (interacts with) BaptistineMyrie",
        "shared_interaction" : "interacts with",
        "name" : "JeanValjean (interacts with) BaptistineMyrie",
        "interaction" : "interacts with",
        "SUID" : 81142,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81121",
        "source" : "80930",
        "target" : "81120",
        "shared_name" : "JeanValjean (interacts with) MadameMagloire",
        "shared_interaction" : "interacts with",
        "name" : "JeanValjean (interacts with) MadameMagloire",
        "interaction" : "interacts with",
        "SUID" : 81121,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81012",
        "source" : "80929",
        "target" : "80958",
        "shared_name" : "Gillenormand (interacts with) Cosette",
        "shared_interaction" : "interacts with",
        "name" : "Gillenormand (interacts with) Cosette",
        "interaction" : "interacts with",
        "SUID" : 81012,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80931",
        "source" : "80929",
        "target" : "80930",
        "shared_name" : "Gillenormand (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Gillenormand (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 80931,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    } ]
  }
},"lesmis.txt_2": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.7.1",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "lesmis.txt_2",
    "name" : "lesmis.txt_2",
    "SUID" : 81761,
    "__Annotations" : [ ],
    "selected" : true
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "82097",
        "ClosenessCentrality" : 0.30769231,
        "Eccentricity" : 5,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.55,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "MademoiselleVaubois",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "MademoiselleVaubois",
        "SelfLoops" : 0,
        "SUID" : 82097,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 1,
        "AverageShortestPathLength" : 3.25,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : -367.8812135858664,
        "y" : 82.35453177405907
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82091",
        "ClosenessCentrality" : 0.39378238,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.69210526,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "MadameDeR",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "MadameDeR",
        "SelfLoops" : 0,
        "SUID" : 82091,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 1,
        "AverageShortestPathLength" : 2.53947368,
        "selected" : false,
        "NeighborhoodConnectivity" : 36.0
      },
      "position" : {
        "x" : -392.0420781835171,
        "y" : 154.98291015625
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82089",
        "ClosenessCentrality" : 0.39378238,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.69210526,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "JacquinLabarre",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "JacquinLabarre",
        "SelfLoops" : 0,
        "SUID" : 82089,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 1,
        "AverageShortestPathLength" : 2.53947368,
        "selected" : false,
        "NeighborhoodConnectivity" : 36.0
      },
      "position" : {
        "x" : 39.529644568430456,
        "y" : 155.34299040748192
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82058",
        "ClosenessCentrality" : 0.34234234,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.61578947,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Boulatruelle",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Boulatruelle",
        "SelfLoops" : 0,
        "SUID" : 82058,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 1,
        "AverageShortestPathLength" : 2.92105263,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.0
      },
      "position" : {
        "x" : 186.58811624811796,
        "y" : 66.92379141761376
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82050",
        "ClosenessCentrality" : 0.31799163,
        "Eccentricity" : 5,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.57105263,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.63333333,
        "shared_name" : "SisterPerpetue",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "SisterPerpetue",
        "SelfLoops" : 0,
        "SUID" : 82050,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 2,
        "AverageShortestPathLength" : 3.14473684,
        "selected" : false,
        "NeighborhoodConnectivity" : 9.5
      },
      "position" : {
        "x" : 187.0190091924539,
        "y" : 236.9166274161489
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82046",
        "ClosenessCentrality" : 0.3015873,
        "Eccentricity" : 5,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.53684211,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Cravatte",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Cravatte",
        "SelfLoops" : 0,
        "SUID" : 82046,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 1,
        "AverageShortestPathLength" : 3.31578947,
        "selected" : false,
        "NeighborhoodConnectivity" : 10.0
      },
      "position" : {
        "x" : 382.074703772532,
        "y" : -81.81197976158546
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82037",
        "ClosenessCentrality" : 0.28787879,
        "Eccentricity" : 5,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.50526316,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Gribier",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Gribier",
        "SelfLoops" : 0,
        "SUID" : 82037,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 1,
        "AverageShortestPathLength" : 3.47368421,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.0
      },
      "position" : {
        "x" : -1.2156557245382942,
        "y" : -214.25990151451515
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82031",
        "ClosenessCentrality" : 0.33480176,
        "Eccentricity" : 5,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.60263158,
        "Stress" : 6,
        "TopologicalCoefficient" : 0.57142857,
        "shared_name" : "Magnon",
        "BetweennessCentrality" : 2.1721E-4,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Magnon",
        "SelfLoops" : 0,
        "SUID" : 82031,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 2,
        "AverageShortestPathLength" : 2.98684211,
        "selected" : false,
        "NeighborhoodConnectivity" : 9.0
      },
      "position" : {
        "x" : 110.43594034479764,
        "y" : 16.191651830211413
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82014",
        "ClosenessCentrality" : 0.3015873,
        "Eccentricity" : 5,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.53684211,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Champtercier",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Champtercier",
        "SelfLoops" : 0,
        "SUID" : 82014,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 1,
        "AverageShortestPathLength" : 3.31578947,
        "selected" : false,
        "NeighborhoodConnectivity" : 10.0
      },
      "position" : {
        "x" : 309.02271993921903,
        "y" : -196.29331826256202
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82008",
        "ClosenessCentrality" : 0.3015873,
        "Eccentricity" : 5,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.53684211,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Monsieur Geborand",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Monsieur Geborand",
        "SelfLoops" : 0,
        "SUID" : 82008,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 1,
        "AverageShortestPathLength" : 3.31578947,
        "selected" : false,
        "NeighborhoodConnectivity" : 10.0
      },
      "position" : {
        "x" : 373.4916425542703,
        "y" : -208.6664566902964
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82003",
        "ClosenessCentrality" : 0.25675676,
        "Eccentricity" : 5,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.42105263,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Jondrette",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Jondrette",
        "SelfLoops" : 0,
        "SUID" : 82003,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 1,
        "AverageShortestPathLength" : 3.89473684,
        "selected" : false,
        "NeighborhoodConnectivity" : 2.0
      },
      "position" : {
        "x" : 162.62391336725858,
        "y" : -265.1757645516245
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81994",
        "ClosenessCentrality" : 0.39583333,
        "Eccentricity" : 4,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.69473684,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.73611111,
        "shared_name" : "Woman1",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Woman1",
        "SelfLoops" : 0,
        "SUID" : 81994,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 2,
        "AverageShortestPathLength" : 2.52631579,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.5
      },
      "position" : {
        "x" : 30.32919692993164,
        "y" : 62.633710894271786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81985",
        "ClosenessCentrality" : 0.3153527,
        "Eccentricity" : 5,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.56578947,
        "Stress" : 4,
        "TopologicalCoefficient" : 0.57142857,
        "shared_name" : "MadamePontmercy",
        "BetweennessCentrality" : 3.5088E-4,
        "NumberOfUndirectedEdges" : 0,
        "name" : "MadamePontmercy",
        "SelfLoops" : 0,
        "SUID" : 81985,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 2,
        "AverageShortestPathLength" : 3.17105263,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.0
      },
      "position" : {
        "x" : -341.95720235539767,
        "y" : 1.3373885245473502
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81983",
        "ClosenessCentrality" : 0.41304348,
        "Eccentricity" : 4,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.71578947,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.37984496,
        "shared_name" : "BaptistineMyrie",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "BaptistineMyrie",
        "SelfLoops" : 0,
        "SUID" : 81983,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 3,
        "AverageShortestPathLength" : 2.42105263,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.33333333
      },
      "position" : {
        "x" : 263.58394441987593,
        "y" : 1.6311083831937783
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81980",
        "ClosenessCentrality" : 0.4021164,
        "Eccentricity" : 4,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.70263158,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.56140351,
        "shared_name" : "Woman2",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Woman2",
        "SelfLoops" : 0,
        "SUID" : 81980,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 3,
        "AverageShortestPathLength" : 2.48684211,
        "selected" : false,
        "NeighborhoodConnectivity" : 21.33333333
      },
      "position" : {
        "x" : -12.303729455007044,
        "y" : 182.50156737281395
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81969",
        "ClosenessCentrality" : 0.34234234,
        "Eccentricity" : 4,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.61578947,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.54545455,
        "shared_name" : "Child1",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Child1",
        "SelfLoops" : 0,
        "SUID" : 81969,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 2,
        "AverageShortestPathLength" : 2.92105263,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.0
      },
      "position" : {
        "x" : -111.2826723261008,
        "y" : -296.0982193856089
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81962",
        "ClosenessCentrality" : 0.41304348,
        "Eccentricity" : 4,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.71578947,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.37984496,
        "shared_name" : "MadameMagloire",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "MadameMagloire",
        "SelfLoops" : 0,
        "SUID" : 81962,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 3,
        "AverageShortestPathLength" : 2.42105263,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.33333333
      },
      "position" : {
        "x" : 118.30610330866483,
        "y" : -77.02381753014015
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81948",
        "ClosenessCentrality" : 0.3015873,
        "Eccentricity" : 5,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.53684211,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Napoleon",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Napoleon",
        "SelfLoops" : 0,
        "SUID" : 81948,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 1,
        "AverageShortestPathLength" : 3.31578947,
        "selected" : false,
        "NeighborhoodConnectivity" : 10.0
      },
      "position" : {
        "x" : 363.13738687800077,
        "y" : -141.56080483482765
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81946",
        "ClosenessCentrality" : 0.3015873,
        "Eccentricity" : 5,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.53684211,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "CountessDeLo",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "CountessDeLo",
        "SelfLoops" : 0,
        "SUID" : 81946,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 1,
        "AverageShortestPathLength" : 3.31578947,
        "selected" : false,
        "NeighborhoodConnectivity" : 10.0
      },
      "position" : {
        "x" : 239.48951395319608,
        "y" : -280.5461258797495
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81940",
        "ClosenessCentrality" : 0.35185185,
        "Eccentricity" : 4,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.63157895,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.66666667,
        "shared_name" : "Anzelma",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Anzelma",
        "SelfLoops" : 0,
        "SUID" : 81940,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 3,
        "AverageShortestPathLength" : 2.84210526,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.66666667
      },
      "position" : {
        "x" : 96.04719217585233,
        "y" : -39.839277735218275
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81937",
        "ClosenessCentrality" : 0.28464419,
        "Eccentricity" : 5,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.49736842,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "MotherPlutarch",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "MotherPlutarch",
        "SelfLoops" : 0,
        "SUID" : 81937,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 1,
        "AverageShortestPathLength" : 3.51315789,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.0
      },
      "position" : {
        "x" : -220.21977559758517,
        "y" : -341.3898758797495
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81927",
        "ClosenessCentrality" : 0.35185185,
        "Eccentricity" : 4,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.63157895,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.65,
        "shared_name" : "BaronessDeThenard",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "BaronessDeThenard",
        "SelfLoops" : 0,
        "SUID" : 81927,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 2,
        "AverageShortestPathLength" : 2.84210526,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.0
      },
      "position" : {
        "x" : -26.148272912038294,
        "y" : -142.41599892662452
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81916",
        "ClosenessCentrality" : 0.39790576,
        "Eccentricity" : 4,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.69736842,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.54054054,
        "shared_name" : "MotherInnocent",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "MotherInnocent",
        "SelfLoops" : 0,
        "SUID" : 81916,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 2,
        "AverageShortestPathLength" : 2.51315789,
        "selected" : false,
        "NeighborhoodConnectivity" : 20.0
      },
      "position" : {
        "x" : -240.61681132246483,
        "y" : 45.14158610531655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81912",
        "ClosenessCentrality" : 0.34080717,
        "Eccentricity" : 5,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.61315789,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.49579832,
        "shared_name" : "Favourite",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Favourite",
        "SelfLoops" : 0,
        "SUID" : 81912,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 7,
        "AverageShortestPathLength" : 2.93421053,
        "selected" : false,
        "NeighborhoodConnectivity" : 8.42857143
      },
      "position" : {
        "x" : 116.05529459284452,
        "y" : 349.41734457923485
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81903",
        "ClosenessCentrality" : 0.46060606,
        "Eccentricity" : 4,
        "Degree" : 11,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.49090909,
        "Radiality" : 0.76578947,
        "Stress" : 606,
        "TopologicalCoefficient" : 0.24475524,
        "shared_name" : "MadameThenardier",
        "BetweennessCentrality" : 0.02900242,
        "NumberOfUndirectedEdges" : 0,
        "name" : "MadameThenardier",
        "SelfLoops" : 0,
        "SUID" : 81903,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 11,
        "AverageShortestPathLength" : 2.17105263,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.81818182
      },
      "position" : {
        "x" : 2.552852498352305,
        "y" : 110.08216055291824
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81894",
        "ClosenessCentrality" : 0.40425532,
        "Eccentricity" : 4,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.70526316,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.31481481,
        "shared_name" : "Chenildieu",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Chenildieu",
        "SelfLoops" : 0,
        "SUID" : 81894,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 6,
        "AverageShortestPathLength" : 2.47368421,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.33333333
      },
      "position" : {
        "x" : -215.75729123170578,
        "y" : 355.9467712579811
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81887",
        "ClosenessCentrality" : 0.40425532,
        "Eccentricity" : 4,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.70526316,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.31481481,
        "shared_name" : "Champmathieu",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Champmathieu",
        "SelfLoops" : 0,
        "SUID" : 81887,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 6,
        "AverageShortestPathLength" : 2.47368421,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.33333333
      },
      "position" : {
        "x" : -140.0033754511008,
        "y" : 137.75144911719872
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81885",
        "ClosenessCentrality" : 0.48101266,
        "Eccentricity" : 3,
        "Degree" : 15,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.60952381,
        "Radiality" : 0.78421053,
        "Stress" : 1226,
        "TopologicalCoefficient" : 0.25818182,
        "shared_name" : "Enjolras",
        "BetweennessCentrality" : 0.04255336,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Enjolras",
        "SelfLoops" : 0,
        "SUID" : 81885,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 15,
        "AverageShortestPathLength" : 2.07894737,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.2
      },
      "position" : {
        "x" : -132.8251527948508,
        "y" : -85.78068398521827
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81883",
        "ClosenessCentrality" : 0.39583333,
        "Eccentricity" : 4,
        "Degree" : 11,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.45454545,
        "Radiality" : 0.69473684,
        "Stress" : 246,
        "TopologicalCoefficient" : 0.31818182,
        "shared_name" : "Eponine",
        "BetweennessCentrality" : 0.01148755,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Eponine",
        "SelfLoops" : 0,
        "SUID" : 81883,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 11,
        "AverageShortestPathLength" : 2.52631579,
        "selected" : false,
        "NeighborhoodConnectivity" : 10.81818182
      },
      "position" : {
        "x" : -25.58085958196017,
        "y" : -97.8012223152964
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81873",
        "ClosenessCentrality" : 0.40425532,
        "Eccentricity" : 4,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.70526316,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.31481481,
        "shared_name" : "Cochepaille",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Cochepaille",
        "SelfLoops" : 0,
        "SUID" : 81873,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 6,
        "AverageShortestPathLength" : 2.47368421,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.33333333
      },
      "position" : {
        "x" : -98.4225649042258,
        "y" : 233.88685751868798
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81869",
        "ClosenessCentrality" : 0.3438914,
        "Eccentricity" : 4,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.61842105,
        "Stress" : 280,
        "TopologicalCoefficient" : 0.5,
        "shared_name" : "MadameBurgon",
        "BetweennessCentrality" : 0.02631579,
        "NumberOfUndirectedEdges" : 0,
        "name" : "MadameBurgon",
        "SelfLoops" : 0,
        "SUID" : 81869,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 2,
        "AverageShortestPathLength" : 2.90789474,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.5
      },
      "position" : {
        "x" : 51.00916727350858,
        "y" : -249.81303261803077
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81867",
        "ClosenessCentrality" : 0.36538462,
        "Eccentricity" : 4,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.65263158,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.42307692,
        "shared_name" : "LieutenantTheoduleGillenormand",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "LieutenantTheoduleGillenormand",
        "SelfLoops" : 0,
        "SUID" : 81867,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 4,
        "AverageShortestPathLength" : 2.73684211,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.0
      },
      "position" : {
        "x" : -158.21733419133517,
        "y" : 80.38257742835594
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81865",
        "ClosenessCentrality" : 0.44186047,
        "Eccentricity" : 4,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.42857143,
        "Radiality" : 0.74736842,
        "Stress" : 612,
        "TopologicalCoefficient" : 0.23214286,
        "shared_name" : "MademoiselleGillenormand",
        "BetweennessCentrality" : 0.04759893,
        "NumberOfUndirectedEdges" : 0,
        "name" : "MademoiselleGillenormand",
        "SelfLoops" : 0,
        "SUID" : 81865,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 7,
        "AverageShortestPathLength" : 2.26315789,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.42857143
      },
      "position" : {
        "x" : -291.79486083984375,
        "y" : -21.056556635528693
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81863",
        "ClosenessCentrality" : 0.39378238,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.69210526,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Gervais",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Gervais",
        "SelfLoops" : 0,
        "SUID" : 81863,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 1,
        "AverageShortestPathLength" : 2.53947368,
        "selected" : false,
        "NeighborhoodConnectivity" : 36.0
      },
      "position" : {
        "x" : -72.54384175969454,
        "y" : 275.1520705313833
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81860",
        "ClosenessCentrality" : 0.4021164,
        "Eccentricity" : 4,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.33333333,
        "Radiality" : 0.70263158,
        "Stress" : 382,
        "TopologicalCoefficient" : 0.38194444,
        "shared_name" : "Fauchelevent",
        "BetweennessCentrality" : 0.02649123,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Fauchelevent",
        "SelfLoops" : 0,
        "SUID" : 81860,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 4,
        "AverageShortestPathLength" : 2.48684211,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.0
      },
      "position" : {
        "x" : -40.403705040944544,
        "y" : -63.34351967857765
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81857",
        "ClosenessCentrality" : 0.39378238,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.69210526,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "MaubertIsabeau",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "MaubertIsabeau",
        "SelfLoops" : 0,
        "SUID" : 81857,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 1,
        "AverageShortestPathLength" : 2.53947368,
        "selected" : false,
        "NeighborhoodConnectivity" : 36.0
      },
      "position" : {
        "x" : 96.14324625300077,
        "y" : 201.0131545157583
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81855",
        "ClosenessCentrality" : 0.41304348,
        "Eccentricity" : 4,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.71578947,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.57954545,
        "shared_name" : "Marguerite",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Marguerite",
        "SelfLoops" : 0,
        "SUID" : 81855,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 2,
        "AverageShortestPathLength" : 2.42105263,
        "selected" : false,
        "NeighborhoodConnectivity" : 25.5
      },
      "position" : {
        "x" : 141.66282327936796,
        "y" : 154.85138560248924
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81850",
        "ClosenessCentrality" : 0.41758242,
        "Eccentricity" : 4,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.66666667,
        "Radiality" : 0.72105263,
        "Stress" : 250,
        "TopologicalCoefficient" : 0.39772727,
        "shared_name" : "SisterSimplice",
        "BetweennessCentrality" : 0.0086403,
        "NumberOfUndirectedEdges" : 0,
        "name" : "SisterSimplice",
        "SelfLoops" : 0,
        "SUID" : 81850,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 4,
        "AverageShortestPathLength" : 2.39473684,
        "selected" : false,
        "NeighborhoodConnectivity" : 17.5
      },
      "position" : {
        "x" : 115.98738098144531,
        "y" : 108.95541937507662
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81845",
        "ClosenessCentrality" : 0.34234234,
        "Eccentricity" : 4,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.61578947,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.54545455,
        "shared_name" : "Child2",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Child2",
        "SelfLoops" : 0,
        "SUID" : 81845,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 2,
        "AverageShortestPathLength" : 2.92105263,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.0
      },
      "position" : {
        "x" : -22.948077599538294,
        "y" : -295.3269791512339
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81843",
        "ClosenessCentrality" : 0.475,
        "Eccentricity" : 3,
        "Degree" : 13,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.76923077,
        "Radiality" : 0.77894737,
        "Stress" : 878,
        "TopologicalCoefficient" : 0.26293706,
        "shared_name" : "LAigleDeMeauxBossuet ",
        "BetweennessCentrality" : 0.03075365,
        "NumberOfUndirectedEdges" : 0,
        "name" : "LAigleDeMeauxBossuet ",
        "SelfLoops" : 0,
        "SUID" : 81843,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 13,
        "AverageShortestPathLength" : 2.10526316,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.46153846
      },
      "position" : {
        "x" : -185.41893331242892,
        "y" : -78.24911355064796
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81840",
        "ClosenessCentrality" : 0.34080717,
        "Eccentricity" : 5,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.61315789,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.49579832,
        "shared_name" : "Fameuil",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Fameuil",
        "SelfLoops" : 0,
        "SUID" : 81840,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 7,
        "AverageShortestPathLength" : 2.93421053,
        "selected" : false,
        "NeighborhoodConnectivity" : 8.42857143
      },
      "position" : {
        "x" : 105.86358316706327,
        "y" : 288.32637930823876
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81837",
        "ClosenessCentrality" : 0.4021164,
        "Eccentricity" : 4,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.70263158,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.56140351,
        "shared_name" : "Toussaint",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Toussaint",
        "SelfLoops" : 0,
        "SUID" : 81837,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 3,
        "AverageShortestPathLength" : 2.48684211,
        "selected" : false,
        "NeighborhoodConnectivity" : 21.33333333
      },
      "position" : {
        "x" : -122.71959249211642,
        "y" : 182.64045477820946
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81835",
        "ClosenessCentrality" : 0.46341463,
        "Eccentricity" : 3,
        "Degree" : 10,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.8,
        "Radiality" : 0.76842105,
        "Stress" : 226,
        "TopologicalCoefficient" : 0.27592593,
        "shared_name" : "Babet",
        "BetweennessCentrality" : 0.00496038,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Babet",
        "SelfLoops" : 0,
        "SUID" : 81835,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 10,
        "AverageShortestPathLength" : 2.15789474,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.9
      },
      "position" : {
        "x" : 49.09803446100858,
        "y" : -35.17420815514015
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81834",
        "ClosenessCentrality" : 0.38,
        "Eccentricity" : 4,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.9047619,
        "Radiality" : 0.67368421,
        "Stress" : 20,
        "TopologicalCoefficient" : 0.41904762,
        "shared_name" : "Brujon",
        "BetweennessCentrality" : 4.386E-4,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Brujon",
        "SelfLoops" : 0,
        "SUID" : 81834,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 7,
        "AverageShortestPathLength" : 2.63157895,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.57142857
      },
      "position" : {
        "x" : 25.61347635553983,
        "y" : -128.34104775474952
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81832",
        "ClosenessCentrality" : 0.3015873,
        "Eccentricity" : 5,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.53684211,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "OldMan",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "OldMan",
        "SelfLoops" : 0,
        "SUID" : 81832,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 1,
        "AverageShortestPathLength" : 3.31578947,
        "selected" : false,
        "NeighborhoodConnectivity" : 10.0
      },
      "position" : {
        "x" : 298.50828560160306,
        "y" : -255.5828385262339
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81830",
        "ClosenessCentrality" : 0.39175258,
        "Eccentricity" : 4,
        "Degree" : 9,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.61111111,
        "Radiality" : 0.68947368,
        "Stress" : 696,
        "TopologicalCoefficient" : 0.28431373,
        "shared_name" : "FelixTholomyes",
        "BetweennessCentrality" : 0.04062935,
        "NumberOfUndirectedEdges" : 0,
        "name" : "FelixTholomyes",
        "SelfLoops" : 0,
        "SUID" : 81830,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 9,
        "AverageShortestPathLength" : 2.55263158,
        "selected" : false,
        "NeighborhoodConnectivity" : 9.66666667
      },
      "position" : {
        "x" : -16.08848897649142,
        "y" : 241.63189078284813
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81826",
        "ClosenessCentrality" : 0.46341463,
        "Eccentricity" : 3,
        "Degree" : 10,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.8,
        "Radiality" : 0.76842105,
        "Stress" : 226,
        "TopologicalCoefficient" : 0.27592593,
        "shared_name" : "Gueulemer",
        "BetweennessCentrality" : 0.00496038,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Gueulemer",
        "SelfLoops" : 0,
        "SUID" : 81826,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 10,
        "AverageShortestPathLength" : 2.15789474,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.9
      },
      "position" : {
        "x" : -76.4519176152497,
        "y" : 93.03279695893842
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81823",
        "ClosenessCentrality" : 0.39583333,
        "Eccentricity" : 4,
        "Degree" : 11,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.69090909,
        "Radiality" : 0.69473684,
        "Stress" : 518,
        "TopologicalCoefficient" : 0.38292011,
        "shared_name" : "Mabeuf",
        "BetweennessCentrality" : 0.02766124,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Mabeuf",
        "SelfLoops" : 0,
        "SUID" : 81823,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 11,
        "AverageShortestPathLength" : 2.52631579,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.72727273
      },
      "position" : {
        "x" : -170.6059145136008,
        "y" : -194.11500405357765
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81821",
        "ClosenessCentrality" : 0.35680751,
        "Eccentricity" : 4,
        "Degree" : 9,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.63947368,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.55092593,
        "shared_name" : "JeanProuvaire",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "JeanProuvaire",
        "SelfLoops" : 0,
        "SUID" : 81821,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 9,
        "AverageShortestPathLength" : 2.80263158,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.22222222
      },
      "position" : {
        "x" : -216.99602071477267,
        "y" : -210.64591836021827
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81819",
        "ClosenessCentrality" : 0.39378238,
        "Eccentricity" : 4,
        "Degree" : 12,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.86363636,
        "Radiality" : 0.69210526,
        "Stress" : 126,
        "TopologicalCoefficient" : 0.3984375,
        "shared_name" : "Bahorel",
        "BetweennessCentrality" : 0.00218549,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Bahorel",
        "SelfLoops" : 0,
        "SUID" : 81819,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 12,
        "AverageShortestPathLength" : 2.53947368,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.75
      },
      "position" : {
        "x" : -188.0231508417258,
        "y" : -136.37565468834327
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81817",
        "ClosenessCentrality" : 0.39175258,
        "Eccentricity" : 4,
        "Degree" : 11,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.92727273,
        "Radiality" : 0.68947368,
        "Stress" : 80,
        "TopologicalCoefficient" : 0.41761364,
        "shared_name" : "Combeferre",
        "BetweennessCentrality" : 0.00125015,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Combeferre",
        "SelfLoops" : 0,
        "SUID" : 81817,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 11,
        "AverageShortestPathLength" : 2.55263158,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.36363636
      },
      "position" : {
        "x" : -242.50975362492892,
        "y" : -145.46708535240577
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81815",
        "ClosenessCentrality" : 0.5170068,
        "Eccentricity" : 3,
        "Degree" : 16,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.40833333,
        "Radiality" : 0.81315789,
        "Stress" : 1290,
        "TopologicalCoefficient" : 0.18945313,
        "shared_name" : "Thenardier",
        "BetweennessCentrality" : 0.07490122,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Thenardier",
        "SelfLoops" : 0,
        "SUID" : 81815,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 16,
        "AverageShortestPathLength" : 1.93421053,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.1875
      },
      "position" : {
        "x" : 332.8627696837776,
        "y" : 92.30407895658894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81814",
        "ClosenessCentrality" : 0.37254902,
        "Eccentricity" : 4,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.33333333,
        "Radiality" : 0.66315789,
        "Stress" : 146,
        "TopologicalCoefficient" : 0.4137931,
        "shared_name" : "Pontmercy",
        "BetweennessCentrality" : 0.00692544,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Pontmercy",
        "SelfLoops" : 0,
        "SUID" : 81814,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 3,
        "AverageShortestPathLength" : 2.68421053,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.33333333
      },
      "position" : {
        "x" : -302.2317943242341,
        "y" : 56.314207043960636
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81812",
        "ClosenessCentrality" : 0.35849057,
        "Eccentricity" : 4,
        "Degree" : 10,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.93333333,
        "Radiality" : 0.64210526,
        "Stress" : 6,
        "TopologicalCoefficient" : 0.52083333,
        "shared_name" : "Grantaire",
        "BetweennessCentrality" : 1.5038E-4,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Grantaire",
        "SelfLoops" : 0,
        "SUID" : 81812,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 10,
        "AverageShortestPathLength" : 2.78947368,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.5
      },
      "position" : {
        "x" : -166.53688375188204,
        "y" : -231.0437760262339
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81809",
        "ClosenessCentrality" : 0.45238095,
        "Eccentricity" : 4,
        "Degree" : 10,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.71111111,
        "Radiality" : 0.75789474,
        "Stress" : 210,
        "TopologicalCoefficient" : 0.27843137,
        "shared_name" : "Claquesous",
        "BetweennessCentrality" : 0.0048618,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Claquesous",
        "SelfLoops" : 0,
        "SUID" : 81809,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 10,
        "AverageShortestPathLength" : 2.21052632,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.2
      },
      "position" : {
        "x" : -95.36066529351628,
        "y" : 42.52465813699353
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81808",
        "ClosenessCentrality" : 0.45783133,
        "Eccentricity" : 3,
        "Degree" : 9,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.83333333,
        "Radiality" : 0.76315789,
        "Stress" : 178,
        "TopologicalCoefficient" : 0.29140461,
        "shared_name" : "Montparnasse",
        "BetweennessCentrality" : 0.00387383,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Montparnasse",
        "SelfLoops" : 0,
        "SUID" : 81808,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 9,
        "AverageShortestPathLength" : 2.18421053,
        "selected" : true,
        "NeighborhoodConnectivity" : 15.44444444
      },
      "position" : {
        "x" : -158.06520080566406,
        "y" : -22.772317787155345
      },
      "selected" : true
    }, {
      "data" : {
        "id" : "81805",
        "ClosenessCentrality" : 0.39378238,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.69210526,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Scaufflaire",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Scaufflaire",
        "SelfLoops" : 0,
        "SUID" : 81805,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 1,
        "AverageShortestPathLength" : 2.53947368,
        "selected" : false,
        "NeighborhoodConnectivity" : 36.0
      },
      "position" : {
        "x" : -229.85740987492892,
        "y" : 107.37869406653954
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81803",
        "ClosenessCentrality" : 0.34080717,
        "Eccentricity" : 5,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.61315789,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.49579832,
        "shared_name" : "Blacheville",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Blacheville",
        "SelfLoops" : 0,
        "SUID" : 81803,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 7,
        "AverageShortestPathLength" : 2.93421053,
        "selected" : false,
        "NeighborhoodConnectivity" : 8.42857143
      },
      "position" : {
        "x" : 47.53040750788358,
        "y" : 310.3739485831411
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81800",
        "ClosenessCentrality" : 0.47798742,
        "Eccentricity" : 4,
        "Degree" : 11,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.38181818,
        "Radiality" : 0.78157895,
        "Stress" : 516,
        "TopologicalCoefficient" : 0.20338983,
        "shared_name" : "Cosette",
        "BetweennessCentrality" : 0.02379625,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Cosette",
        "SelfLoops" : 0,
        "SUID" : 81800,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 11,
        "AverageShortestPathLength" : 2.09210526,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.0
      },
      "position" : {
        "x" : 147.61885264842218,
        "y" : -190.27267456054688
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81799",
        "ClosenessCentrality" : 0.53146853,
        "Eccentricity" : 3,
        "Degree" : 19,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.33333333,
        "Radiality" : 0.82368421,
        "Stress" : 2580,
        "TopologicalCoefficient" : 0.18022329,
        "shared_name" : "Marius",
        "BetweennessCentrality" : 0.13203249,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Marius",
        "SelfLoops" : 0,
        "SUID" : 81799,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 19,
        "AverageShortestPathLength" : 1.88157895,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.89473684
      },
      "position" : {
        "x" : -535.3159806797947,
        "y" : -150.67348493450902
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81797",
        "ClosenessCentrality" : 0.46060606,
        "Eccentricity" : 4,
        "Degree" : 15,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.31428571,
        "Radiality" : 0.76578947,
        "Stress" : 1878,
        "TopologicalCoefficient" : 0.196,
        "shared_name" : "Fantine",
        "BetweennessCentrality" : 0.12964454,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Fantine",
        "SelfLoops" : 0,
        "SUID" : 81797,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 15,
        "AverageShortestPathLength" : 2.17105263,
        "selected" : false,
        "NeighborhoodConnectivity" : 9.8
      },
      "position" : {
        "x" : 472.4757080078125,
        "y" : -135.43045043945312
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81795",
        "ClosenessCentrality" : 0.34080717,
        "Eccentricity" : 5,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.61315789,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.49579832,
        "shared_name" : "Dahlia",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Dahlia",
        "SelfLoops" : 0,
        "SUID" : 81795,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 7,
        "AverageShortestPathLength" : 2.93421053,
        "selected" : false,
        "NeighborhoodConnectivity" : 8.42857143
      },
      "position" : {
        "x" : 6.265301306711706,
        "y" : 382.71519614173485
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81793",
        "ClosenessCentrality" : 0.42937853,
        "Eccentricity" : 4,
        "Degree" : 10,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.06666667,
        "Radiality" : 0.73421053,
        "Stress" : 1680,
        "TopologicalCoefficient" : 0.11666667,
        "shared_name" : "BishopCharles-Francois-BienvenuMyriel",
        "BetweennessCentrality" : 0.17684211,
        "NumberOfUndirectedEdges" : 0,
        "name" : "BishopCharles-Francois-BienvenuMyriel",
        "SelfLoops" : 0,
        "SUID" : 81793,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 10,
        "AverageShortestPathLength" : 2.32894737,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.9
      },
      "position" : {
        "x" : 232.512074072825,
        "y" : -112.43531655357765
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81792",
        "ClosenessCentrality" : 0.3015873,
        "Eccentricity" : 5,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.53684211,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Count",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Count",
        "SelfLoops" : 0,
        "SUID" : 81792,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 1,
        "AverageShortestPathLength" : 3.31578947,
        "selected" : false,
        "NeighborhoodConnectivity" : 10.0
      },
      "position" : {
        "x" : 335.7190252141824,
        "y" : -29.793211451038587
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81790",
        "ClosenessCentrality" : 0.5170068,
        "Eccentricity" : 3,
        "Degree" : 17,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.32352941,
        "Radiality" : 0.81315789,
        "Stress" : 1380,
        "TopologicalCoefficient" : 0.17371324,
        "shared_name" : "Javert",
        "BetweennessCentrality" : 0.05433156,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Javert",
        "SelfLoops" : 0,
        "SUID" : 81790,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 17,
        "AverageShortestPathLength" : 1.93421053,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.11764706
      },
      "position" : {
        "x" : 435.90504261524967,
        "y" : 267.11966330465685
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81788",
        "ClosenessCentrality" : 0.4,
        "Eccentricity" : 4,
        "Degree" : 13,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.75641026,
        "Radiality" : 0.7,
        "Stress" : 192,
        "TopologicalCoefficient" : 0.36877828,
        "shared_name" : "Courfeyrac",
        "BetweennessCentrality" : 0.00526703,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Courfeyrac",
        "SelfLoops" : 0,
        "SUID" : 81788,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 13,
        "AverageShortestPathLength" : 2.5,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.53846154
      },
      "position" : {
        "x" : -134.5258363886008,
        "y" : -144.92213295982765
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81787",
        "ClosenessCentrality" : 0.35348837,
        "Eccentricity" : 4,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.63421053,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.57738095,
        "shared_name" : "MadameHucheloup",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "MadameHucheloup",
        "SelfLoops" : 0,
        "SUID" : 81787,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 7,
        "AverageShortestPathLength" : 2.82894737,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.85714286
      },
      "position" : {
        "x" : -253.59843770696017,
        "y" : -185.3527359871714
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81785",
        "ClosenessCentrality" : 0.51351351,
        "Eccentricity" : 3,
        "Degree" : 22,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.35497835,
        "Radiality" : 0.81052632,
        "Stress" : 2706,
        "TopologicalCoefficient" : 0.20175439,
        "shared_name" : "Gavroche",
        "BetweennessCentrality" : 0.1651125,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Gavroche",
        "SelfLoops" : 0,
        "SUID" : 81785,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 22,
        "AverageShortestPathLength" : 1.94736842,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.54545455
      },
      "position" : {
        "x" : -31.152975115463192,
        "y" : -216.36090281932061
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81783",
        "ClosenessCentrality" : 0.42696629,
        "Eccentricity" : 4,
        "Degree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.64285714,
        "Radiality" : 0.73157895,
        "Stress" : 100,
        "TopologicalCoefficient" : 0.27840909,
        "shared_name" : "Bamatabois",
        "BetweennessCentrality" : 0.00804094,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Bamatabois",
        "SelfLoops" : 0,
        "SUID" : 81783,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 8,
        "AverageShortestPathLength" : 2.34210526,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.25
      },
      "position" : {
        "x" : -67.6328920526633,
        "y" : 180.75913382484032
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81781",
        "ClosenessCentrality" : 0.40425532,
        "Eccentricity" : 4,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.70526316,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.31481481,
        "shared_name" : "Judge",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Judge",
        "SelfLoops" : 0,
        "SUID" : 81781,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 6,
        "AverageShortestPathLength" : 2.47368421,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.33333333
      },
      "position" : {
        "x" : -338.44459180934456,
        "y" : 300.3294151177238
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81780",
        "ClosenessCentrality" : 0.40425532,
        "Eccentricity" : 4,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.70526316,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.31481481,
        "shared_name" : "Brevet",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Brevet",
        "SelfLoops" : 0,
        "SUID" : 81780,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 6,
        "AverageShortestPathLength" : 2.47368421,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.33333333
      },
      "position" : {
        "x" : -342.0592041015625,
        "y" : 210.18341258494561
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81778",
        "ClosenessCentrality" : 0.39175258,
        "Eccentricity" : 4,
        "Degree" : 11,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.92727273,
        "Radiality" : 0.68947368,
        "Stress" : 80,
        "TopologicalCoefficient" : 0.41761364,
        "shared_name" : "Feuilly",
        "BetweennessCentrality" : 0.00125015,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Feuilly",
        "SelfLoops" : 0,
        "SUID" : 81778,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 11,
        "AverageShortestPathLength" : 2.55263158,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.36363636
      },
      "position" : {
        "x" : -109.96977559758517,
        "y" : -191.40894936607765
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81777",
        "ClosenessCentrality" : 0.39378238,
        "Eccentricity" : 4,
        "Degree" : 12,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.86363636,
        "Radiality" : 0.69210526,
        "Stress" : 126,
        "TopologicalCoefficient" : 0.3984375,
        "shared_name" : "Joly",
        "BetweennessCentrality" : 0.00218549,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Joly",
        "SelfLoops" : 0,
        "SUID" : 81777,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 12,
        "AverageShortestPathLength" : 2.53947368,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.75
      },
      "position" : {
        "x" : -233.72825948430392,
        "y" : -97.82047890709327
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81775",
        "ClosenessCentrality" : 0.34080717,
        "Eccentricity" : 5,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.61315789,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.49579832,
        "shared_name" : "Listolier",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Listolier",
        "SelfLoops" : 0,
        "SUID" : 81775,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 7,
        "AverageShortestPathLength" : 2.93421053,
        "selected" : false,
        "NeighborhoodConnectivity" : 8.42857143
      },
      "position" : {
        "x" : 66.16001566218046,
        "y" : 385.26463461829735
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81774",
        "ClosenessCentrality" : 0.34080717,
        "Eccentricity" : 5,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.61315789,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.49579832,
        "shared_name" : "Zephine",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Zephine",
        "SelfLoops" : 0,
        "SUID" : 81774,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 7,
        "AverageShortestPathLength" : 2.93421053,
        "selected" : false,
        "NeighborhoodConnectivity" : 8.42857143
      },
      "position" : {
        "x" : -18.02177755071017,
        "y" : 332.2682662100942
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81772",
        "ClosenessCentrality" : 0.6440678,
        "Eccentricity" : 3,
        "Degree" : 36,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.12063492,
        "Radiality" : 0.88947368,
        "Stress" : 7270,
        "TopologicalCoefficient" : 0.10708535,
        "shared_name" : "JeanValjean",
        "BetweennessCentrality" : 0.56998905,
        "NumberOfUndirectedEdges" : 0,
        "name" : "JeanValjean",
        "SelfLoops" : 0,
        "SUID" : 81772,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 36,
        "AverageShortestPathLength" : 1.55263158,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.52777778
      },
      "position" : {
        "x" : 577.5846823984682,
        "y" : -31.690881497665853
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81771",
        "ClosenessCentrality" : 0.44186047,
        "Eccentricity" : 4,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.47619048,
        "Radiality" : 0.74736842,
        "Stress" : 358,
        "TopologicalCoefficient" : 0.23323615,
        "shared_name" : "Gillenormand",
        "BetweennessCentrality" : 0.02021062,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Gillenormand",
        "SelfLoops" : 0,
        "SUID" : 81771,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 7,
        "AverageShortestPathLength" : 2.26315789,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.57142857
      },
      "position" : {
        "x" : -343.00452048239123,
        "y" : -76.77521140035998
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "82098",
        "source" : "82097",
        "target" : "81865",
        "EdgeBetweenness" : 152.0,
        "shared_name" : "MademoiselleVaubois (interacts with) MademoiselleGillenormand",
        "shared_interaction" : "interacts with",
        "name" : "MademoiselleVaubois (interacts with) MademoiselleGillenormand",
        "interaction" : "interacts with",
        "SUID" : 82098,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82092",
        "source" : "82091",
        "target" : "81772",
        "EdgeBetweenness" : 152.0,
        "shared_name" : "MadameDeR (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "MadameDeR (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 82092,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82059",
        "source" : "82058",
        "target" : "81815",
        "EdgeBetweenness" : 152.0,
        "shared_name" : "Boulatruelle (interacts with) Thenardier",
        "shared_interaction" : "interacts with",
        "name" : "Boulatruelle (interacts with) Thenardier",
        "interaction" : "interacts with",
        "SUID" : 82059,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82051",
        "source" : "82050",
        "target" : "81797",
        "EdgeBetweenness" : 100.75031831,
        "shared_name" : "SisterPerpetue (interacts with) Fantine",
        "shared_interaction" : "interacts with",
        "name" : "SisterPerpetue (interacts with) Fantine",
        "interaction" : "interacts with",
        "SUID" : 82051,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82047",
        "source" : "82046",
        "target" : "81793",
        "EdgeBetweenness" : 152.0,
        "shared_name" : "Cravatte (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "shared_interaction" : "interacts with",
        "name" : "Cravatte (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "interaction" : "interacts with",
        "SUID" : 82047,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82038",
        "source" : "82037",
        "target" : "81860",
        "EdgeBetweenness" : 152.0,
        "shared_name" : "Gribier (interacts with) Fauchelevent",
        "shared_interaction" : "interacts with",
        "name" : "Gribier (interacts with) Fauchelevent",
        "interaction" : "interacts with",
        "SUID" : 82038,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82069",
        "source" : "82031",
        "target" : "81771",
        "EdgeBetweenness" : 64.78784461,
        "shared_name" : "Magnon (interacts with) Gillenormand",
        "shared_interaction" : "interacts with",
        "name" : "Magnon (interacts with) Gillenormand",
        "interaction" : "interacts with",
        "SUID" : 82069,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82032",
        "source" : "82031",
        "target" : "81903",
        "EdgeBetweenness" : 89.68834586,
        "shared_name" : "Magnon (interacts with) MadameThenardier",
        "shared_interaction" : "interacts with",
        "name" : "Magnon (interacts with) MadameThenardier",
        "interaction" : "interacts with",
        "SUID" : 82032,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82015",
        "source" : "82014",
        "target" : "81793",
        "EdgeBetweenness" : 152.0,
        "shared_name" : "Champtercier (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "shared_interaction" : "interacts with",
        "name" : "Champtercier (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "interaction" : "interacts with",
        "SUID" : 82015,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82009",
        "source" : "82008",
        "target" : "81793",
        "EdgeBetweenness" : 152.0,
        "shared_name" : "Monsieur Geborand (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "shared_interaction" : "interacts with",
        "name" : "Monsieur Geborand (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "interaction" : "interacts with",
        "SUID" : 82009,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82081",
        "source" : "81994",
        "target" : "81790",
        "EdgeBetweenness" : 42.52307692,
        "shared_name" : "Woman1 (interacts with) Javert",
        "shared_interaction" : "interacts with",
        "name" : "Woman1 (interacts with) Javert",
        "interaction" : "interacts with",
        "SUID" : 82081,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81995",
        "source" : "81994",
        "target" : "81772",
        "EdgeBetweenness" : 109.47692308,
        "shared_name" : "Woman1 (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Woman1 (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81995,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82002",
        "source" : "81985",
        "target" : "81814",
        "EdgeBetweenness" : 43.475,
        "shared_name" : "MadamePontmercy (interacts with) Pontmercy",
        "shared_interaction" : "interacts with",
        "name" : "MadamePontmercy (interacts with) Pontmercy",
        "interaction" : "interacts with",
        "SUID" : 82002,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81986",
        "source" : "81985",
        "target" : "81865",
        "EdgeBetweenness" : 112.525,
        "shared_name" : "MadamePontmercy (interacts with) MademoiselleGillenormand",
        "shared_interaction" : "interacts with",
        "name" : "MadamePontmercy (interacts with) MademoiselleGillenormand",
        "interaction" : "interacts with",
        "SUID" : 81986,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82013",
        "source" : "81983",
        "target" : "81793",
        "EdgeBetweenness" : 16.0,
        "shared_name" : "BaptistineMyrie (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "shared_interaction" : "interacts with",
        "name" : "BaptistineMyrie (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "interaction" : "interacts with",
        "SUID" : 82013,
        "Strength" : 8,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82077",
        "source" : "81980",
        "target" : "81790",
        "EdgeBetweenness" : 35.20641026,
        "shared_name" : "Woman2 (interacts with) Javert",
        "shared_interaction" : "interacts with",
        "name" : "Woman2 (interacts with) Javert",
        "interaction" : "interacts with",
        "SUID" : 82077,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81988",
        "source" : "81980",
        "target" : "81772",
        "EdgeBetweenness" : 93.33141026,
        "shared_name" : "Woman2 (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Woman2 (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81988,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81981",
        "source" : "81980",
        "target" : "81800",
        "EdgeBetweenness" : 23.46217949,
        "shared_name" : "Woman2 (interacts with) Cosette",
        "shared_interaction" : "interacts with",
        "name" : "Woman2 (interacts with) Cosette",
        "interaction" : "interacts with",
        "SUID" : 81981,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81970",
        "source" : "81969",
        "target" : "81785",
        "EdgeBetweenness" : 150.0,
        "shared_name" : "Child1 (interacts with) Gavroche",
        "shared_interaction" : "interacts with",
        "name" : "Child1 (interacts with) Gavroche",
        "interaction" : "interacts with",
        "SUID" : 81970,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82079",
        "source" : "81962",
        "target" : "81793",
        "EdgeBetweenness" : 16.0,
        "shared_name" : "MadameMagloire (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "shared_interaction" : "interacts with",
        "name" : "MadameMagloire (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "interaction" : "interacts with",
        "SUID" : 82079,
        "Strength" : 10,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82076",
        "source" : "81962",
        "target" : "81983",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "MadameMagloire (interacts with) BaptistineMyrie",
        "shared_interaction" : "interacts with",
        "name" : "MadameMagloire (interacts with) BaptistineMyrie",
        "interaction" : "interacts with",
        "SUID" : 82076,
        "Strength" : 6,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81949",
        "source" : "81948",
        "target" : "81793",
        "EdgeBetweenness" : 152.0,
        "shared_name" : "Napoleon (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "shared_interaction" : "interacts with",
        "name" : "Napoleon (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "interaction" : "interacts with",
        "SUID" : 81949,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81947",
        "source" : "81946",
        "target" : "81793",
        "EdgeBetweenness" : 152.0,
        "shared_name" : "CountessDeLo (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "shared_interaction" : "interacts with",
        "name" : "CountessDeLo (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "interaction" : "interacts with",
        "SUID" : 81947,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82099",
        "source" : "81940",
        "target" : "81903",
        "EdgeBetweenness" : 50.14285714,
        "shared_name" : "Anzelma (interacts with) MadameThenardier",
        "shared_interaction" : "interacts with",
        "name" : "Anzelma (interacts with) MadameThenardier",
        "interaction" : "interacts with",
        "SUID" : 82099,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82040",
        "source" : "81940",
        "target" : "81883",
        "EdgeBetweenness" : 25.10952381,
        "shared_name" : "Anzelma (interacts with) Eponine",
        "shared_interaction" : "interacts with",
        "name" : "Anzelma (interacts with) Eponine",
        "interaction" : "interacts with",
        "SUID" : 82040,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81941",
        "source" : "81940",
        "target" : "81815",
        "EdgeBetweenness" : 76.74761905,
        "shared_name" : "Anzelma (interacts with) Thenardier",
        "shared_interaction" : "interacts with",
        "name" : "Anzelma (interacts with) Thenardier",
        "interaction" : "interacts with",
        "SUID" : 81941,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81938",
        "source" : "81937",
        "target" : "81823",
        "EdgeBetweenness" : 152.0,
        "shared_name" : "MotherPlutarch (interacts with) Mabeuf",
        "shared_interaction" : "interacts with",
        "name" : "MotherPlutarch (interacts with) Mabeuf",
        "interaction" : "interacts with",
        "SUID" : 81938,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81959",
        "source" : "81927",
        "target" : "81771",
        "EdgeBetweenness" : 42.86190476,
        "shared_name" : "BaronessDeThenard (interacts with) Gillenormand",
        "shared_interaction" : "interacts with",
        "name" : "BaronessDeThenard (interacts with) Gillenormand",
        "interaction" : "interacts with",
        "SUID" : 81959,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81928",
        "source" : "81927",
        "target" : "81799",
        "EdgeBetweenness" : 109.13809524,
        "shared_name" : "BaronessDeThenard (interacts with) Marius",
        "shared_interaction" : "interacts with",
        "name" : "BaronessDeThenard (interacts with) Marius",
        "interaction" : "interacts with",
        "SUID" : 81928,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82034",
        "source" : "81916",
        "target" : "81860",
        "EdgeBetweenness" : 5.0,
        "shared_name" : "MotherInnocent (interacts with) Fauchelevent",
        "shared_interaction" : "interacts with",
        "name" : "MotherInnocent (interacts with) Fauchelevent",
        "interaction" : "interacts with",
        "SUID" : 82034,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81917",
        "source" : "81916",
        "target" : "81772",
        "EdgeBetweenness" : 147.0,
        "shared_name" : "MotherInnocent (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "MotherInnocent (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81917,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82066",
        "source" : "81912",
        "target" : "81830",
        "EdgeBetweenness" : 39.65238095,
        "shared_name" : "Favourite (interacts with) FelixTholomyes",
        "shared_interaction" : "interacts with",
        "name" : "Favourite (interacts with) FelixTholomyes",
        "interaction" : "interacts with",
        "SUID" : 82066,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81991",
        "source" : "81912",
        "target" : "81775",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Favourite (interacts with) Listolier",
        "shared_interaction" : "interacts with",
        "name" : "Favourite (interacts with) Listolier",
        "interaction" : "interacts with",
        "SUID" : 81991,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81957",
        "source" : "81912",
        "target" : "81840",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Favourite (interacts with) Fameuil",
        "shared_interaction" : "interacts with",
        "name" : "Favourite (interacts with) Fameuil",
        "interaction" : "interacts with",
        "SUID" : 81957,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81913",
        "source" : "81912",
        "target" : "81803",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Favourite (interacts with) Blacheville",
        "shared_interaction" : "interacts with",
        "name" : "Favourite (interacts with) Blacheville",
        "interaction" : "interacts with",
        "SUID" : 81913,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82067",
        "source" : "81903",
        "target" : "81797",
        "EdgeBetweenness" : 67.40633223,
        "shared_name" : "MadameThenardier (interacts with) Fantine",
        "shared_interaction" : "interacts with",
        "name" : "MadameThenardier (interacts with) Fantine",
        "interaction" : "interacts with",
        "SUID" : 82067,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81930",
        "source" : "81903",
        "target" : "81772",
        "EdgeBetweenness" : 128.28050254,
        "shared_name" : "MadameThenardier (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "MadameThenardier (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81930,
        "Strength" : 7,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82101",
        "source" : "81894",
        "target" : "81781",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Chenildieu (interacts with) Judge",
        "shared_interaction" : "interacts with",
        "name" : "Chenildieu (interacts with) Judge",
        "interaction" : "interacts with",
        "SUID" : 82101,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82053",
        "source" : "81894",
        "target" : "81780",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Chenildieu (interacts with) Brevet",
        "shared_interaction" : "interacts with",
        "name" : "Chenildieu (interacts with) Brevet",
        "interaction" : "interacts with",
        "SUID" : 82053,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82052",
        "source" : "81894",
        "target" : "81772",
        "EdgeBetweenness" : 132.83333333,
        "shared_name" : "Chenildieu (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Chenildieu (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 82052,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82001",
        "source" : "81894",
        "target" : "81887",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Chenildieu (interacts with) Champmathieu",
        "shared_interaction" : "interacts with",
        "name" : "Chenildieu (interacts with) Champmathieu",
        "interaction" : "interacts with",
        "SUID" : 82001,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81895",
        "source" : "81894",
        "target" : "81783",
        "EdgeBetweenness" : 11.16666667,
        "shared_name" : "Chenildieu (interacts with) Bamatabois",
        "shared_interaction" : "interacts with",
        "name" : "Chenildieu (interacts with) Bamatabois",
        "interaction" : "interacts with",
        "SUID" : 81895,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82073",
        "source" : "81887",
        "target" : "81783",
        "EdgeBetweenness" : 11.16666667,
        "shared_name" : "Champmathieu (interacts with) Bamatabois",
        "shared_interaction" : "interacts with",
        "name" : "Champmathieu (interacts with) Bamatabois",
        "interaction" : "interacts with",
        "SUID" : 82073,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82065",
        "source" : "81887",
        "target" : "81781",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Champmathieu (interacts with) Judge",
        "shared_interaction" : "interacts with",
        "name" : "Champmathieu (interacts with) Judge",
        "interaction" : "interacts with",
        "SUID" : 82065,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82010",
        "source" : "81887",
        "target" : "81772",
        "EdgeBetweenness" : 132.83333333,
        "shared_name" : "Champmathieu (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Champmathieu (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 82010,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82019",
        "source" : "81885",
        "target" : "81823",
        "EdgeBetweenness" : 43.95416348,
        "shared_name" : "Enjolras (interacts with) Mabeuf",
        "shared_interaction" : "interacts with",
        "name" : "Enjolras (interacts with) Mabeuf",
        "interaction" : "interacts with",
        "SUID" : 82019,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81977",
        "source" : "81885",
        "target" : "81785",
        "EdgeBetweenness" : 14.71666667,
        "shared_name" : "Enjolras (interacts with) Gavroche",
        "shared_interaction" : "interacts with",
        "name" : "Enjolras (interacts with) Gavroche",
        "interaction" : "interacts with",
        "SUID" : 81977,
        "Strength" : 7,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81935",
        "source" : "81885",
        "target" : "81790",
        "EdgeBetweenness" : 64.67925518,
        "shared_name" : "Enjolras (interacts with) Javert",
        "shared_interaction" : "interacts with",
        "name" : "Enjolras (interacts with) Javert",
        "interaction" : "interacts with",
        "SUID" : 81935,
        "Strength" : 6,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81932",
        "source" : "81885",
        "target" : "81772",
        "EdgeBetweenness" : 230.271856,
        "shared_name" : "Enjolras (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Enjolras (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81932,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81911",
        "source" : "81885",
        "target" : "81799",
        "EdgeBetweenness" : 32.91918812,
        "shared_name" : "Enjolras (interacts with) Marius",
        "shared_interaction" : "interacts with",
        "name" : "Enjolras (interacts with) Marius",
        "interaction" : "interacts with",
        "SUID" : 81911,
        "Strength" : 7,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81956",
        "source" : "81883",
        "target" : "81903",
        "EdgeBetweenness" : 34.71879929,
        "shared_name" : "Eponine (interacts with) MadameThenardier",
        "shared_interaction" : "interacts with",
        "name" : "Eponine (interacts with) MadameThenardier",
        "interaction" : "interacts with",
        "SUID" : 81956,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81910",
        "source" : "81883",
        "target" : "81815",
        "EdgeBetweenness" : 28.01829804,
        "shared_name" : "Eponine (interacts with) Thenardier",
        "shared_interaction" : "interacts with",
        "name" : "Eponine (interacts with) Thenardier",
        "interaction" : "interacts with",
        "SUID" : 81910,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82075",
        "source" : "81873",
        "target" : "81772",
        "EdgeBetweenness" : 132.83333333,
        "shared_name" : "Cochepaille (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Cochepaille (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 82075,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81982",
        "source" : "81873",
        "target" : "81780",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Cochepaille (interacts with) Brevet",
        "shared_interaction" : "interacts with",
        "name" : "Cochepaille (interacts with) Brevet",
        "interaction" : "interacts with",
        "SUID" : 81982,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81971",
        "source" : "81873",
        "target" : "81781",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Cochepaille (interacts with) Judge",
        "shared_interaction" : "interacts with",
        "name" : "Cochepaille (interacts with) Judge",
        "interaction" : "interacts with",
        "SUID" : 81971,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81955",
        "source" : "81873",
        "target" : "81894",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Cochepaille (interacts with) Chenildieu",
        "shared_interaction" : "interacts with",
        "name" : "Cochepaille (interacts with) Chenildieu",
        "interaction" : "interacts with",
        "SUID" : 81955,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81888",
        "source" : "81873",
        "target" : "81887",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Cochepaille (interacts with) Champmathieu",
        "shared_interaction" : "interacts with",
        "name" : "Cochepaille (interacts with) Champmathieu",
        "interaction" : "interacts with",
        "SUID" : 81888,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81874",
        "source" : "81873",
        "target" : "81783",
        "EdgeBetweenness" : 11.16666667,
        "shared_name" : "Cochepaille (interacts with) Bamatabois",
        "shared_interaction" : "interacts with",
        "name" : "Cochepaille (interacts with) Bamatabois",
        "interaction" : "interacts with",
        "SUID" : 81874,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82004",
        "source" : "81869",
        "target" : "82003",
        "EdgeBetweenness" : 152.0,
        "shared_name" : "MadameBurgon (interacts with) Jondrette",
        "shared_interaction" : "interacts with",
        "name" : "MadameBurgon (interacts with) Jondrette",
        "interaction" : "interacts with",
        "SUID" : 82004,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81944",
        "source" : "81867",
        "target" : "81865",
        "EdgeBetweenness" : 20.78888889,
        "shared_name" : "LieutenantTheoduleGillenormand (interacts with) MademoiselleGillenormand",
        "shared_interaction" : "interacts with",
        "name" : "LieutenantTheoduleGillenormand (interacts with) MademoiselleGillenormand",
        "interaction" : "interacts with",
        "SUID" : 81944,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81875",
        "source" : "81867",
        "target" : "81800",
        "EdgeBetweenness" : 41.0,
        "shared_name" : "LieutenantTheoduleGillenormand (interacts with) Cosette",
        "shared_interaction" : "interacts with",
        "name" : "LieutenantTheoduleGillenormand (interacts with) Cosette",
        "interaction" : "interacts with",
        "SUID" : 81875,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81868",
        "source" : "81867",
        "target" : "81771",
        "EdgeBetweenness" : 19.78888889,
        "shared_name" : "LieutenantTheoduleGillenormand (interacts with) Gillenormand",
        "shared_interaction" : "interacts with",
        "name" : "LieutenantTheoduleGillenormand (interacts with) Gillenormand",
        "interaction" : "interacts with",
        "SUID" : 81868,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82096",
        "source" : "81865",
        "target" : "81772",
        "EdgeBetweenness" : 263.5790404,
        "shared_name" : "MademoiselleGillenormand (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "MademoiselleGillenormand (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 82096,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82045",
        "source" : "81865",
        "target" : "81771",
        "EdgeBetweenness" : 14.66666667,
        "shared_name" : "MademoiselleGillenormand (interacts with) Gillenormand",
        "shared_interaction" : "interacts with",
        "name" : "MademoiselleGillenormand (interacts with) Gillenormand",
        "interaction" : "interacts with",
        "SUID" : 82045,
        "Strength" : 9,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81866",
        "source" : "81865",
        "target" : "81800",
        "EdgeBetweenness" : 34.8,
        "shared_name" : "MademoiselleGillenormand (interacts with) Cosette",
        "shared_interaction" : "interacts with",
        "name" : "MademoiselleGillenormand (interacts with) Cosette",
        "interaction" : "interacts with",
        "SUID" : 81866,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81864",
        "source" : "81863",
        "target" : "81772",
        "EdgeBetweenness" : 152.0,
        "shared_name" : "Gervais (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Gervais (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81864,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82055",
        "source" : "81860",
        "target" : "81772",
        "EdgeBetweenness" : 212.95384615,
        "shared_name" : "Fauchelevent (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Fauchelevent (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 82055,
        "Strength" : 8,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81861",
        "source" : "81860",
        "target" : "81790",
        "EdgeBetweenness" : 84.04615385,
        "shared_name" : "Fauchelevent (interacts with) Javert",
        "shared_interaction" : "interacts with",
        "name" : "Fauchelevent (interacts with) Javert",
        "interaction" : "interacts with",
        "SUID" : 81861,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81858",
        "source" : "81857",
        "target" : "81772",
        "EdgeBetweenness" : 152.0,
        "shared_name" : "MaubertIsabeau (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "MaubertIsabeau (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81858,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82088",
        "source" : "81855",
        "target" : "81772",
        "EdgeBetweenness" : 124.93650794,
        "shared_name" : "Marguerite (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Marguerite (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 82088,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82093",
        "source" : "81850",
        "target" : "82050",
        "EdgeBetweenness" : 51.24968169,
        "shared_name" : "SisterSimplice (interacts with) SisterPerpetue",
        "shared_interaction" : "interacts with",
        "name" : "SisterSimplice (interacts with) SisterPerpetue",
        "interaction" : "interacts with",
        "SUID" : 82093,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82064",
        "source" : "81850",
        "target" : "81772",
        "EdgeBetweenness" : 135.29025288,
        "shared_name" : "SisterSimplice (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "SisterSimplice (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 82064,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81893",
        "source" : "81850",
        "target" : "81790",
        "EdgeBetweenness" : 42.20558265,
        "shared_name" : "SisterSimplice (interacts with) Javert",
        "shared_interaction" : "interacts with",
        "name" : "SisterSimplice (interacts with) Javert",
        "interaction" : "interacts with",
        "SUID" : 81893,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81851",
        "source" : "81850",
        "target" : "81797",
        "EdgeBetweenness" : 21.75384615,
        "shared_name" : "SisterSimplice (interacts with) Fantine",
        "shared_interaction" : "interacts with",
        "name" : "SisterSimplice (interacts with) Fantine",
        "interaction" : "interacts with",
        "SUID" : 81851,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82049",
        "source" : "81845",
        "target" : "81969",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Child2 (interacts with) Child1",
        "shared_interaction" : "interacts with",
        "name" : "Child2 (interacts with) Child1",
        "interaction" : "interacts with",
        "SUID" : 82049,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81846",
        "source" : "81845",
        "target" : "81785",
        "EdgeBetweenness" : 150.0,
        "shared_name" : "Child2 (interacts with) Gavroche",
        "shared_interaction" : "interacts with",
        "name" : "Child2 (interacts with) Gavroche",
        "interaction" : "interacts with",
        "SUID" : 81846,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82094",
        "source" : "81843",
        "target" : "81785",
        "EdgeBetweenness" : 17.28571429,
        "shared_name" : "LAigleDeMeauxBossuet  (interacts with) Gavroche",
        "shared_interaction" : "interacts with",
        "name" : "LAigleDeMeauxBossuet  (interacts with) Gavroche",
        "interaction" : "interacts with",
        "SUID" : 82094,
        "Strength" : 5,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82084",
        "source" : "81843",
        "target" : "81817",
        "EdgeBetweenness" : 16.64603175,
        "shared_name" : "LAigleDeMeauxBossuet  (interacts with) Combeferre",
        "shared_interaction" : "interacts with",
        "name" : "LAigleDeMeauxBossuet  (interacts with) Combeferre",
        "interaction" : "interacts with",
        "SUID" : 82084,
        "Strength" : 9,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82043",
        "source" : "81843",
        "target" : "81778",
        "EdgeBetweenness" : 16.64603175,
        "shared_name" : "LAigleDeMeauxBossuet  (interacts with) Feuilly",
        "shared_interaction" : "interacts with",
        "name" : "LAigleDeMeauxBossuet  (interacts with) Feuilly",
        "interaction" : "interacts with",
        "SUID" : 82043,
        "Strength" : 6,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82029",
        "source" : "81843",
        "target" : "81885",
        "EdgeBetweenness" : 3.66666667,
        "shared_name" : "LAigleDeMeauxBossuet  (interacts with) Enjolras",
        "shared_interaction" : "interacts with",
        "name" : "LAigleDeMeauxBossuet  (interacts with) Enjolras",
        "interaction" : "interacts with",
        "SUID" : 82029,
        "Strength" : 10,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82027",
        "source" : "81843",
        "target" : "81823",
        "EdgeBetweenness" : 34.92946269,
        "shared_name" : "LAigleDeMeauxBossuet  (interacts with) Mabeuf",
        "shared_interaction" : "interacts with",
        "name" : "LAigleDeMeauxBossuet  (interacts with) Mabeuf",
        "interaction" : "interacts with",
        "SUID" : 82027,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81990",
        "source" : "81843",
        "target" : "81821",
        "EdgeBetweenness" : 26.71486291,
        "shared_name" : "LAigleDeMeauxBossuet  (interacts with) JeanProuvaire",
        "shared_interaction" : "interacts with",
        "name" : "LAigleDeMeauxBossuet  (interacts with) JeanProuvaire",
        "interaction" : "interacts with",
        "SUID" : 81990,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81939",
        "source" : "81843",
        "target" : "81788",
        "EdgeBetweenness" : 17.10758849,
        "shared_name" : "LAigleDeMeauxBossuet  (interacts with) Courfeyrac",
        "shared_interaction" : "interacts with",
        "name" : "LAigleDeMeauxBossuet  (interacts with) Courfeyrac",
        "interaction" : "interacts with",
        "SUID" : 81939,
        "Strength" : 12,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81919",
        "source" : "81843",
        "target" : "81819",
        "EdgeBetweenness" : 16.36031746,
        "shared_name" : "LAigleDeMeauxBossuet  (interacts with) Bahorel",
        "shared_interaction" : "interacts with",
        "name" : "LAigleDeMeauxBossuet  (interacts with) Bahorel",
        "interaction" : "interacts with",
        "SUID" : 81919,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81871",
        "source" : "81843",
        "target" : "81772",
        "EdgeBetweenness" : 247.40995124,
        "shared_name" : "LAigleDeMeauxBossuet  (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "LAigleDeMeauxBossuet  (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81871,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81844",
        "source" : "81843",
        "target" : "81799",
        "EdgeBetweenness" : 34.50490241,
        "shared_name" : "LAigleDeMeauxBossuet  (interacts with) Marius",
        "shared_interaction" : "interacts with",
        "name" : "LAigleDeMeauxBossuet  (interacts with) Marius",
        "interaction" : "interacts with",
        "SUID" : 81844,
        "Strength" : 5,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81997",
        "source" : "81840",
        "target" : "81830",
        "EdgeBetweenness" : 39.65238095,
        "shared_name" : "Fameuil (interacts with) FelixTholomyes",
        "shared_interaction" : "interacts with",
        "name" : "Fameuil (interacts with) FelixTholomyes",
        "interaction" : "interacts with",
        "SUID" : 81997,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81841",
        "source" : "81840",
        "target" : "81775",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Fameuil (interacts with) Listolier",
        "shared_interaction" : "interacts with",
        "name" : "Fameuil (interacts with) Listolier",
        "interaction" : "interacts with",
        "SUID" : 81841,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82025",
        "source" : "81837",
        "target" : "81772",
        "EdgeBetweenness" : 93.33141026,
        "shared_name" : "Toussaint (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Toussaint (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 82025,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81909",
        "source" : "81837",
        "target" : "81800",
        "EdgeBetweenness" : 23.46217949,
        "shared_name" : "Toussaint (interacts with) Cosette",
        "shared_interaction" : "interacts with",
        "name" : "Toussaint (interacts with) Cosette",
        "interaction" : "interacts with",
        "SUID" : 81909,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81838",
        "source" : "81837",
        "target" : "81790",
        "EdgeBetweenness" : 35.20641026,
        "shared_name" : "Toussaint (interacts with) Javert",
        "shared_interaction" : "interacts with",
        "name" : "Toussaint (interacts with) Javert",
        "interaction" : "interacts with",
        "SUID" : 81838,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82100",
        "source" : "81835",
        "target" : "81826",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Babet (interacts with) Gueulemer",
        "shared_interaction" : "interacts with",
        "name" : "Babet (interacts with) Gueulemer",
        "interaction" : "interacts with",
        "SUID" : 82100,
        "Strength" : 6,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82072",
        "source" : "81835",
        "target" : "81883",
        "EdgeBetweenness" : 16.98101343,
        "shared_name" : "Babet (interacts with) Eponine",
        "shared_interaction" : "interacts with",
        "name" : "Babet (interacts with) Eponine",
        "interaction" : "interacts with",
        "SUID" : 82072,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82017",
        "source" : "81835",
        "target" : "81785",
        "EdgeBetweenness" : 37.12431078,
        "shared_name" : "Babet (interacts with) Gavroche",
        "shared_interaction" : "interacts with",
        "name" : "Babet (interacts with) Gavroche",
        "interaction" : "interacts with",
        "SUID" : 82017,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81987",
        "source" : "81835",
        "target" : "81903",
        "EdgeBetweenness" : 15.72669173,
        "shared_name" : "Babet (interacts with) MadameThenardier",
        "shared_interaction" : "interacts with",
        "name" : "Babet (interacts with) MadameThenardier",
        "interaction" : "interacts with",
        "SUID" : 81987,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81958",
        "source" : "81835",
        "target" : "81790",
        "EdgeBetweenness" : 17.46025641,
        "shared_name" : "Babet (interacts with) Javert",
        "shared_interaction" : "interacts with",
        "name" : "Babet (interacts with) Javert",
        "interaction" : "interacts with",
        "SUID" : 81958,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81890",
        "source" : "81835",
        "target" : "81815",
        "EdgeBetweenness" : 13.8,
        "shared_name" : "Babet (interacts with) Thenardier",
        "shared_interaction" : "interacts with",
        "name" : "Babet (interacts with) Thenardier",
        "interaction" : "interacts with",
        "SUID" : 81890,
        "Strength" : 6,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81878",
        "source" : "81835",
        "target" : "81772",
        "EdgeBetweenness" : 85.58724054,
        "shared_name" : "Babet (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Babet (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81878,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82056",
        "source" : "81834",
        "target" : "81785",
        "EdgeBetweenness" : 46.11648352,
        "shared_name" : "Brujon (interacts with) Gavroche",
        "shared_interaction" : "interacts with",
        "name" : "Brujon (interacts with) Gavroche",
        "interaction" : "interacts with",
        "SUID" : 82056,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81926",
        "source" : "81834",
        "target" : "81809",
        "EdgeBetweenness" : 15.83315018,
        "shared_name" : "Brujon (interacts with) Claquesous",
        "shared_interaction" : "interacts with",
        "name" : "Brujon (interacts with) Claquesous",
        "interaction" : "interacts with",
        "SUID" : 81926,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81915",
        "source" : "81834",
        "target" : "81826",
        "EdgeBetweenness" : 13.58315018,
        "shared_name" : "Brujon (interacts with) Gueulemer",
        "shared_interaction" : "interacts with",
        "name" : "Brujon (interacts with) Gueulemer",
        "interaction" : "interacts with",
        "SUID" : 81915,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81908",
        "source" : "81834",
        "target" : "81808",
        "EdgeBetweenness" : 12.78315018,
        "shared_name" : "Brujon (interacts with) Montparnasse",
        "shared_interaction" : "interacts with",
        "name" : "Brujon (interacts with) Montparnasse",
        "interaction" : "interacts with",
        "SUID" : 81908,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81901",
        "source" : "81834",
        "target" : "81815",
        "EdgeBetweenness" : 44.21758242,
        "shared_name" : "Brujon (interacts with) Thenardier",
        "shared_interaction" : "interacts with",
        "name" : "Brujon (interacts with) Thenardier",
        "interaction" : "interacts with",
        "SUID" : 81901,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81884",
        "source" : "81834",
        "target" : "81883",
        "EdgeBetweenness" : 10.88333333,
        "shared_name" : "Brujon (interacts with) Eponine",
        "shared_interaction" : "interacts with",
        "name" : "Brujon (interacts with) Eponine",
        "interaction" : "interacts with",
        "SUID" : 81884,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81836",
        "source" : "81834",
        "target" : "81835",
        "EdgeBetweenness" : 13.58315018,
        "shared_name" : "Brujon (interacts with) Babet",
        "shared_interaction" : "interacts with",
        "name" : "Brujon (interacts with) Babet",
        "interaction" : "interacts with",
        "SUID" : 81836,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81833",
        "source" : "81832",
        "target" : "81793",
        "EdgeBetweenness" : 152.0,
        "shared_name" : "OldMan (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "shared_interaction" : "interacts with",
        "name" : "OldMan (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "interaction" : "interacts with",
        "SUID" : 81833,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82057",
        "source" : "81826",
        "target" : "81883",
        "EdgeBetweenness" : 16.98101343,
        "shared_name" : "Gueulemer (interacts with) Eponine",
        "shared_interaction" : "interacts with",
        "name" : "Gueulemer (interacts with) Eponine",
        "interaction" : "interacts with",
        "SUID" : 82057,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81961",
        "source" : "81826",
        "target" : "81785",
        "EdgeBetweenness" : 37.12431078,
        "shared_name" : "Gueulemer (interacts with) Gavroche",
        "shared_interaction" : "interacts with",
        "name" : "Gueulemer (interacts with) Gavroche",
        "interaction" : "interacts with",
        "SUID" : 81961,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81931",
        "source" : "81826",
        "target" : "81903",
        "EdgeBetweenness" : 15.72669173,
        "shared_name" : "Gueulemer (interacts with) MadameThenardier",
        "shared_interaction" : "interacts with",
        "name" : "Gueulemer (interacts with) MadameThenardier",
        "interaction" : "interacts with",
        "SUID" : 81931,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81872",
        "source" : "81826",
        "target" : "81790",
        "EdgeBetweenness" : 17.46025641,
        "shared_name" : "Gueulemer (interacts with) Javert",
        "shared_interaction" : "interacts with",
        "name" : "Gueulemer (interacts with) Javert",
        "interaction" : "interacts with",
        "SUID" : 81872,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81848",
        "source" : "81826",
        "target" : "81815",
        "EdgeBetweenness" : 13.8,
        "shared_name" : "Gueulemer (interacts with) Thenardier",
        "shared_interaction" : "interacts with",
        "name" : "Gueulemer (interacts with) Thenardier",
        "interaction" : "interacts with",
        "SUID" : 81848,
        "Strength" : 5,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81827",
        "source" : "81826",
        "target" : "81772",
        "EdgeBetweenness" : 85.58724054,
        "shared_name" : "Gueulemer (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Gueulemer (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81827,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82006",
        "source" : "81823",
        "target" : "81883",
        "EdgeBetweenness" : 35.53357525,
        "shared_name" : "Mabeuf (interacts with) Eponine",
        "shared_interaction" : "interacts with",
        "name" : "Mabeuf (interacts with) Eponine",
        "interaction" : "interacts with",
        "SUID" : 82006,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81862",
        "source" : "81823",
        "target" : "81785",
        "EdgeBetweenness" : 69.80309396,
        "shared_name" : "Mabeuf (interacts with) Gavroche",
        "shared_interaction" : "interacts with",
        "name" : "Mabeuf (interacts with) Gavroche",
        "interaction" : "interacts with",
        "SUID" : 81862,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81847",
        "source" : "81823",
        "target" : "81799",
        "EdgeBetweenness" : 99.31779985,
        "shared_name" : "Mabeuf (interacts with) Marius",
        "shared_interaction" : "interacts with",
        "name" : "Mabeuf (interacts with) Marius",
        "interaction" : "interacts with",
        "SUID" : 81847,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81972",
        "source" : "81821",
        "target" : "81817",
        "EdgeBetweenness" : 5.56291486,
        "shared_name" : "JeanProuvaire (interacts with) Combeferre",
        "shared_interaction" : "interacts with",
        "name" : "JeanProuvaire (interacts with) Combeferre",
        "interaction" : "interacts with",
        "SUID" : 81972,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81951",
        "source" : "81821",
        "target" : "81785",
        "EdgeBetweenness" : 56.23015873,
        "shared_name" : "JeanProuvaire (interacts with) Gavroche",
        "shared_interaction" : "interacts with",
        "name" : "JeanProuvaire (interacts with) Gavroche",
        "interaction" : "interacts with",
        "SUID" : 81951,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81899",
        "source" : "81821",
        "target" : "81885",
        "EdgeBetweenness" : 34.8023088,
        "shared_name" : "JeanProuvaire (interacts with) Enjolras",
        "shared_interaction" : "interacts with",
        "name" : "JeanProuvaire (interacts with) Enjolras",
        "interaction" : "interacts with",
        "SUID" : 81899,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82086",
        "source" : "81819",
        "target" : "81799",
        "EdgeBetweenness" : 63.44299765,
        "shared_name" : "Bahorel (interacts with) Marius",
        "shared_interaction" : "interacts with",
        "name" : "Bahorel (interacts with) Marius",
        "interaction" : "interacts with",
        "SUID" : 82086,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82016",
        "source" : "81819",
        "target" : "81785",
        "EdgeBetweenness" : 39.37619048,
        "shared_name" : "Bahorel (interacts with) Gavroche",
        "shared_interaction" : "interacts with",
        "name" : "Bahorel (interacts with) Gavroche",
        "interaction" : "interacts with",
        "SUID" : 82016,
        "Strength" : 5,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81929",
        "source" : "81819",
        "target" : "81817",
        "EdgeBetweenness" : 2.28571429,
        "shared_name" : "Bahorel (interacts with) Combeferre",
        "shared_interaction" : "interacts with",
        "name" : "Bahorel (interacts with) Combeferre",
        "interaction" : "interacts with",
        "SUID" : 81929,
        "Strength" : 5,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81925",
        "source" : "81819",
        "target" : "81788",
        "EdgeBetweenness" : 3.2,
        "shared_name" : "Bahorel (interacts with) Courfeyrac",
        "shared_interaction" : "interacts with",
        "name" : "Bahorel (interacts with) Courfeyrac",
        "interaction" : "interacts with",
        "SUID" : 81925,
        "Strength" : 6,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81921",
        "source" : "81819",
        "target" : "81885",
        "EdgeBetweenness" : 22.35396825,
        "shared_name" : "Bahorel (interacts with) Enjolras",
        "shared_interaction" : "interacts with",
        "name" : "Bahorel (interacts with) Enjolras",
        "interaction" : "interacts with",
        "SUID" : 81921,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81906",
        "source" : "81819",
        "target" : "81821",
        "EdgeBetweenness" : 5.84862915,
        "shared_name" : "Bahorel (interacts with) JeanProuvaire",
        "shared_interaction" : "interacts with",
        "name" : "Bahorel (interacts with) JeanProuvaire",
        "interaction" : "interacts with",
        "SUID" : 81906,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81825",
        "source" : "81819",
        "target" : "81823",
        "EdgeBetweenness" : 6.86666667,
        "shared_name" : "Bahorel (interacts with) Mabeuf",
        "shared_interaction" : "interacts with",
        "name" : "Bahorel (interacts with) Mabeuf",
        "interaction" : "interacts with",
        "SUID" : 81825,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81820",
        "source" : "81819",
        "target" : "81778",
        "EdgeBetweenness" : 2.28571429,
        "shared_name" : "Bahorel (interacts with) Feuilly",
        "shared_interaction" : "interacts with",
        "name" : "Bahorel (interacts with) Feuilly",
        "interaction" : "interacts with",
        "SUID" : 81820,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81992",
        "source" : "81817",
        "target" : "81785",
        "EdgeBetweenness" : 39.66190476,
        "shared_name" : "Combeferre (interacts with) Gavroche",
        "shared_interaction" : "interacts with",
        "name" : "Combeferre (interacts with) Gavroche",
        "interaction" : "interacts with",
        "SUID" : 81992,
        "Strength" : 6,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81960",
        "source" : "81817",
        "target" : "81885",
        "EdgeBetweenness" : 22.63968254,
        "shared_name" : "Combeferre (interacts with) Enjolras",
        "shared_interaction" : "interacts with",
        "name" : "Combeferre (interacts with) Enjolras",
        "interaction" : "interacts with",
        "SUID" : 81960,
        "Strength" : 15,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81824",
        "source" : "81817",
        "target" : "81823",
        "EdgeBetweenness" : 6.2,
        "shared_name" : "Combeferre (interacts with) Mabeuf",
        "shared_interaction" : "interacts with",
        "name" : "Combeferre (interacts with) Mabeuf",
        "interaction" : "interacts with",
        "SUID" : 81824,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81818",
        "source" : "81817",
        "target" : "81799",
        "EdgeBetweenness" : 59.63535354,
        "shared_name" : "Combeferre (interacts with) Marius",
        "shared_interaction" : "interacts with",
        "name" : "Combeferre (interacts with) Marius",
        "interaction" : "interacts with",
        "SUID" : 81818,
        "Strength" : 5,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82007",
        "source" : "81815",
        "target" : "81797",
        "EdgeBetweenness" : 137.46738164,
        "shared_name" : "Thenardier (interacts with) Fantine",
        "shared_interaction" : "interacts with",
        "name" : "Thenardier (interacts with) Fantine",
        "interaction" : "interacts with",
        "SUID" : 82007,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81968",
        "source" : "81815",
        "target" : "81903",
        "EdgeBetweenness" : 19.17907268,
        "shared_name" : "Thenardier (interacts with) MadameThenardier",
        "shared_interaction" : "interacts with",
        "name" : "Thenardier (interacts with) MadameThenardier",
        "interaction" : "interacts with",
        "SUID" : 81968,
        "Strength" : 13,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81880",
        "source" : "81815",
        "target" : "81772",
        "EdgeBetweenness" : 177.49200244,
        "shared_name" : "Thenardier (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Thenardier (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81880,
        "Strength" : 12,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81816",
        "source" : "81814",
        "target" : "81815",
        "EdgeBetweenness" : 92.35515873,
        "shared_name" : "Pontmercy (interacts with) Thenardier",
        "shared_interaction" : "interacts with",
        "name" : "Pontmercy (interacts with) Thenardier",
        "interaction" : "interacts with",
        "SUID" : 81816,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82035",
        "source" : "81812",
        "target" : "81785",
        "EdgeBetweenness" : 55.94444444,
        "shared_name" : "Grantaire (interacts with) Gavroche",
        "shared_interaction" : "interacts with",
        "name" : "Grantaire (interacts with) Gavroche",
        "interaction" : "interacts with",
        "SUID" : 82035,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82033",
        "source" : "81812",
        "target" : "81788",
        "EdgeBetweenness" : 8.85815296,
        "shared_name" : "Grantaire (interacts with) Courfeyrac",
        "shared_interaction" : "interacts with",
        "name" : "Grantaire (interacts with) Courfeyrac",
        "interaction" : "interacts with",
        "SUID" : 82033,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81973",
        "source" : "81812",
        "target" : "81819",
        "EdgeBetweenness" : 5.56291486,
        "shared_name" : "Grantaire (interacts with) Bahorel",
        "shared_interaction" : "interacts with",
        "name" : "Grantaire (interacts with) Bahorel",
        "interaction" : "interacts with",
        "SUID" : 81973,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81922",
        "source" : "81812",
        "target" : "81821",
        "EdgeBetweenness" : 2.28571429,
        "shared_name" : "Grantaire (interacts with) JeanProuvaire",
        "shared_interaction" : "interacts with",
        "name" : "Grantaire (interacts with) JeanProuvaire",
        "interaction" : "interacts with",
        "SUID" : 81922,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81918",
        "source" : "81812",
        "target" : "81843",
        "EdgeBetweenness" : 26.42914863,
        "shared_name" : "Grantaire (interacts with) LAigleDeMeauxBossuet ",
        "shared_interaction" : "interacts with",
        "name" : "Grantaire (interacts with) LAigleDeMeauxBossuet ",
        "interaction" : "interacts with",
        "SUID" : 81918,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81900",
        "source" : "81812",
        "target" : "81778",
        "EdgeBetweenness" : 5.84862915,
        "shared_name" : "Grantaire (interacts with) Feuilly",
        "shared_interaction" : "interacts with",
        "name" : "Grantaire (interacts with) Feuilly",
        "interaction" : "interacts with",
        "SUID" : 81900,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81886",
        "source" : "81812",
        "target" : "81885",
        "EdgeBetweenness" : 34.51659452,
        "shared_name" : "Grantaire (interacts with) Enjolras",
        "shared_interaction" : "interacts with",
        "name" : "Grantaire (interacts with) Enjolras",
        "interaction" : "interacts with",
        "SUID" : 81886,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81879",
        "source" : "81812",
        "target" : "81777",
        "EdgeBetweenness" : 5.56291486,
        "shared_name" : "Grantaire (interacts with) Joly",
        "shared_interaction" : "interacts with",
        "name" : "Grantaire (interacts with) Joly",
        "interaction" : "interacts with",
        "SUID" : 81879,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81842",
        "source" : "81812",
        "target" : "81817",
        "EdgeBetweenness" : 5.84862915,
        "shared_name" : "Grantaire (interacts with) Combeferre",
        "shared_interaction" : "interacts with",
        "name" : "Grantaire (interacts with) Combeferre",
        "interaction" : "interacts with",
        "SUID" : 81842,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82062",
        "source" : "81809",
        "target" : "81835",
        "EdgeBetweenness" : 3.75,
        "shared_name" : "Claquesous (interacts with) Babet",
        "shared_interaction" : "interacts with",
        "name" : "Claquesous (interacts with) Babet",
        "interaction" : "interacts with",
        "SUID" : 82062,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82048",
        "source" : "81809",
        "target" : "81790",
        "EdgeBetweenness" : 18.21025641,
        "shared_name" : "Claquesous (interacts with) Javert",
        "shared_interaction" : "interacts with",
        "name" : "Claquesous (interacts with) Javert",
        "interaction" : "interacts with",
        "SUID" : 82048,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82024",
        "source" : "81809",
        "target" : "81826",
        "EdgeBetweenness" : 3.75,
        "shared_name" : "Claquesous (interacts with) Gueulemer",
        "shared_interaction" : "interacts with",
        "name" : "Claquesous (interacts with) Gueulemer",
        "interaction" : "interacts with",
        "SUID" : 82024,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82023",
        "source" : "81809",
        "target" : "81815",
        "EdgeBetweenness" : 16.01666667,
        "shared_name" : "Claquesous (interacts with) Thenardier",
        "shared_interaction" : "interacts with",
        "name" : "Claquesous (interacts with) Thenardier",
        "interaction" : "interacts with",
        "SUID" : 82023,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82022",
        "source" : "81809",
        "target" : "81885",
        "EdgeBetweenness" : 29.31240602,
        "shared_name" : "Claquesous (interacts with) Enjolras",
        "shared_interaction" : "interacts with",
        "name" : "Claquesous (interacts with) Enjolras",
        "interaction" : "interacts with",
        "SUID" : 82022,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81945",
        "source" : "81809",
        "target" : "81883",
        "EdgeBetweenness" : 16.3976801,
        "shared_name" : "Claquesous (interacts with) Eponine",
        "shared_interaction" : "interacts with",
        "name" : "Claquesous (interacts with) Eponine",
        "interaction" : "interacts with",
        "SUID" : 81945,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81936",
        "source" : "81809",
        "target" : "81772",
        "EdgeBetweenness" : 86.33724054,
        "shared_name" : "Claquesous (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Claquesous (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81936,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81904",
        "source" : "81809",
        "target" : "81903",
        "EdgeBetweenness" : 13.53145363,
        "shared_name" : "Claquesous (interacts with) MadameThenardier",
        "shared_interaction" : "interacts with",
        "name" : "Claquesous (interacts with) MadameThenardier",
        "interaction" : "interacts with",
        "SUID" : 81904,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82063",
        "source" : "81808",
        "target" : "81883",
        "EdgeBetweenness" : 17.90561661,
        "shared_name" : "Montparnasse (interacts with) Eponine",
        "shared_interaction" : "interacts with",
        "name" : "Montparnasse (interacts with) Eponine",
        "interaction" : "interacts with",
        "SUID" : 82063,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82020",
        "source" : "81808",
        "target" : "81772",
        "EdgeBetweenness" : 88.02851038,
        "shared_name" : "Montparnasse (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Montparnasse (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 82020,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81996",
        "source" : "81808",
        "target" : "81835",
        "EdgeBetweenness" : 2.53571429,
        "shared_name" : "Montparnasse (interacts with) Babet",
        "shared_interaction" : "interacts with",
        "name" : "Montparnasse (interacts with) Babet",
        "interaction" : "interacts with",
        "SUID" : 81996,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81989",
        "source" : "81808",
        "target" : "81790",
        "EdgeBetweenness" : 19.55152625,
        "shared_name" : "Montparnasse (interacts with) Javert",
        "shared_interaction" : "interacts with",
        "name" : "Montparnasse (interacts with) Javert",
        "interaction" : "interacts with",
        "SUID" : 81989,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81978",
        "source" : "81808",
        "target" : "81815",
        "EdgeBetweenness" : 16.21349206,
        "shared_name" : "Montparnasse (interacts with) Thenardier",
        "shared_interaction" : "interacts with",
        "name" : "Montparnasse (interacts with) Thenardier",
        "interaction" : "interacts with",
        "SUID" : 81978,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81974",
        "source" : "81808",
        "target" : "81826",
        "EdgeBetweenness" : 2.53571429,
        "shared_name" : "Montparnasse (interacts with) Gueulemer",
        "shared_interaction" : "interacts with",
        "name" : "Montparnasse (interacts with) Gueulemer",
        "interaction" : "interacts with",
        "SUID" : 81974,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81889",
        "source" : "81808",
        "target" : "81785",
        "EdgeBetweenness" : 32.32222222,
        "shared_name" : "Montparnasse (interacts with) Gavroche",
        "shared_interaction" : "interacts with",
        "name" : "Montparnasse (interacts with) Gavroche",
        "interaction" : "interacts with",
        "SUID" : 81889,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81810",
        "source" : "81808",
        "target" : "81809",
        "EdgeBetweenness" : 4.28571429,
        "shared_name" : "Montparnasse (interacts with) Claquesous",
        "shared_interaction" : "interacts with",
        "name" : "Montparnasse (interacts with) Claquesous",
        "interaction" : "interacts with",
        "SUID" : 81810,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81806",
        "source" : "81805",
        "target" : "81772",
        "EdgeBetweenness" : 152.0,
        "shared_name" : "Scaufflaire (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Scaufflaire (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81806,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82070",
        "source" : "81803",
        "target" : "81840",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Blacheville (interacts with) Fameuil",
        "shared_interaction" : "interacts with",
        "name" : "Blacheville (interacts with) Fameuil",
        "interaction" : "interacts with",
        "SUID" : 82070,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82054",
        "source" : "81803",
        "target" : "81830",
        "EdgeBetweenness" : 39.65238095,
        "shared_name" : "Blacheville (interacts with) FelixTholomyes",
        "shared_interaction" : "interacts with",
        "name" : "Blacheville (interacts with) FelixTholomyes",
        "interaction" : "interacts with",
        "SUID" : 82054,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81804",
        "source" : "81803",
        "target" : "81775",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Blacheville (interacts with) Listolier",
        "shared_interaction" : "interacts with",
        "name" : "Blacheville (interacts with) Listolier",
        "interaction" : "interacts with",
        "SUID" : 81804,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82039",
        "source" : "81800",
        "target" : "81772",
        "EdgeBetweenness" : 90.18412698,
        "shared_name" : "Cosette (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Cosette (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 82039,
        "Strength" : 31,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81967",
        "source" : "81800",
        "target" : "81815",
        "EdgeBetweenness" : 31.63705739,
        "shared_name" : "Cosette (interacts with) Thenardier",
        "shared_interaction" : "interacts with",
        "name" : "Cosette (interacts with) Thenardier",
        "interaction" : "interacts with",
        "SUID" : 81967,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81964",
        "source" : "81800",
        "target" : "81903",
        "EdgeBetweenness" : 21.55952381,
        "shared_name" : "Cosette (interacts with) MadameThenardier",
        "shared_interaction" : "interacts with",
        "name" : "Cosette (interacts with) MadameThenardier",
        "interaction" : "interacts with",
        "SUID" : 81964,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81852",
        "source" : "81800",
        "target" : "81830",
        "EdgeBetweenness" : 76.31904762,
        "shared_name" : "Cosette (interacts with) FelixTholomyes",
        "shared_interaction" : "interacts with",
        "name" : "Cosette (interacts with) FelixTholomyes",
        "interaction" : "interacts with",
        "SUID" : 81852,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82042",
        "source" : "81799",
        "target" : "81785",
        "EdgeBetweenness" : 102.48664844,
        "shared_name" : "Marius (interacts with) Gavroche",
        "shared_interaction" : "interacts with",
        "name" : "Marius (interacts with) Gavroche",
        "interaction" : "interacts with",
        "SUID" : 82042,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81999",
        "source" : "81799",
        "target" : "81883",
        "EdgeBetweenness" : 48.93217338,
        "shared_name" : "Marius (interacts with) Eponine",
        "shared_interaction" : "interacts with",
        "name" : "Marius (interacts with) Eponine",
        "interaction" : "interacts with",
        "SUID" : 81999,
        "Strength" : 5,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81975",
        "source" : "81799",
        "target" : "81815",
        "EdgeBetweenness" : 49.91903064,
        "shared_name" : "Marius (interacts with) Thenardier",
        "shared_interaction" : "interacts with",
        "name" : "Marius (interacts with) Thenardier",
        "interaction" : "interacts with",
        "SUID" : 81975,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81965",
        "source" : "81799",
        "target" : "81830",
        "EdgeBetweenness" : 259.03490366,
        "shared_name" : "Marius (interacts with) FelixTholomyes",
        "shared_interaction" : "interacts with",
        "name" : "Marius (interacts with) FelixTholomyes",
        "interaction" : "interacts with",
        "SUID" : 81965,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81924",
        "source" : "81799",
        "target" : "81865",
        "EdgeBetweenness" : 96.26818182,
        "shared_name" : "Marius (interacts with) MademoiselleGillenormand",
        "shared_interaction" : "interacts with",
        "name" : "Marius (interacts with) MademoiselleGillenormand",
        "interaction" : "interacts with",
        "SUID" : 81924,
        "Strength" : 6,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81920",
        "source" : "81799",
        "target" : "81814",
        "EdgeBetweenness" : 95.11984127,
        "shared_name" : "Marius (interacts with) Pontmercy",
        "shared_interaction" : "interacts with",
        "name" : "Marius (interacts with) Pontmercy",
        "interaction" : "interacts with",
        "SUID" : 81920,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81907",
        "source" : "81799",
        "target" : "81771",
        "EdgeBetweenness" : 57.89781271,
        "shared_name" : "Marius (interacts with) Gillenormand",
        "shared_interaction" : "interacts with",
        "name" : "Marius (interacts with) Gillenormand",
        "interaction" : "interacts with",
        "SUID" : 81907,
        "Strength" : 12,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81902",
        "source" : "81799",
        "target" : "81867",
        "EdgeBetweenness" : 70.42222222,
        "shared_name" : "Marius (interacts with) LieutenantTheoduleGillenormand",
        "shared_interaction" : "interacts with",
        "name" : "Marius (interacts with) LieutenantTheoduleGillenormand",
        "interaction" : "interacts with",
        "SUID" : 81902,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81877",
        "source" : "81799",
        "target" : "81772",
        "EdgeBetweenness" : 259.28668488,
        "shared_name" : "Marius (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Marius (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81877,
        "Strength" : 19,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81801",
        "source" : "81799",
        "target" : "81800",
        "EdgeBetweenness" : 36.17380952,
        "shared_name" : "Marius (interacts with) Cosette",
        "shared_interaction" : "interacts with",
        "name" : "Marius (interacts with) Cosette",
        "interaction" : "interacts with",
        "SUID" : 81801,
        "Strength" : 21,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82080",
        "source" : "81797",
        "target" : "81830",
        "EdgeBetweenness" : 41.90633223,
        "shared_name" : "Fantine (interacts with) FelixTholomyes",
        "shared_interaction" : "interacts with",
        "name" : "Fantine (interacts with) FelixTholomyes",
        "interaction" : "interacts with",
        "SUID" : 82080,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82074",
        "source" : "81797",
        "target" : "81912",
        "EdgeBetweenness" : 102.34761905,
        "shared_name" : "Fantine (interacts with) Favourite",
        "shared_interaction" : "interacts with",
        "name" : "Fantine (interacts with) Favourite",
        "interaction" : "interacts with",
        "SUID" : 82074,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82011",
        "source" : "81797",
        "target" : "81803",
        "EdgeBetweenness" : 102.34761905,
        "shared_name" : "Fantine (interacts with) Blacheville",
        "shared_interaction" : "interacts with",
        "name" : "Fantine (interacts with) Blacheville",
        "interaction" : "interacts with",
        "SUID" : 82011,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81896",
        "source" : "81797",
        "target" : "81775",
        "EdgeBetweenness" : 102.34761905,
        "shared_name" : "Fantine (interacts with) Listolier",
        "shared_interaction" : "interacts with",
        "name" : "Fantine (interacts with) Listolier",
        "interaction" : "interacts with",
        "SUID" : 81896,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81859",
        "source" : "81797",
        "target" : "81840",
        "EdgeBetweenness" : 102.34761905,
        "shared_name" : "Fantine (interacts with) Fameuil",
        "shared_interaction" : "interacts with",
        "name" : "Fantine (interacts with) Fameuil",
        "interaction" : "interacts with",
        "SUID" : 81859,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81856",
        "source" : "81797",
        "target" : "81855",
        "EdgeBetweenness" : 27.06349206,
        "shared_name" : "Fantine (interacts with) Marguerite",
        "shared_interaction" : "interacts with",
        "name" : "Fantine (interacts with) Marguerite",
        "interaction" : "interacts with",
        "SUID" : 81856,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81839",
        "source" : "81797",
        "target" : "81795",
        "EdgeBetweenness" : 102.34761905,
        "shared_name" : "Fantine (interacts with) Dahlia",
        "shared_interaction" : "interacts with",
        "name" : "Fantine (interacts with) Dahlia",
        "interaction" : "interacts with",
        "SUID" : 81839,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81811",
        "source" : "81797",
        "target" : "81774",
        "EdgeBetweenness" : 102.34761905,
        "shared_name" : "Fantine (interacts with) Zephine",
        "shared_interaction" : "interacts with",
        "name" : "Fantine (interacts with) Zephine",
        "interaction" : "interacts with",
        "SUID" : 81811,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81798",
        "source" : "81797",
        "target" : "81772",
        "EdgeBetweenness" : 445.94740684,
        "shared_name" : "Fantine (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Fantine (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81798,
        "Strength" : 9,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82078",
        "source" : "81795",
        "target" : "81912",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Dahlia (interacts with) Favourite",
        "shared_interaction" : "interacts with",
        "name" : "Dahlia (interacts with) Favourite",
        "interaction" : "interacts with",
        "SUID" : 82078,
        "Strength" : 5,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81954",
        "source" : "81795",
        "target" : "81840",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Dahlia (interacts with) Fameuil",
        "shared_interaction" : "interacts with",
        "name" : "Dahlia (interacts with) Fameuil",
        "interaction" : "interacts with",
        "SUID" : 81954,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81923",
        "source" : "81795",
        "target" : "81803",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Dahlia (interacts with) Blacheville",
        "shared_interaction" : "interacts with",
        "name" : "Dahlia (interacts with) Blacheville",
        "interaction" : "interacts with",
        "SUID" : 81923,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81831",
        "source" : "81795",
        "target" : "81830",
        "EdgeBetweenness" : 39.65238095,
        "shared_name" : "Dahlia (interacts with) FelixTholomyes",
        "shared_interaction" : "interacts with",
        "name" : "Dahlia (interacts with) FelixTholomyes",
        "interaction" : "interacts with",
        "SUID" : 81831,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81796",
        "source" : "81795",
        "target" : "81775",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Dahlia (interacts with) Listolier",
        "shared_interaction" : "interacts with",
        "name" : "Dahlia (interacts with) Listolier",
        "interaction" : "interacts with",
        "SUID" : 81796,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81794",
        "source" : "81792",
        "target" : "81793",
        "EdgeBetweenness" : 152.0,
        "shared_name" : "Count (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "shared_interaction" : "interacts with",
        "name" : "Count (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "interaction" : "interacts with",
        "SUID" : 81794,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82021",
        "source" : "81790",
        "target" : "81903",
        "EdgeBetweenness" : 26.66730287,
        "shared_name" : "Javert (interacts with) MadameThenardier",
        "shared_interaction" : "interacts with",
        "name" : "Javert (interacts with) MadameThenardier",
        "interaction" : "interacts with",
        "SUID" : 82021,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81943",
        "source" : "81790",
        "target" : "81797",
        "EdgeBetweenness" : 108.97976403,
        "shared_name" : "Javert (interacts with) Fantine",
        "shared_interaction" : "interacts with",
        "name" : "Javert (interacts with) Fantine",
        "interaction" : "interacts with",
        "SUID" : 81943,
        "Strength" : 5,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81942",
        "source" : "81790",
        "target" : "81815",
        "EdgeBetweenness" : 30.0459707,
        "shared_name" : "Javert (interacts with) Thenardier",
        "shared_interaction" : "interacts with",
        "name" : "Javert (interacts with) Thenardier",
        "interaction" : "interacts with",
        "SUID" : 81942,
        "Strength" : 5,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81891",
        "source" : "81790",
        "target" : "81800",
        "EdgeBetweenness" : 27.03650794,
        "shared_name" : "Javert (interacts with) Cosette",
        "shared_interaction" : "interacts with",
        "name" : "Javert (interacts with) Cosette",
        "interaction" : "interacts with",
        "SUID" : 81891,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81876",
        "source" : "81790",
        "target" : "81772",
        "EdgeBetweenness" : 44.3047619,
        "shared_name" : "Javert (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Javert (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81876,
        "Strength" : 17,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82028",
        "source" : "81788",
        "target" : "81785",
        "EdgeBetweenness" : 34.69321365,
        "shared_name" : "Courfeyrac (interacts with) Gavroche",
        "shared_interaction" : "interacts with",
        "name" : "Courfeyrac (interacts with) Gavroche",
        "interaction" : "interacts with",
        "SUID" : 82028,
        "Strength" : 7,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81998",
        "source" : "81788",
        "target" : "81885",
        "EdgeBetweenness" : 21.47708174,
        "shared_name" : "Courfeyrac (interacts with) Enjolras",
        "shared_interaction" : "interacts with",
        "name" : "Courfeyrac (interacts with) Enjolras",
        "interaction" : "interacts with",
        "SUID" : 81998,
        "Strength" : 17,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81976",
        "source" : "81788",
        "target" : "81817",
        "EdgeBetweenness" : 3.48571429,
        "shared_name" : "Courfeyrac (interacts with) Combeferre",
        "shared_interaction" : "interacts with",
        "name" : "Courfeyrac (interacts with) Combeferre",
        "interaction" : "interacts with",
        "SUID" : 81976,
        "Strength" : 13,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81953",
        "source" : "81788",
        "target" : "81823",
        "EdgeBetweenness" : 5.66666667,
        "shared_name" : "Courfeyrac (interacts with) Mabeuf",
        "shared_interaction" : "interacts with",
        "name" : "Courfeyrac (interacts with) Mabeuf",
        "interaction" : "interacts with",
        "SUID" : 81953,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81905",
        "source" : "81788",
        "target" : "81883",
        "EdgeBetweenness" : 31.49705078,
        "shared_name" : "Courfeyrac (interacts with) Eponine",
        "shared_interaction" : "interacts with",
        "name" : "Courfeyrac (interacts with) Eponine",
        "interaction" : "interacts with",
        "SUID" : 81905,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81882",
        "source" : "81788",
        "target" : "81778",
        "EdgeBetweenness" : 3.48571429,
        "shared_name" : "Courfeyrac (interacts with) Feuilly",
        "shared_interaction" : "interacts with",
        "name" : "Courfeyrac (interacts with) Feuilly",
        "interaction" : "interacts with",
        "SUID" : 81882,
        "Strength" : 6,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81849",
        "source" : "81788",
        "target" : "81799",
        "EdgeBetweenness" : 59.59237376,
        "shared_name" : "Courfeyrac (interacts with) Marius",
        "shared_interaction" : "interacts with",
        "name" : "Courfeyrac (interacts with) Marius",
        "interaction" : "interacts with",
        "SUID" : 81849,
        "Strength" : 9,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81822",
        "source" : "81788",
        "target" : "81821",
        "EdgeBetweenness" : 9.14386724,
        "shared_name" : "Courfeyrac (interacts with) JeanProuvaire",
        "shared_interaction" : "interacts with",
        "name" : "Courfeyrac (interacts with) JeanProuvaire",
        "interaction" : "interacts with",
        "SUID" : 81822,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82083",
        "source" : "81787",
        "target" : "81819",
        "EdgeBetweenness" : 7.33145363,
        "shared_name" : "MadameHucheloup (interacts with) Bahorel",
        "shared_interaction" : "interacts with",
        "name" : "MadameHucheloup (interacts with) Bahorel",
        "interaction" : "interacts with",
        "SUID" : 82083,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82082",
        "source" : "81787",
        "target" : "81843",
        "EdgeBetweenness" : 28.53061631,
        "shared_name" : "MadameHucheloup (interacts with) LAigleDeMeauxBossuet ",
        "shared_interaction" : "interacts with",
        "name" : "MadameHucheloup (interacts with) LAigleDeMeauxBossuet ",
        "interaction" : "interacts with",
        "SUID" : 82082,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82018",
        "source" : "81787",
        "target" : "81885",
        "EdgeBetweenness" : 36.80477899,
        "shared_name" : "MadameHucheloup (interacts with) Enjolras",
        "shared_interaction" : "interacts with",
        "name" : "MadameHucheloup (interacts with) Enjolras",
        "interaction" : "interacts with",
        "SUID" : 82018,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81813",
        "source" : "81787",
        "target" : "81812",
        "EdgeBetweenness" : 2.85714286,
        "shared_name" : "MadameHucheloup (interacts with) Grantaire",
        "shared_interaction" : "interacts with",
        "name" : "MadameHucheloup (interacts with) Grantaire",
        "interaction" : "interacts with",
        "SUID" : 81813,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81807",
        "source" : "81787",
        "target" : "81785",
        "EdgeBetweenness" : 58.50783778,
        "shared_name" : "MadameHucheloup (interacts with) Gavroche",
        "shared_interaction" : "interacts with",
        "name" : "MadameHucheloup (interacts with) Gavroche",
        "interaction" : "interacts with",
        "SUID" : 81807,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81802",
        "source" : "81787",
        "target" : "81777",
        "EdgeBetweenness" : 7.33145363,
        "shared_name" : "MadameHucheloup (interacts with) Joly",
        "shared_interaction" : "interacts with",
        "name" : "MadameHucheloup (interacts with) Joly",
        "interaction" : "interacts with",
        "SUID" : 81802,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81789",
        "source" : "81787",
        "target" : "81788",
        "EdgeBetweenness" : 10.63671679,
        "shared_name" : "MadameHucheloup (interacts with) Courfeyrac",
        "shared_interaction" : "interacts with",
        "name" : "MadameHucheloup (interacts with) Courfeyrac",
        "interaction" : "interacts with",
        "SUID" : 81789,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82071",
        "source" : "81785",
        "target" : "81815",
        "EdgeBetweenness" : 106.96458962,
        "shared_name" : "Gavroche (interacts with) Thenardier",
        "shared_interaction" : "interacts with",
        "name" : "Gavroche (interacts with) Thenardier",
        "interaction" : "interacts with",
        "SUID" : 82071,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81870",
        "source" : "81785",
        "target" : "81869",
        "EdgeBetweenness" : 300.0,
        "shared_name" : "Gavroche (interacts with) MadameBurgon",
        "shared_interaction" : "interacts with",
        "name" : "Gavroche (interacts with) MadameBurgon",
        "interaction" : "interacts with",
        "SUID" : 81870,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81791",
        "source" : "81785",
        "target" : "81790",
        "EdgeBetweenness" : 121.27321122,
        "shared_name" : "Gavroche (interacts with) Javert",
        "shared_interaction" : "interacts with",
        "name" : "Gavroche (interacts with) Javert",
        "interaction" : "interacts with",
        "SUID" : 81791,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81786",
        "source" : "81785",
        "target" : "81772",
        "EdgeBetweenness" : 485.61343109,
        "shared_name" : "Gavroche (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Gavroche (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81786,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82060",
        "source" : "81783",
        "target" : "81797",
        "EdgeBetweenness" : 64.58717949,
        "shared_name" : "Bamatabois (interacts with) Fantine",
        "shared_interaction" : "interacts with",
        "name" : "Bamatabois (interacts with) Fantine",
        "interaction" : "interacts with",
        "SUID" : 82060,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82026",
        "source" : "81783",
        "target" : "81790",
        "EdgeBetweenness" : 36.52307692,
        "shared_name" : "Bamatabois (interacts with) Javert",
        "shared_interaction" : "interacts with",
        "name" : "Bamatabois (interacts with) Javert",
        "interaction" : "interacts with",
        "SUID" : 82026,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81784",
        "source" : "81783",
        "target" : "81772",
        "EdgeBetweenness" : 86.72307692,
        "shared_name" : "Bamatabois (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Bamatabois (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81784,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82085",
        "source" : "81781",
        "target" : "81783",
        "EdgeBetweenness" : 11.16666667,
        "shared_name" : "Judge (interacts with) Bamatabois",
        "shared_interaction" : "interacts with",
        "name" : "Judge (interacts with) Bamatabois",
        "interaction" : "interacts with",
        "SUID" : 82085,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81853",
        "source" : "81781",
        "target" : "81772",
        "EdgeBetweenness" : 132.83333333,
        "shared_name" : "Judge (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Judge (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81853,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82041",
        "source" : "81780",
        "target" : "81783",
        "EdgeBetweenness" : 11.16666667,
        "shared_name" : "Brevet (interacts with) Bamatabois",
        "shared_interaction" : "interacts with",
        "name" : "Brevet (interacts with) Bamatabois",
        "interaction" : "interacts with",
        "SUID" : 82041,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82036",
        "source" : "81780",
        "target" : "81887",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Brevet (interacts with) Champmathieu",
        "shared_interaction" : "interacts with",
        "name" : "Brevet (interacts with) Champmathieu",
        "interaction" : "interacts with",
        "SUID" : 82036,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81828",
        "source" : "81780",
        "target" : "81772",
        "EdgeBetweenness" : 132.83333333,
        "shared_name" : "Brevet (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Brevet (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81828,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81782",
        "source" : "81780",
        "target" : "81781",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Brevet (interacts with) Judge",
        "shared_interaction" : "interacts with",
        "name" : "Brevet (interacts with) Judge",
        "interaction" : "interacts with",
        "SUID" : 81782,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82044",
        "source" : "81778",
        "target" : "81799",
        "EdgeBetweenness" : 59.63535354,
        "shared_name" : "Feuilly (interacts with) Marius",
        "shared_interaction" : "interacts with",
        "name" : "Feuilly (interacts with) Marius",
        "interaction" : "interacts with",
        "SUID" : 82044,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82012",
        "source" : "81778",
        "target" : "81885",
        "EdgeBetweenness" : 22.63968254,
        "shared_name" : "Feuilly (interacts with) Enjolras",
        "shared_interaction" : "interacts with",
        "name" : "Feuilly (interacts with) Enjolras",
        "interaction" : "interacts with",
        "SUID" : 82012,
        "Strength" : 6,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82005",
        "source" : "81778",
        "target" : "81785",
        "EdgeBetweenness" : 39.66190476,
        "shared_name" : "Feuilly (interacts with) Gavroche",
        "shared_interaction" : "interacts with",
        "name" : "Feuilly (interacts with) Gavroche",
        "interaction" : "interacts with",
        "SUID" : 82005,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81993",
        "source" : "81778",
        "target" : "81823",
        "EdgeBetweenness" : 6.2,
        "shared_name" : "Feuilly (interacts with) Mabeuf",
        "shared_interaction" : "interacts with",
        "name" : "Feuilly (interacts with) Mabeuf",
        "interaction" : "interacts with",
        "SUID" : 81993,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81966",
        "source" : "81778",
        "target" : "81817",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Feuilly (interacts with) Combeferre",
        "shared_interaction" : "interacts with",
        "name" : "Feuilly (interacts with) Combeferre",
        "interaction" : "interacts with",
        "SUID" : 81966,
        "Strength" : 5,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81881",
        "source" : "81778",
        "target" : "81821",
        "EdgeBetweenness" : 5.56291486,
        "shared_name" : "Feuilly (interacts with) JeanProuvaire",
        "shared_interaction" : "interacts with",
        "name" : "Feuilly (interacts with) JeanProuvaire",
        "interaction" : "interacts with",
        "SUID" : 81881,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82095",
        "source" : "81777",
        "target" : "81885",
        "EdgeBetweenness" : 22.35396825,
        "shared_name" : "Joly (interacts with) Enjolras",
        "shared_interaction" : "interacts with",
        "name" : "Joly (interacts with) Enjolras",
        "interaction" : "interacts with",
        "SUID" : 82095,
        "Strength" : 5,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82087",
        "source" : "81777",
        "target" : "81788",
        "EdgeBetweenness" : 3.2,
        "shared_name" : "Joly (interacts with) Courfeyrac",
        "shared_interaction" : "interacts with",
        "name" : "Joly (interacts with) Courfeyrac",
        "interaction" : "interacts with",
        "SUID" : 82087,
        "Strength" : 5,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82030",
        "source" : "81777",
        "target" : "81817",
        "EdgeBetweenness" : 2.28571429,
        "shared_name" : "Joly (interacts with) Combeferre",
        "shared_interaction" : "interacts with",
        "name" : "Joly (interacts with) Combeferre",
        "interaction" : "interacts with",
        "SUID" : 82030,
        "Strength" : 5,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81979",
        "source" : "81777",
        "target" : "81819",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Joly (interacts with) Bahorel",
        "shared_interaction" : "interacts with",
        "name" : "Joly (interacts with) Bahorel",
        "interaction" : "interacts with",
        "SUID" : 81979,
        "Strength" : 5,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81952",
        "source" : "81777",
        "target" : "81785",
        "EdgeBetweenness" : 39.37619048,
        "shared_name" : "Joly (interacts with) Gavroche",
        "shared_interaction" : "interacts with",
        "name" : "Joly (interacts with) Gavroche",
        "interaction" : "interacts with",
        "SUID" : 81952,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81934",
        "source" : "81777",
        "target" : "81843",
        "EdgeBetweenness" : 16.36031746,
        "shared_name" : "Joly (interacts with) LAigleDeMeauxBossuet ",
        "shared_interaction" : "interacts with",
        "name" : "Joly (interacts with) LAigleDeMeauxBossuet ",
        "interaction" : "interacts with",
        "SUID" : 81934,
        "Strength" : 7,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81898",
        "source" : "81777",
        "target" : "81823",
        "EdgeBetweenness" : 6.86666667,
        "shared_name" : "Joly (interacts with) Mabeuf",
        "shared_interaction" : "interacts with",
        "name" : "Joly (interacts with) Mabeuf",
        "interaction" : "interacts with",
        "SUID" : 81898,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81892",
        "source" : "81777",
        "target" : "81799",
        "EdgeBetweenness" : 63.44299765,
        "shared_name" : "Joly (interacts with) Marius",
        "shared_interaction" : "interacts with",
        "name" : "Joly (interacts with) Marius",
        "interaction" : "interacts with",
        "SUID" : 81892,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81829",
        "source" : "81777",
        "target" : "81821",
        "EdgeBetweenness" : 5.84862915,
        "shared_name" : "Joly (interacts with) JeanProuvaire",
        "shared_interaction" : "interacts with",
        "name" : "Joly (interacts with) JeanProuvaire",
        "interaction" : "interacts with",
        "SUID" : 81829,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81779",
        "source" : "81777",
        "target" : "81778",
        "EdgeBetweenness" : 2.28571429,
        "shared_name" : "Joly (interacts with) Feuilly",
        "shared_interaction" : "interacts with",
        "name" : "Joly (interacts with) Feuilly",
        "interaction" : "interacts with",
        "SUID" : 81779,
        "Strength" : 5,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81950",
        "source" : "81775",
        "target" : "81830",
        "EdgeBetweenness" : 39.65238095,
        "shared_name" : "Listolier (interacts with) FelixTholomyes",
        "shared_interaction" : "interacts with",
        "name" : "Listolier (interacts with) FelixTholomyes",
        "interaction" : "interacts with",
        "SUID" : 81950,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82061",
        "source" : "81774",
        "target" : "81840",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Zephine (interacts with) Fameuil",
        "shared_interaction" : "interacts with",
        "name" : "Zephine (interacts with) Fameuil",
        "interaction" : "interacts with",
        "SUID" : 82061,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82000",
        "source" : "81774",
        "target" : "81830",
        "EdgeBetweenness" : 39.65238095,
        "shared_name" : "Zephine (interacts with) FelixTholomyes",
        "shared_interaction" : "interacts with",
        "name" : "Zephine (interacts with) FelixTholomyes",
        "interaction" : "interacts with",
        "SUID" : 82000,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81933",
        "source" : "81774",
        "target" : "81803",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Zephine (interacts with) Blacheville",
        "shared_interaction" : "interacts with",
        "name" : "Zephine (interacts with) Blacheville",
        "interaction" : "interacts with",
        "SUID" : 81933,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81914",
        "source" : "81774",
        "target" : "81912",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Zephine (interacts with) Favourite",
        "shared_interaction" : "interacts with",
        "name" : "Zephine (interacts with) Favourite",
        "interaction" : "interacts with",
        "SUID" : 81914,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81897",
        "source" : "81774",
        "target" : "81795",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Zephine (interacts with) Dahlia",
        "shared_interaction" : "interacts with",
        "name" : "Zephine (interacts with) Dahlia",
        "interaction" : "interacts with",
        "SUID" : 81897,
        "Strength" : 4,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81776",
        "source" : "81774",
        "target" : "81775",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Zephine (interacts with) Listolier",
        "shared_interaction" : "interacts with",
        "name" : "Zephine (interacts with) Listolier",
        "interaction" : "interacts with",
        "SUID" : 81776,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82090",
        "source" : "81772",
        "target" : "82089",
        "EdgeBetweenness" : 152.0,
        "shared_name" : "JeanValjean (interacts with) JacquinLabarre",
        "shared_interaction" : "interacts with",
        "name" : "JeanValjean (interacts with) JacquinLabarre",
        "interaction" : "interacts with",
        "SUID" : 82090,
        "Strength" : 1,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82068",
        "source" : "81772",
        "target" : "81793",
        "EdgeBetweenness" : 1072.0,
        "shared_name" : "JeanValjean (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "shared_interaction" : "interacts with",
        "name" : "JeanValjean (interacts with) BishopCharles-Francois-BienvenuMyriel",
        "interaction" : "interacts with",
        "SUID" : 82068,
        "Strength" : 5,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81984",
        "source" : "81772",
        "target" : "81983",
        "EdgeBetweenness" : 134.0,
        "shared_name" : "JeanValjean (interacts with) BaptistineMyrie",
        "shared_interaction" : "interacts with",
        "name" : "JeanValjean (interacts with) BaptistineMyrie",
        "interaction" : "interacts with",
        "SUID" : 81984,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81963",
        "source" : "81772",
        "target" : "81962",
        "EdgeBetweenness" : 134.0,
        "shared_name" : "JeanValjean (interacts with) MadameMagloire",
        "shared_interaction" : "interacts with",
        "name" : "JeanValjean (interacts with) MadameMagloire",
        "interaction" : "interacts with",
        "SUID" : 81963,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81854",
        "source" : "81771",
        "target" : "81800",
        "EdgeBetweenness" : 17.64285714,
        "shared_name" : "Gillenormand (interacts with) Cosette",
        "shared_interaction" : "interacts with",
        "name" : "Gillenormand (interacts with) Cosette",
        "interaction" : "interacts with",
        "SUID" : 81854,
        "Strength" : 3,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81773",
        "source" : "81771",
        "target" : "81772",
        "EdgeBetweenness" : 164.75511126,
        "shared_name" : "Gillenormand (interacts with) JeanValjean",
        "shared_interaction" : "interacts with",
        "name" : "Gillenormand (interacts with) JeanValjean",
        "interaction" : "interacts with",
        "SUID" : 81773,
        "Strength" : 2,
        "selected" : false
      },
      "selected" : false
    } ]
  }
},"ladysusan": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.7.1",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "ladysusan",
    "name" : "ladysusan",
    "SUID" : 81609,
    "__Annotations" : [ ],
    "selected" : false
  },
  "elements" : {
    "nodes" : [ ],
    "edges" : [ ]
  }
},"tblladysusandata2.csv": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.7.1",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "tblladysusandata2.csv",
    "name" : "tblladysusandata2.csv",
    "SUID" : 81621,
    "__Annotations" : [ ],
    "selected" : false
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "81658",
        "ClosenessCentrality" : 0.4375,
        "Eccentricity" : 3,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.67857143,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Miss Vernon",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Miss Vernon",
        "SelfLoops" : 0,
        "SUID" : 81658,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 1,
        "AverageShortestPathLength" : 2.28571429,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.0
      },
      "position" : {
        "x" : -165.11888122558594,
        "y" : -216.34601615906482
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81648",
        "ClosenessCentrality" : 0.4375,
        "Eccentricity" : 3,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.67857143,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Sir Reginald De Courcy",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Sir Reginald De Courcy",
        "SelfLoops" : 0,
        "SUID" : 81648,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 2,
        "AverageShortestPathLength" : 2.28571429,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.0
      },
      "position" : {
        "x" : 23.44921112060547,
        "y" : -57.36772918701172
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81639",
        "ClosenessCentrality" : 0.7,
        "Eccentricity" : 2,
        "Degree" : 10,
        "PartnerOfMultiEdgedNodePairs" : 3,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.89285714,
        "Stress" : 34,
        "TopologicalCoefficient" : 0.25,
        "shared_name" : "Mr. De Courcy",
        "BetweennessCentrality" : 0.80952381,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Mr. De Courcy",
        "SelfLoops" : 0,
        "SUID" : 81639,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 10,
        "AverageShortestPathLength" : 1.42857143,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.75
      },
      "position" : {
        "x" : -82.09011009214156,
        "y" : 164.93960479733457
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81637",
        "ClosenessCentrality" : 0.35,
        "Eccentricity" : 4,
        "Degree" : 14,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.53571429,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Lady De Courcy",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Lady De Courcy",
        "SelfLoops" : 0,
        "SUID" : 81637,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 14,
        "AverageShortestPathLength" : 2.85714286,
        "selected" : false,
        "NeighborhoodConnectivity" : 2.0
      },
      "position" : {
        "x" : -495.339470138557,
        "y" : -136.9994585418773
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81636",
        "ClosenessCentrality" : 0.5,
        "Eccentricity" : 3,
        "Degree" : 16,
        "PartnerOfMultiEdgedNodePairs" : 2,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.75,
        "Stress" : 12,
        "TopologicalCoefficient" : 0.5,
        "shared_name" : "Mrs. Vernon",
        "BetweennessCentrality" : 0.28571429,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Mrs. Vernon",
        "SelfLoops" : 0,
        "SUID" : 81636,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 16,
        "AverageShortestPathLength" : 2.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 2.5
      },
      "position" : {
        "x" : -282.51646469117645,
        "y" : 225.05074241636032
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81634",
        "ClosenessCentrality" : 0.38888889,
        "Eccentricity" : 4,
        "Degree" : 17,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.60714286,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Mrs. Johnson",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Mrs. Johnson",
        "SelfLoops" : 0,
        "SUID" : 81634,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 17,
        "AverageShortestPathLength" : 2.57142857,
        "selected" : false,
        "NeighborhoodConnectivity" : 3.0
      },
      "position" : {
        "x" : 431.6394107818245,
        "y" : -84.35581924437041
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81632",
        "ClosenessCentrality" : 0.38888889,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.60714286,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Mr. Vernon",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Mr. Vernon",
        "SelfLoops" : 0,
        "SUID" : 81632,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 1,
        "AverageShortestPathLength" : 2.57142857,
        "selected" : false,
        "NeighborhoodConnectivity" : 3.0
      },
      "position" : {
        "x" : 193.33087539672852,
        "y" : 10.149826049804688
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81631",
        "ClosenessCentrality" : 0.58333333,
        "Eccentricity" : 3,
        "Degree" : 23,
        "PartnerOfMultiEdgedNodePairs" : 2,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.82142857,
        "Stress" : 22,
        "TopologicalCoefficient" : 0.33333333,
        "shared_name" : "Lady Susan",
        "BetweennessCentrality" : 0.52380952,
        "NumberOfUndirectedEdges" : 0,
        "name" : "Lady Susan",
        "SelfLoops" : 0,
        "SUID" : 81631,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 23,
        "AverageShortestPathLength" : 1.71428571,
        "selected" : true,
        "NeighborhoodConnectivity" : 2.0
      },
      "position" : {
        "x" : 193.36065673828125,
        "y" : 199.09358955382584
      },
      "selected" : true
    } ],
    "edges" : [ {
      "data" : {
        "id" : "81659",
        "source" : "81658",
        "target" : "81639",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "Miss Vernon (interacts with) Mr. De Courcy",
        "Description" : "Letter 21 -- Miss Vernon to Mr. De Courcy ",
        "shared_interaction" : "interacts with",
        "name" : "Miss Vernon (interacts with) Mr. De Courcy",
        "interaction" : "interacts with",
        "SUID" : 81659,
        "Letter_No" : 21,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81649",
        "source" : "81648",
        "target" : "81639",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "Sir Reginald De Courcy (interacts with) Mr. De Courcy",
        "Description" : "Letter 12 -- Sir Reginald De Courcy to His Son",
        "shared_interaction" : "interacts with",
        "Coordinates" : "51.3241974854,-2.51400561211",
        "name" : "Sir Reginald De Courcy (interacts with) Mr. De Courcy",
        "interaction" : "interacts with",
        "SUID" : 81649,
        "Letter_No" : 12,
        "Place" : "Parklands",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81674",
        "source" : "81639",
        "target" : "81631",
        "EdgeBetweenness" : 30.0,
        "shared_name" : "Mr. De Courcy (interacts with) Lady Susan",
        "Description" : "Letter 36 -- Mr. De Courcy to Lady Susan",
        "shared_interaction" : "interacts with",
        "name" : "Mr. De Courcy (interacts with) Lady Susan",
        "interaction" : "interacts with",
        "SUID" : 81674,
        "Letter_No" : 36,
        "Place" : "Hotel",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81672",
        "source" : "81639",
        "target" : "81631",
        "EdgeBetweenness" : 30.0,
        "shared_name" : "Mr. De Courcy (interacts with) Lady Susan",
        "Description" : "Letter 34 -- Mr. De Courcy to Lady Susan",
        "shared_interaction" : "interacts with",
        "name" : "Mr. De Courcy (interacts with) Lady Susan",
        "interaction" : "interacts with",
        "SUID" : 81672,
        "Letter_No" : 34,
        "Place" : "Hotel",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81651",
        "source" : "81639",
        "target" : "81648",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "Mr. De Courcy (interacts with) Sir Reginald De Courcy",
        "Description" : "Letter 14 -- Mr. De Courcy to Sir Reginald ",
        "shared_interaction" : "interacts with",
        "Coordinates" : "51.3354,-2.7963",
        "name" : "Mr. De Courcy (interacts with) Sir Reginald De Courcy",
        "interaction" : "interacts with",
        "SUID" : 81651,
        "Letter_No" : 14,
        "Place" : "Churchhill",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81640",
        "source" : "81639",
        "target" : "81636",
        "EdgeBetweenness" : 24.0,
        "shared_name" : "Mr. De Courcy (interacts with) Mrs. Vernon",
        "Description" : "Letter 4 -- Mr. De Courcy to Mrs. Vernon",
        "shared_interaction" : "interacts with",
        "Coordinates" : "51.3241974854,-2.51400561211",
        "name" : "Mr. De Courcy (interacts with) Mrs. Vernon",
        "interaction" : "interacts with",
        "SUID" : 81640,
        "Letter_No" : 4,
        "Place" : "Parklands",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81678",
        "source" : "81637",
        "target" : "81636",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "Lady De Courcy (interacts with) Mrs. Vernon",
        "Description" : "Letter 40 -- Lady De Courcy to Mrs. Vernon ",
        "shared_interaction" : "interacts with",
        "name" : "Lady De Courcy (interacts with) Mrs. Vernon",
        "interaction" : "interacts with",
        "SUID" : 81678,
        "Letter_No" : 40,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81650",
        "source" : "81637",
        "target" : "81636",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "Lady De Courcy (interacts with) Mrs. Vernon",
        "Description" : "Letter 13 -- Lady De Courcy to Mrs. Vernon",
        "shared_interaction" : "interacts with",
        "Coordinates" : "51.3241974854,-2.51400561211",
        "name" : "Lady De Courcy (interacts with) Mrs. Vernon",
        "interaction" : "interacts with",
        "SUID" : 81650,
        "Letter_No" : 13,
        "Place" : "Parklands",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81680",
        "source" : "81636",
        "target" : "81637",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "Mrs. Vernon (interacts with) Lady De Courcy",
        "Description" : "Conclusion -- Mrs. Vernon to Lady De Courcy",
        "shared_interaction" : "interacts with",
        "name" : "Mrs. Vernon (interacts with) Lady De Courcy",
        "interaction" : "interacts with",
        "SUID" : 81680,
        "Letter_No" : 42,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81679",
        "source" : "81636",
        "target" : "81637",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "Mrs. Vernon (interacts with) Lady De Courcy",
        "Description" : "Letter 41 -- Mrs. Vernon to Lady De Courcy ",
        "shared_interaction" : "interacts with",
        "Coordinates" : "51.3354,-2.7963",
        "name" : "Mrs. Vernon (interacts with) Lady De Courcy",
        "interaction" : "interacts with",
        "SUID" : 81679,
        "Letter_No" : 41,
        "Place" : "Churchhill",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81665",
        "source" : "81636",
        "target" : "81637",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "Mrs. Vernon (interacts with) Lady De Courcy",
        "Description" : "Letter 27 -- Mrs. Vernon to Lady De Courcy",
        "shared_interaction" : "interacts with",
        "Coordinates" : "51.3354,-2.7963",
        "name" : "Mrs. Vernon (interacts with) Lady De Courcy",
        "interaction" : "interacts with",
        "SUID" : 81665,
        "Letter_No" : 27,
        "Place" : "Churchhill",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81662",
        "source" : "81636",
        "target" : "81637",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "Mrs. Vernon (interacts with) Lady De Courcy",
        "Description" : "Letter 24 -- From the Same to the Same ",
        "shared_interaction" : "interacts with",
        "Coordinates" : "51.3354,-2.7963",
        "name" : "Mrs. Vernon (interacts with) Lady De Courcy",
        "interaction" : "interacts with",
        "SUID" : 81662,
        "Letter_No" : 24,
        "Place" : "Churchhill",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81661",
        "source" : "81636",
        "target" : "81637",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "Mrs. Vernon (interacts with) Lady De Courcy",
        "Description" : "Letter 23 -- Mrs. Vernon to Lady De Courcy",
        "shared_interaction" : "interacts with",
        "Coordinates" : "51.3354,-2.7963",
        "name" : "Mrs. Vernon (interacts with) Lady De Courcy",
        "interaction" : "interacts with",
        "SUID" : 81661,
        "Letter_No" : 23,
        "Place" : "Churchhill",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81657",
        "source" : "81636",
        "target" : "81637",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "Mrs. Vernon (interacts with) Lady De Courcy",
        "Description" : "Letter 20 -- Mrs. Vernon to Lady De Courcy ",
        "shared_interaction" : "interacts with",
        "Coordinates" : "51.3354,-2.7963",
        "name" : "Mrs. Vernon (interacts with) Lady De Courcy",
        "interaction" : "interacts with",
        "SUID" : 81657,
        "Letter_No" : 20,
        "Place" : "Churchhill",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81655",
        "source" : "81636",
        "target" : "81637",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "Mrs. Vernon (interacts with) Lady De Courcy",
        "Description" : "Letter 18 -- From the Same to the Same ",
        "shared_interaction" : "interacts with",
        "Coordinates" : "51.3354,-2.7963",
        "name" : "Mrs. Vernon (interacts with) Lady De Courcy",
        "interaction" : "interacts with",
        "SUID" : 81655,
        "Letter_No" : 18,
        "Place" : "Churchhill",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81654",
        "source" : "81636",
        "target" : "81637",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "Mrs. Vernon (interacts with) Lady De Courcy",
        "Description" : "Letter 17 -- Mrs. Vernon to Lady De Courcy",
        "shared_interaction" : "interacts with",
        "Coordinates" : "51.3354,-2.7963",
        "name" : "Mrs. Vernon (interacts with) Lady De Courcy",
        "interaction" : "interacts with",
        "SUID" : 81654,
        "Letter_No" : 17,
        "Place" : "Churchhill",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81652",
        "source" : "81636",
        "target" : "81637",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "Mrs. Vernon (interacts with) Lady De Courcy",
        "Description" : "Letter 15 -- Mrs. Vernon to Lady De Courcy",
        "shared_interaction" : "interacts with",
        "Coordinates" : "51.3354,-2.7963",
        "name" : "Mrs. Vernon (interacts with) Lady De Courcy",
        "interaction" : "interacts with",
        "SUID" : 81652,
        "Letter_No" : 15,
        "Place" : "Churchhill",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81647",
        "source" : "81636",
        "target" : "81637",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "Mrs. Vernon (interacts with) Lady De Courcy",
        "Description" : "Letter 11 -- Mrs. Vernon to Lady De Courcy",
        "shared_interaction" : "interacts with",
        "Coordinates" : "51.3354,-2.7963",
        "name" : "Mrs. Vernon (interacts with) Lady De Courcy",
        "interaction" : "interacts with",
        "SUID" : 81647,
        "Letter_No" : 11,
        "Place" : "Churchhill",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81644",
        "source" : "81636",
        "target" : "81637",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "Mrs. Vernon (interacts with) Lady De Courcy",
        "Description" : "Letter 8 -- Mrs. Vernon to Lady De Courcy",
        "shared_interaction" : "interacts with",
        "Coordinates" : "51.3354,-2.7963",
        "name" : "Mrs. Vernon (interacts with) Lady De Courcy",
        "interaction" : "interacts with",
        "SUID" : 81644,
        "Letter_No" : 8,
        "Place" : "Churchhill",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81642",
        "source" : "81636",
        "target" : "81639",
        "EdgeBetweenness" : 24.0,
        "shared_name" : "Mrs. Vernon (interacts with) Mr. De Courcy",
        "Description" : "Letter 6 -- Mrs. Vernon to Mr. De Courcy",
        "shared_interaction" : "interacts with",
        "Coordinates" : "51.3354,-2.7963",
        "name" : "Mrs. Vernon (interacts with) Mr. De Courcy",
        "interaction" : "interacts with",
        "SUID" : 81642,
        "Letter_No" : 6,
        "Place" : "Churchhill",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81638",
        "source" : "81636",
        "target" : "81637",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "Mrs. Vernon (interacts with) Lady De Courcy",
        "Description" : "Letter 3 -- Mrs. Vernon to Lady De Courcy ",
        "shared_interaction" : "interacts with",
        "Coordinates" : "51.3354,-2.7963",
        "name" : "Mrs. Vernon (interacts with) Lady De Courcy",
        "interaction" : "interacts with",
        "SUID" : 81638,
        "Letter_No" : 3,
        "Place" : "Churchhill",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81676",
        "source" : "81634",
        "target" : "81631",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "Mrs. Johnson (interacts with) Lady Susan",
        "Description" : "Letter 38 -- Mrs. Johnson to Lady Susan Vernon ",
        "shared_interaction" : "interacts with",
        "Coordinates" : "51.4798,-0.0311",
        "name" : "Mrs. Johnson (interacts with) Lady Susan",
        "interaction" : "interacts with",
        "SUID" : 81676,
        "Letter_No" : 38,
        "Place" : "Edward Street",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81670",
        "source" : "81634",
        "target" : "81631",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "Mrs. Johnson (interacts with) Lady Susan",
        "Description" : "Letter 32 -- Mrs. Johnson to Lady Susan",
        "shared_interaction" : "interacts with",
        "Coordinates" : "51.4798,-0.0311",
        "name" : "Mrs. Johnson (interacts with) Lady Susan",
        "interaction" : "interacts with",
        "SUID" : 81670,
        "Letter_No" : 32,
        "Place" : "Edward Street",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81666",
        "source" : "81634",
        "target" : "81631",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "Mrs. Johnson (interacts with) Lady Susan",
        "Description" : "Letter 28 -- Mrs. Johnson to Lady Susan",
        "shared_interaction" : "interacts with",
        "Coordinates" : "51.4798,-0.0311",
        "name" : "Mrs. Johnson (interacts with) Lady Susan",
        "interaction" : "interacts with",
        "SUID" : 81666,
        "Letter_No" : 28,
        "Place" : "Edward Street",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81664",
        "source" : "81634",
        "target" : "81631",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "Mrs. Johnson (interacts with) Lady Susan",
        "Description" : "Letter 26 -- Mrs. Johnson to Lady Susan",
        "shared_interaction" : "interacts with",
        "Coordinates" : "51.4798,-0.0311",
        "name" : "Mrs. Johnson (interacts with) Lady Susan",
        "interaction" : "interacts with",
        "SUID" : 81664,
        "Letter_No" : 26,
        "Place" : "Edward Street",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81645",
        "source" : "81634",
        "target" : "81631",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "Mrs. Johnson (interacts with) Lady Susan",
        "Description" : "Letter 9 -- Mrs. Johnson to Lady Susan",
        "shared_interaction" : "interacts with",
        "Coordinates" : "51.4798,-0.0311",
        "name" : "Mrs. Johnson (interacts with) Lady Susan",
        "interaction" : "interacts with",
        "SUID" : 81645,
        "Letter_No" : 9,
        "Place" : "Edward Street",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81677",
        "source" : "81631",
        "target" : "81634",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "Lady Susan (interacts with) Mrs. Johnson",
        "Description" : "Letter 39 -- Lady Susan to Mrs. Johnson",
        "shared_interaction" : "interacts with",
        "Coordinates" : "51.515419, -0.141099",
        "name" : "Lady Susan (interacts with) Mrs. Johnson",
        "interaction" : "interacts with",
        "SUID" : 81677,
        "Letter_No" : 39,
        "Place" : "Upper Seymour Street.",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81675",
        "source" : "81631",
        "target" : "81639",
        "EdgeBetweenness" : 30.0,
        "shared_name" : "Lady Susan (interacts with) Mr. De Courcy",
        "Description" : "Letter 37 -- Lady Susan to Mr. De Courcy",
        "shared_interaction" : "interacts with",
        "Coordinates" : "51.515419,-0.141099",
        "name" : "Lady Susan (interacts with) Mr. De Courcy",
        "interaction" : "interacts with",
        "SUID" : 81675,
        "Letter_No" : 37,
        "Place" : "Upper Seymour Street",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81673",
        "source" : "81631",
        "target" : "81639",
        "EdgeBetweenness" : 30.0,
        "shared_name" : "Lady Susan (interacts with) Mr. De Courcy",
        "Description" : "Letter 35 -- Lady Susan to Mr. De Courcy",
        "shared_interaction" : "interacts with",
        "Coordinates" : "51.515419,-0.141099",
        "name" : "Lady Susan (interacts with) Mr. De Courcy",
        "interaction" : "interacts with",
        "SUID" : 81673,
        "Letter_No" : 35,
        "Place" : "Upper Seymour Street",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81671",
        "source" : "81631",
        "target" : "81634",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "Lady Susan (interacts with) Mrs. Johnson",
        "Description" : "Letter 33 -- Lady Susan to Mrs. Johnson ",
        "shared_interaction" : "interacts with",
        "Coordinates" : "51.515419,-0.141099",
        "name" : "Lady Susan (interacts with) Mrs. Johnson",
        "interaction" : "interacts with",
        "SUID" : 81671,
        "Letter_No" : 33,
        "Place" : "Upper Seymour Street",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81669",
        "source" : "81631",
        "target" : "81634",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "Lady Susan (interacts with) Mrs. Johnson",
        "Description" : "Letter 31 -- Lady Susan to Mrs. Johnson",
        "shared_interaction" : "interacts with",
        "Coordinates" : "51.515419,-0.141099",
        "name" : "Lady Susan (interacts with) Mrs. Johnson",
        "interaction" : "interacts with",
        "SUID" : 81669,
        "Letter_No" : 31,
        "Place" : "Upper Seymour Street",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81668",
        "source" : "81631",
        "target" : "81639",
        "EdgeBetweenness" : 30.0,
        "shared_name" : "Lady Susan (interacts with) Mr. De Courcy",
        "Description" : "Letter 30 -- Lady Susan to Mr. De Courcy",
        "shared_interaction" : "interacts with",
        "Coordinates" : "51.515419,-0.141099",
        "name" : "Lady Susan (interacts with) Mr. De Courcy",
        "interaction" : "interacts with",
        "SUID" : 81668,
        "Letter_No" : 30,
        "Place" : "Upper Seymour Street",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81667",
        "source" : "81631",
        "target" : "81634",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "Lady Susan (interacts with) Mrs. Johnson",
        "Description" : "Letter 29 -- Lady Susan to Mrs. Johnson",
        "shared_interaction" : "interacts with",
        "Coordinates" : "51.515419,-0.141099",
        "name" : "Lady Susan (interacts with) Mrs. Johnson",
        "interaction" : "interacts with",
        "SUID" : 81667,
        "Letter_No" : 29,
        "Place" : "Upper Seymour Street",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81663",
        "source" : "81631",
        "target" : "81634",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "Lady Susan (interacts with) Mrs. Johnson",
        "Description" : "Letter 25 -- Lady Susan to Mrs. Johnson",
        "shared_interaction" : "interacts with",
        "Coordinates" : "51.3354,-2.7963",
        "name" : "Lady Susan (interacts with) Mrs. Johnson",
        "interaction" : "interacts with",
        "SUID" : 81663,
        "Letter_No" : 25,
        "Place" : "Churchhill",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81660",
        "source" : "81631",
        "target" : "81634",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "Lady Susan (interacts with) Mrs. Johnson",
        "Description" : "Letter 22 -- Lady Susan to Mrs. Johnson ",
        "shared_interaction" : "interacts with",
        "Coordinates" : "51.3354,-2.7963",
        "name" : "Lady Susan (interacts with) Mrs. Johnson",
        "interaction" : "interacts with",
        "SUID" : 81660,
        "Letter_No" : 22,
        "Place" : "Churchhill",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81656",
        "source" : "81631",
        "target" : "81634",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "Lady Susan (interacts with) Mrs. Johnson",
        "Description" : "Letter 19 -- Lady Susan to Mrs. Johnson",
        "shared_interaction" : "interacts with",
        "Coordinates" : "51.3354,-2.7963",
        "name" : "Lady Susan (interacts with) Mrs. Johnson",
        "interaction" : "interacts with",
        "SUID" : 81656,
        "Letter_No" : 19,
        "Place" : "Churchhill",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81653",
        "source" : "81631",
        "target" : "81634",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "Lady Susan (interacts with) Mrs. Johnson",
        "Description" : "Letter 16 -- Lady Susan to Mrs. Johnson ",
        "shared_interaction" : "interacts with",
        "Coordinates" : "51.3354,-2.7963",
        "name" : "Lady Susan (interacts with) Mrs. Johnson",
        "interaction" : "interacts with",
        "SUID" : 81653,
        "Letter_No" : 16,
        "Place" : "Churchhill",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81646",
        "source" : "81631",
        "target" : "81634",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "Lady Susan (interacts with) Mrs. Johnson",
        "Description" : "Letter 10 -- Lady Susan to Mrs. Johnson",
        "shared_interaction" : "interacts with",
        "Coordinates" : "51.3354,-2.7963",
        "name" : "Lady Susan (interacts with) Mrs. Johnson",
        "interaction" : "interacts with",
        "SUID" : 81646,
        "Letter_No" : 10,
        "Place" : "Churchhill",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81643",
        "source" : "81631",
        "target" : "81634",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "Lady Susan (interacts with) Mrs. Johnson",
        "Description" : "Letter 7 -- Lady Susan to Mrs. Johnson",
        "shared_interaction" : "interacts with",
        "Coordinates" : "51.3354,-2.7963",
        "name" : "Lady Susan (interacts with) Mrs. Johnson",
        "interaction" : "interacts with",
        "SUID" : 81643,
        "Letter_No" : 7,
        "Place" : "Churchhill",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81641",
        "source" : "81631",
        "target" : "81634",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "Lady Susan (interacts with) Mrs. Johnson",
        "Description" : "Letter 5 -- Lady Susan to Mrs. Johnson",
        "shared_interaction" : "interacts with",
        "Coordinates" : "51.3354,-2.7963",
        "name" : "Lady Susan (interacts with) Mrs. Johnson",
        "interaction" : "interacts with",
        "SUID" : 81641,
        "Letter_No" : 5,
        "Place" : "Churchhill",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81635",
        "source" : "81631",
        "target" : "81634",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "Lady Susan (interacts with) Mrs. Johnson",
        "Description" : "Letter 2 -- Lady Susan to Mrs. Johnson",
        "shared_interaction" : "interacts with",
        "Coordinates" : "51.34,-2.782",
        "name" : "Lady Susan (interacts with) Mrs. Johnson",
        "interaction" : "interacts with",
        "SUID" : 81635,
        "Letter_No" : 2,
        "Place" : "Langford",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81633",
        "source" : "81631",
        "target" : "81632",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "Lady Susan (interacts with) Mr. Vernon",
        "Description" : "Letter 1 --  Lady Susan to Mr. Vernon",
        "shared_interaction" : "interacts with",
        "Coordinates" : "51.34,-2.782",
        "name" : "Lady Susan (interacts with) Mr. Vernon",
        "interaction" : "interacts with",
        "SUID" : 81633,
        "Letter_No" : 1,
        "Place" : "Langford",
        "selected" : false
      },
      "selected" : false
    } ]
  }
}}