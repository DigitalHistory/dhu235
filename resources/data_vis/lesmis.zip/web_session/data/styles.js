var styles = [ {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.7.1",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Ripple",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "text-valign" : "center",
      "text-halign" : "center",
      "width" : 50.0,
      "border-width" : 20.0,
      "height" : 50.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,255)",
      "font-size" : 8,
      "color" : "rgb(19,58,96)",
      "border-color" : "rgb(51,153,255)",
      "text-opacity" : 1.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "border-opacity" : 1.0,
      "background-opacity" : 1.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,204)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 10,
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "none",
      "target-arrow-color" : "rgb(0,0,0)",
      "line-style" : "solid",
      "width" : 3.0,
      "color" : "rgb(0,0,0)",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "text-opacity" : 1.0,
      "line-color" : "rgb(51,153,255)",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "",
      "opacity" : 1.0
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.7.1",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "NetworkAnalyzer Style: lesmis.txt_2_1",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "text-valign" : "center",
      "text-halign" : "center",
      "width" : 30.0,
      "border-width" : 0.5,
      "height" : 30.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,255)",
      "font-size" : 12,
      "color" : "rgb(130,130,130)",
      "border-color" : "rgb(0,0,0)",
      "text-opacity" : 1.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "border-opacity" : 1.0,
      "background-opacity" : 0.7843137254901961,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node[Degree > 36]",
    "css" : {
      "background-color" : "rgb(252,141,89)"
    }
  }, {
    "selector" : "node[Degree = 36]",
    "css" : {
      "background-color" : "rgb(252,141,89)"
    }
  }, {
    "selector" : "node[Degree > 6.5974026][Degree < 36]",
    "css" : {
      "background-color" : "mapData(Degree,6.5974026,36,rgb(255,255,191),rgb(252,141,89))"
    }
  }, {
    "selector" : "node[Degree > 1][Degree < 6.5974026]",
    "css" : {
      "background-color" : "mapData(Degree,1,6.5974026,rgb(145,191,219),rgb(255,255,191))"
    }
  }, {
    "selector" : "node[Degree = 1]",
    "css" : {
      "background-color" : "rgb(145,191,219)"
    }
  }, {
    "selector" : "node[Degree < 1]",
    "css" : {
      "background-color" : "rgb(145,191,219)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 10,
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "none",
      "target-arrow-color" : "rgb(0,0,0)",
      "line-style" : "solid",
      "width" : 3.0,
      "color" : "rgb(0,0,0)",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "text-opacity" : 1.0,
      "line-color" : "rgb(64,64,64)",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "",
      "opacity" : 0.39215686274509803
    }
  }, {
    "selector" : "edge[Strength > 31]",
    "css" : {
      "width" : 8.0
    }
  }, {
    "selector" : "edge[Strength = 31]",
    "css" : {
      "width" : 8.0
    }
  }, {
    "selector" : "edge[Strength > 3.22834646][Strength < 31]",
    "css" : {
      "width" : "mapData(Strength,3.22834646,31,4.0,8.0)"
    }
  }, {
    "selector" : "edge[Strength > 1][Strength < 3.22834646]",
    "css" : {
      "width" : "mapData(Strength,1,3.22834646,1.0,4.0)"
    }
  }, {
    "selector" : "edge[Strength = 1]",
    "css" : {
      "width" : 1.0
    }
  }, {
    "selector" : "edge[Strength < 1]",
    "css" : {
      "width" : 1.0
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.7.1",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Marquee",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "text-valign" : "bottom",
      "text-halign" : "center",
      "width" : 20.0,
      "border-width" : 10.0,
      "height" : 20.0,
      "shape" : "ellipse",
      "background-color" : "rgb(0,204,255)",
      "font-size" : 12,
      "color" : "rgb(102,102,102)",
      "border-color" : "rgb(255,255,255)",
      "text-opacity" : 1.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "border-opacity" : 1.0,
      "background-opacity" : 1.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,0,102)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 8,
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "triangle",
      "target-arrow-color" : "rgb(255,255,255)",
      "line-style" : "dashed",
      "width" : 2.0,
      "color" : "rgb(102,102,102)",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "text-opacity" : 1.0,
      "line-color" : "rgb(255,255,255)",
      "source-arrow-color" : "rgb(255,255,255)",
      "opacity" : 1.0,
      "content" : "data(interaction)"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.7.1",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Sample1",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "text-valign" : "center",
      "text-halign" : "center",
      "width" : 25.0,
      "border-width" : 0.0,
      "height" : 25.0,
      "shape" : "ellipse",
      "background-color" : "rgb(127,205,187)",
      "font-size" : 10,
      "color" : "rgb(51,51,51)",
      "border-color" : "rgb(0,0,0)",
      "text-opacity" : 1.0,
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "border-opacity" : 1.0,
      "background-opacity" : 1.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 10,
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "none",
      "target-arrow-color" : "rgb(0,0,0)",
      "line-style" : "solid",
      "width" : 1.0,
      "color" : "rgb(51,51,51)",
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "text-opacity" : 1.0,
      "line-color" : "rgb(153,153,153)",
      "source-arrow-color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "content" : "data(interaction)"
    }
  }, {
    "selector" : "edge[interaction = 'pp']",
    "css" : {
      "line-style" : "solid"
    }
  }, {
    "selector" : "edge[interaction = 'pd']",
    "css" : {
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.7.1",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "NetworkAnalyzer Style: tblladysusandata2.csv_2",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "text-valign" : "center",
      "text-halign" : "center",
      "width" : 30.0,
      "border-width" : 0.0,
      "height" : 30.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,255)",
      "font-size" : 12,
      "color" : "rgb(130,130,130)",
      "border-color" : "rgb(0,0,0)",
      "text-opacity" : 1.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "border-opacity" : 1.0,
      "background-opacity" : 0.7843137254901961,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node[BetweennessCentrality > 0.80952381]",
    "css" : {
      "background-color" : "rgb(252,141,89)"
    }
  }, {
    "selector" : "node[BetweennessCentrality = 0.80952381]",
    "css" : {
      "background-color" : "rgb(252,141,89)"
    }
  }, {
    "selector" : "node[BetweennessCentrality > 0.20238095][BetweennessCentrality < 0.80952381]",
    "css" : {
      "background-color" : "mapData(BetweennessCentrality,0.20238095,0.80952381,rgb(255,255,191),rgb(252,141,89))"
    }
  }, {
    "selector" : "node[BetweennessCentrality > 0][BetweennessCentrality < 0.20238095]",
    "css" : {
      "background-color" : "mapData(BetweennessCentrality,0,0.20238095,rgb(145,191,219),rgb(255,255,191))"
    }
  }, {
    "selector" : "node[BetweennessCentrality = 0]",
    "css" : {
      "background-color" : "rgb(145,191,219)"
    }
  }, {
    "selector" : "node[BetweennessCentrality < 0]",
    "css" : {
      "background-color" : "rgb(145,191,219)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 10,
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "none",
      "target-arrow-color" : "rgb(0,0,0)",
      "line-style" : "solid",
      "width" : 3.0,
      "color" : "rgb(0,0,0)",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "text-opacity" : 1.0,
      "line-color" : "rgb(64,64,64)",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "",
      "opacity" : 0.39215686274509803
    }
  }, {
    "selector" : "edge[EdgeBetweenness > 30]",
    "css" : {
      "width" : 8.0
    }
  }, {
    "selector" : "edge[EdgeBetweenness = 30]",
    "css" : {
      "width" : 8.0
    }
  }, {
    "selector" : "edge[EdgeBetweenness > 16.38095238][EdgeBetweenness < 30]",
    "css" : {
      "width" : "mapData(EdgeBetweenness,16.38095238,30,4.0,8.0)"
    }
  }, {
    "selector" : "edge[EdgeBetweenness > 14][EdgeBetweenness < 16.38095238]",
    "css" : {
      "width" : "mapData(EdgeBetweenness,14,16.38095238,1.0,4.0)"
    }
  }, {
    "selector" : "edge[EdgeBetweenness = 14]",
    "css" : {
      "width" : 1.0
    }
  }, {
    "selector" : "edge[EdgeBetweenness < 14]",
    "css" : {
      "width" : 1.0
    }
  }, {
    "selector" : "edge[EdgeBetweenness > 30]",
    "css" : {
      "line-color" : "rgb(145,191,219)"
    }
  }, {
    "selector" : "edge[EdgeBetweenness = 30]",
    "css" : {
      "line-color" : "rgb(145,191,219)"
    }
  }, {
    "selector" : "edge[EdgeBetweenness > 16.38095238][EdgeBetweenness < 30]",
    "css" : {
      "line-color" : "mapData(EdgeBetweenness,16.38095238,30,rgb(255,255,191),rgb(145,191,219))"
    }
  }, {
    "selector" : "edge[EdgeBetweenness > 14][EdgeBetweenness < 16.38095238]",
    "css" : {
      "line-color" : "mapData(EdgeBetweenness,14,16.38095238,rgb(252,141,89),rgb(255,255,191))"
    }
  }, {
    "selector" : "edge[EdgeBetweenness = 14]",
    "css" : {
      "line-color" : "rgb(252,141,89)"
    }
  }, {
    "selector" : "edge[EdgeBetweenness < 14]",
    "css" : {
      "line-color" : "rgb(252,141,89)"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.7.1",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "NetworkAnalyzer Style: lesmis.txt_2_0",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "text-valign" : "center",
      "text-halign" : "center",
      "width" : 30.0,
      "border-width" : 0.0,
      "height" : 30.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,255)",
      "font-size" : 12,
      "color" : "rgb(130,130,130)",
      "border-color" : "rgb(0,0,0)",
      "text-opacity" : 1.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "border-opacity" : 1.0,
      "background-opacity" : 0.7843137254901961,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 10,
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "none",
      "target-arrow-color" : "rgb(0,0,0)",
      "line-style" : "solid",
      "width" : 3.0,
      "color" : "rgb(0,0,0)",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "text-opacity" : 1.0,
      "line-color" : "rgb(64,64,64)",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "",
      "opacity" : 0.39215686274509803
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.7.1",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Solid",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "text-valign" : "center",
      "text-halign" : "center",
      "width" : 40.0,
      "border-width" : 0.0,
      "height" : 40.0,
      "shape" : "ellipse",
      "background-color" : "rgb(102,102,102)",
      "font-size" : 14,
      "color" : "rgb(0,0,0)",
      "border-color" : "rgb(0,0,0)",
      "text-opacity" : 1.0,
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "border-opacity" : 1.0,
      "background-opacity" : 1.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 10,
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "none",
      "target-arrow-color" : "rgb(0,0,0)",
      "line-style" : "solid",
      "width" : 12.0,
      "color" : "rgb(0,0,0)",
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "text-opacity" : 1.0,
      "line-color" : "rgb(204,204,204)",
      "source-arrow-color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "content" : "data(interaction)"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.7.1",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "NetworkAnalyzer Style: tblladysusandata2.csv_1",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "text-valign" : "center",
      "text-halign" : "center",
      "width" : 30.0,
      "border-width" : 0.0,
      "height" : 30.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,255)",
      "font-size" : 12,
      "color" : "rgb(130,130,130)",
      "border-color" : "rgb(0,0,0)",
      "text-opacity" : 1.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "border-opacity" : 1.0,
      "background-opacity" : 0.7843137254901961,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 10,
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "none",
      "target-arrow-color" : "rgb(0,0,0)",
      "line-style" : "solid",
      "width" : 3.0,
      "color" : "rgb(0,0,0)",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "text-opacity" : 1.0,
      "line-color" : "rgb(64,64,64)",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "",
      "opacity" : 0.39215686274509803
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.7.1",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "default black",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "text-valign" : "bottom",
      "text-halign" : "right",
      "width" : 15.0,
      "border-width" : 0.0,
      "height" : 15.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,255)",
      "font-size" : 12,
      "color" : "rgb(204,204,204)",
      "border-color" : "rgb(0,153,0)",
      "text-opacity" : 1.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "border-opacity" : 1.0,
      "background-opacity" : 1.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 10,
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "none",
      "target-arrow-color" : "rgb(0,0,0)",
      "line-style" : "solid",
      "width" : 2.0,
      "color" : "rgb(0,0,0)",
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "text-opacity" : 1.0,
      "line-color" : "rgb(0,153,0)",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "",
      "opacity" : 1.0
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.7.1",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Minimal",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "text-valign" : "center",
      "text-halign" : "center",
      "width" : 42.0,
      "border-width" : 0.0,
      "height" : 42.0,
      "shape" : "rectangle",
      "background-color" : "rgb(255,255,255)",
      "font-size" : 9,
      "color" : "rgb(51,51,51)",
      "border-color" : "rgb(0,0,0)",
      "text-opacity" : 1.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "border-opacity" : 1.0,
      "background-opacity" : 1.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 10,
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "none",
      "target-arrow-color" : "rgb(0,0,0)",
      "line-style" : "solid",
      "width" : 2.0,
      "color" : "rgb(0,0,0)",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "text-opacity" : 1.0,
      "line-color" : "rgb(76,76,76)",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "",
      "opacity" : 1.0
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.7.1",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Sample3",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "text-valign" : "bottom",
      "text-halign" : "right",
      "width" : 20.0,
      "border-width" : 8.0,
      "height" : 20.0,
      "shape" : "ellipse",
      "background-color" : "rgb(61,154,255)",
      "font-size" : 14,
      "color" : "rgb(206,206,206)",
      "border-color" : "rgb(255,255,255)",
      "text-opacity" : 1.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "border-opacity" : 1.0,
      "background-opacity" : 1.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 10,
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "none",
      "target-arrow-color" : "rgb(0,0,0)",
      "line-style" : "solid",
      "width" : 2.0,
      "color" : "rgb(0,0,0)",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "text-opacity" : 1.0,
      "line-color" : "rgb(255,255,255)",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "",
      "opacity" : 1.0
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.7.1",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "default",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "text-valign" : "center",
      "text-halign" : "center",
      "width" : 75.0,
      "border-width" : 0.5,
      "height" : 35.0,
      "shape" : "ellipse",
      "background-color" : "rgb(137,208,245)",
      "font-size" : 12,
      "color" : "rgb(0,0,0)",
      "border-color" : "rgb(204,204,204)",
      "text-opacity" : 1.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "border-opacity" : 1.0,
      "background-opacity" : 1.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 10,
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "none",
      "target-arrow-color" : "rgb(0,0,0)",
      "line-style" : "solid",
      "width" : 2.0,
      "color" : "rgb(0,0,0)",
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "text-opacity" : 1.0,
      "line-color" : "rgb(132,132,132)",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "",
      "opacity" : 1.0
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.7.1",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Curved",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "text-valign" : "bottom",
      "text-halign" : "right",
      "width" : 18.0,
      "border-width" : 7.0,
      "height" : 18.0,
      "shape" : "ellipse",
      "background-color" : "rgb(254,196,79)",
      "font-size" : 14,
      "color" : "rgb(102,102,102)",
      "border-color" : "rgb(255,255,255)",
      "text-opacity" : 1.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "border-opacity" : 1.0,
      "background-opacity" : 1.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 10,
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "triangle",
      "target-arrow-color" : "rgb(255,255,255)",
      "line-style" : "solid",
      "width" : 3.0,
      "color" : "rgb(0,0,0)",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "text-opacity" : 1.0,
      "line-color" : "rgb(255,255,255)",
      "source-arrow-color" : "rgb(255,255,255)",
      "content" : "",
      "opacity" : 1.0
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.7.1",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Sample2",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "text-valign" : "center",
      "text-halign" : "right",
      "width" : 50.0,
      "border-width" : 15.0,
      "height" : 50.0,
      "shape" : "ellipse",
      "background-color" : "rgb(58,127,182)",
      "font-size" : 20,
      "color" : "rgb(102,102,102)",
      "border-color" : "rgb(255,255,255)",
      "text-opacity" : 1.0,
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "border-opacity" : 1.0,
      "background-opacity" : 1.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 10,
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "none",
      "target-arrow-color" : "rgb(0,0,0)",
      "line-style" : "solid",
      "width" : 20.0,
      "color" : "rgb(0,0,0)",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "text-opacity" : 1.0,
      "line-color" : "rgb(255,255,255)",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "",
      "opacity" : 1.0
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.7.1",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "NetworkAnalyzer Style: tblladysusandata2.csv_3",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "text-valign" : "center",
      "text-halign" : "center",
      "width" : 30.0,
      "border-width" : 0.0,
      "height" : 30.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,255)",
      "font-size" : 12,
      "color" : "rgb(130,130,130)",
      "border-color" : "rgb(0,0,0)",
      "text-opacity" : 1.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "border-opacity" : 1.0,
      "background-opacity" : 0.7843137254901961,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node[Degree > 23]",
    "css" : {
      "background-color" : "rgb(145,191,219)"
    }
  }, {
    "selector" : "node[Degree = 23]",
    "css" : {
      "background-color" : "rgb(145,191,219)"
    }
  }, {
    "selector" : "node[Degree > 10.5][Degree < 23]",
    "css" : {
      "background-color" : "mapData(Degree,10.5,23,rgb(255,255,191),rgb(145,191,219))"
    }
  }, {
    "selector" : "node[Degree > 1][Degree < 10.5]",
    "css" : {
      "background-color" : "mapData(Degree,1,10.5,rgb(252,141,89),rgb(255,255,191))"
    }
  }, {
    "selector" : "node[Degree = 1]",
    "css" : {
      "background-color" : "rgb(252,141,89)"
    }
  }, {
    "selector" : "node[Degree < 1]",
    "css" : {
      "background-color" : "rgb(252,141,89)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 10,
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "none",
      "target-arrow-color" : "rgb(0,0,0)",
      "line-style" : "solid",
      "width" : 3.0,
      "color" : "rgb(0,0,0)",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "text-opacity" : 1.0,
      "line-color" : "rgb(64,64,64)",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "",
      "opacity" : 0.39215686274509803
    }
  }, {
    "selector" : "edge[EdgeBetweenness > 30]",
    "css" : {
      "width" : 8.0
    }
  }, {
    "selector" : "edge[EdgeBetweenness = 30]",
    "css" : {
      "width" : 8.0
    }
  }, {
    "selector" : "edge[EdgeBetweenness > 16.38095238][EdgeBetweenness < 30]",
    "css" : {
      "width" : "mapData(EdgeBetweenness,16.38095238,30,4.0,8.0)"
    }
  }, {
    "selector" : "edge[EdgeBetweenness > 14][EdgeBetweenness < 16.38095238]",
    "css" : {
      "width" : "mapData(EdgeBetweenness,14,16.38095238,1.0,4.0)"
    }
  }, {
    "selector" : "edge[EdgeBetweenness = 14]",
    "css" : {
      "width" : 1.0
    }
  }, {
    "selector" : "edge[EdgeBetweenness < 14]",
    "css" : {
      "width" : 1.0
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.7.1",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "NetworkAnalyzer Style: lesmis.txt_2",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "text-valign" : "center",
      "text-halign" : "center",
      "width" : 70.0,
      "border-width" : 0.0,
      "height" : 30.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,102,102)",
      "font-size" : 10,
      "color" : "rgb(130,130,130)",
      "border-color" : "rgb(0,0,0)",
      "text-opacity" : 1.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "border-opacity" : 1.0,
      "background-opacity" : 0.7843137254901961,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 10,
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "none",
      "target-arrow-color" : "rgb(0,0,0)",
      "line-style" : "solid",
      "width" : 3.0,
      "color" : "rgb(0,0,0)",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "text-opacity" : 1.0,
      "line-color" : "rgb(64,64,64)",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "",
      "opacity" : 0.39215686274509803
    }
  }, {
    "selector" : "edge[Strength > 31]",
    "css" : {
      "width" : 8.0
    }
  }, {
    "selector" : "edge[Strength = 31]",
    "css" : {
      "width" : 8.0
    }
  }, {
    "selector" : "edge[Strength > 3.22834646][Strength < 31]",
    "css" : {
      "width" : "mapData(Strength,3.22834646,31,4.0,8.0)"
    }
  }, {
    "selector" : "edge[Strength > 1][Strength < 3.22834646]",
    "css" : {
      "width" : "mapData(Strength,1,3.22834646,1.0,4.0)"
    }
  }, {
    "selector" : "edge[Strength = 1]",
    "css" : {
      "width" : 1.0
    }
  }, {
    "selector" : "edge[Strength < 1]",
    "css" : {
      "width" : 1.0
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.7.1",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Directed",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "text-valign" : "center",
      "text-halign" : "center",
      "width" : 45.0,
      "border-width" : 5.0,
      "height" : 45.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,255)",
      "font-size" : 8,
      "color" : "rgb(51,153,255)",
      "border-color" : "rgb(145,145,145)",
      "text-opacity" : 1.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "border-opacity" : 1.0,
      "background-opacity" : 1.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,0,102)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 12,
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "triangle",
      "target-arrow-color" : "rgb(204,204,204)",
      "line-style" : "solid",
      "width" : 5.0,
      "color" : "rgb(51,153,255)",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "text-opacity" : 1.0,
      "line-color" : "rgb(204,204,204)",
      "source-arrow-color" : "rgb(204,204,204)",
      "opacity" : 1.0,
      "content" : "data(interaction)"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.7.1",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Gradient1",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "text-valign" : "bottom",
      "text-halign" : "right",
      "width" : 30.0,
      "border-width" : 0.0,
      "height" : 30.0,
      "shape" : "ellipse",
      "background-color" : "rgb(0,0,0)",
      "font-size" : 8,
      "color" : "rgb(204,204,204)",
      "border-color" : "rgb(0,0,0)",
      "text-opacity" : 1.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "border-opacity" : 1.0,
      "background-opacity" : 1.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 10,
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "none",
      "target-arrow-color" : "rgb(0,0,0)",
      "line-style" : "solid",
      "width" : 1.0,
      "color" : "rgb(0,0,0)",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "text-opacity" : 1.0,
      "line-color" : "rgb(102,102,102)",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "",
      "opacity" : 1.0
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.7.1",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Universe",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "text-valign" : "center",
      "text-halign" : "center",
      "width" : 40.0,
      "border-width" : 0.0,
      "height" : 40.0,
      "shape" : "ellipse",
      "background-color" : "rgb(0,0,0)",
      "font-size" : 18,
      "color" : "rgb(255,255,255)",
      "border-color" : "rgb(0,0,0)",
      "text-opacity" : 1.0,
      "font-family" : "Monospaced.plain",
      "font-weight" : "normal",
      "border-opacity" : 1.0,
      "background-opacity" : 1.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 10,
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "none",
      "target-arrow-color" : "rgb(0,0,0)",
      "line-style" : "dashed",
      "width" : 2.0,
      "color" : "rgb(0,0,0)",
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "text-opacity" : 1.0,
      "line-color" : "rgb(153,153,153)",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "",
      "opacity" : 1.0
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.7.1",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Big Labels",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "text-valign" : "center",
      "text-halign" : "center",
      "width" : 5.0,
      "border-width" : 0.0,
      "height" : 5.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,255)",
      "font-size" : 24,
      "color" : "rgb(51,51,51)",
      "border-color" : "rgb(0,0,0)",
      "text-opacity" : 1.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "border-opacity" : 1.0,
      "background-opacity" : 1.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,0,102)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 10,
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "none",
      "target-arrow-color" : "rgb(0,0,0)",
      "line-style" : "solid",
      "width" : 1.0,
      "color" : "rgb(0,0,0)",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "text-opacity" : 1.0,
      "line-color" : "rgb(183,183,183)",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "",
      "opacity" : 1.0
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.7.1",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "NetworkAnalyzer Style: tblladysusandata2.csv_0",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "text-valign" : "center",
      "text-halign" : "center",
      "width" : 30.0,
      "border-width" : 0.0,
      "height" : 30.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,255)",
      "font-size" : 12,
      "color" : "rgb(130,130,130)",
      "border-color" : "rgb(0,0,0)",
      "text-opacity" : 1.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "border-opacity" : 1.0,
      "background-opacity" : 0.7843137254901961,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 10,
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "none",
      "target-arrow-color" : "rgb(0,0,0)",
      "line-style" : "solid",
      "width" : 3.0,
      "color" : "rgb(0,0,0)",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "text-opacity" : 1.0,
      "line-color" : "rgb(64,64,64)",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "",
      "opacity" : 0.39215686274509803
    }
  }, {
    "selector" : "edge[Letter_No > 42]",
    "css" : {
      "width" : 8.0
    }
  }, {
    "selector" : "edge[Letter_No = 42]",
    "css" : {
      "width" : 8.0
    }
  }, {
    "selector" : "edge[Letter_No > 21.5][Letter_No < 42]",
    "css" : {
      "width" : "mapData(Letter_No,21.5,42,4.0,8.0)"
    }
  }, {
    "selector" : "edge[Letter_No > 1][Letter_No < 21.5]",
    "css" : {
      "width" : "mapData(Letter_No,1,21.5,1.0,4.0)"
    }
  }, {
    "selector" : "edge[Letter_No = 1]",
    "css" : {
      "width" : 1.0
    }
  }, {
    "selector" : "edge[Letter_No < 1]",
    "css" : {
      "width" : 1.0
    }
  }, {
    "selector" : "edge[Letter_No > 42]",
    "css" : {
      "line-color" : "rgb(252,141,89)"
    }
  }, {
    "selector" : "edge[Letter_No = 42]",
    "css" : {
      "line-color" : "rgb(252,141,89)"
    }
  }, {
    "selector" : "edge[Letter_No > 21.5][Letter_No < 42]",
    "css" : {
      "line-color" : "mapData(Letter_No,21.5,42,rgb(255,255,191),rgb(252,141,89))"
    }
  }, {
    "selector" : "edge[Letter_No > 1][Letter_No < 21.5]",
    "css" : {
      "line-color" : "mapData(Letter_No,1,21.5,rgb(145,191,219),rgb(255,255,191))"
    }
  }, {
    "selector" : "edge[Letter_No = 1]",
    "css" : {
      "line-color" : "rgb(145,191,219)"
    }
  }, {
    "selector" : "edge[Letter_No < 1]",
    "css" : {
      "line-color" : "rgb(145,191,219)"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.7.1",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "NetworkAnalyzer Style: tblladysusandata2.csv",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "text-valign" : "center",
      "text-halign" : "center",
      "width" : 30.0,
      "border-width" : 0.0,
      "height" : 30.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,255)",
      "font-size" : 12,
      "color" : "rgb(130,130,130)",
      "border-color" : "rgb(0,0,0)",
      "text-opacity" : 1.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "border-opacity" : 1.0,
      "background-opacity" : 0.7843137254901961,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 10,
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "none",
      "target-arrow-color" : "rgb(0,0,0)",
      "line-style" : "solid",
      "width" : 3.0,
      "color" : "rgb(0,0,0)",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "text-opacity" : 1.0,
      "line-color" : "rgb(64,64,64)",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "",
      "opacity" : 0.39215686274509803
    }
  }, {
    "selector" : "edge[Letter_No > 42]",
    "css" : {
      "line-color" : "rgb(145,191,219)"
    }
  }, {
    "selector" : "edge[Letter_No = 42]",
    "css" : {
      "line-color" : "rgb(145,191,219)"
    }
  }, {
    "selector" : "edge[Letter_No > 21.5][Letter_No < 42]",
    "css" : {
      "line-color" : "mapData(Letter_No,21.5,42,rgb(255,255,191),rgb(145,191,219))"
    }
  }, {
    "selector" : "edge[Letter_No > 1][Letter_No < 21.5]",
    "css" : {
      "line-color" : "mapData(Letter_No,1,21.5,rgb(252,141,89),rgb(255,255,191))"
    }
  }, {
    "selector" : "edge[Letter_No = 1]",
    "css" : {
      "line-color" : "rgb(252,141,89)"
    }
  }, {
    "selector" : "edge[Letter_No < 1]",
    "css" : {
      "line-color" : "rgb(252,141,89)"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.7.1",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Nested Network Style",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "text-valign" : "center",
      "text-halign" : "center",
      "width" : 60.0,
      "border-width" : 2.0,
      "height" : 40.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,255)",
      "font-size" : 12,
      "color" : "rgb(0,0,0)",
      "border-color" : "rgb(0,0,0)",
      "text-opacity" : 1.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "border-opacity" : 1.0,
      "background-opacity" : 1.0,
      "content" : "data(shared_name)"
    }
  }, {
    "selector" : "node[has_nested_network]",
    "css" : {
      "text-valign" : "bottom"
    }
  }, {
    "selector" : "node[has_nested_network]",
    "css" : {
      "color" : "rgb(0,102,204)"
    }
  }, {
    "selector" : "node[has_nested_network]",
    "css" : {
      "shape" : "rectangle"
    }
  }, {
    "selector" : "node[has_nested_network]",
    "css" : {
      "background-color" : "rgb(255,255,255)"
    }
  }, {
    "selector" : "node[has_nested_network]",
    "css" : {
      "border-color" : "rgb(0,102,204)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 10,
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "none",
      "target-arrow-color" : "rgb(0,0,0)",
      "line-style" : "solid",
      "width" : 1.0,
      "color" : "rgb(0,0,0)",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "text-opacity" : 1.0,
      "line-color" : "rgb(64,64,64)",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "",
      "opacity" : 1.0
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
} ]