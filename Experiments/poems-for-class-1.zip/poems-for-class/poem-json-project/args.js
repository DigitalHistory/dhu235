#!/usr/bin/env node

// process.argv.forEach((index,val) => {
//   console.log(index,val);
// })
// const optionDefinitions = [
//   { name: 'verbose', alias: 'v', type: Boolean },
//   { name: 'src', type: String, multiple: true, defaultOption: true },
//   { name: 'timeout', alias: 't', type: Number }
// ]
// const commandLineArgs = require('command-line-args')
// const options = commandLineArgs(optionDefinitions)

// console.log(options);
const {argv} = require('yargs');
console.log(argv);
