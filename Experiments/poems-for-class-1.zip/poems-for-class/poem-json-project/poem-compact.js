let poem={
  "stanzas": [
    [],
    [],
    [
      [
        {"type": "word", "content": "Adieu"},
        {"type": "punctuation", "content": ","},
        {"type": "word", "content": "farewell"},
        {"type": "punctuation", "content": ","},
        {"type": "word", "content": "earth's"},
        {"type": "word", "content": "bliss;"}
      ],
      [
        {"type": "word", "content": "This"},
        {"type": "word", "content": "world"},
        {"type": "word", "content": "uncertain"},
        {"type": "word", "content": "is;"}
      ],
      [
        {"type": "word", "content": "Fond"},
        {"type": "word", "content": "are"},
        {"type": "word", "content": "life's"},
        {"type": "word", "content": "lustful"},
        {"type": "word", "content": "joys;"}
      ],
      [
        {"type": "word", "content": "Death"},
        {"type": "word", "content": "proves"},
        {"type": "word", "content": "them"},
        {"type": "word", "content": "all"},
        {"type": "word", "content": "but"},
        {"type": "word", "content": "toys;"}
      ],
      [
        {"type": "word", "content": "None"},
        {"type": "word", "content": "from"},
        {"type": "word", "content": "his"},
        {"type": "word", "content": "darts"},
        {"type": "word", "content": "can"},
        {"type": "word", "content": "fly;"}
      ],
      [
        {"type": "word", "content": "I"},
        {"type": "word", "content": "am"},
        {"type": "word", "content": "sick"},
        {"type": "punctuation", "content": ","},
        {"type": "word", "content": "I"},
        {"type": "word", "content": "must"},
        {"type": "word", "content": "die"},
        {"type": "punctuation", "content": "."}
      ],
      [
        {"type": "indent", "content": "    "},
        {type: "prayer", "content": [
        {"type": "word", "content": "Lord"},
        {"type": "punctuation", "content": ","},
        {"type": "word", "content": "have"},
        {"type": "word", "content": "mercy"},
        {"type": "word", "content": "on"},
        {"type": "word", "content": "us!"}
        ]
        }]
    ],
    [
      [
        {"type": "word", "content": "Rich"},
        {"type": "word", "content": "men"},
        {"type": "punctuation", "content": ","},
        {"type": "word", "content": "trust"},
        {"type": "word", "content": "not"},
        {"type": "word", "content": "in"},
        {"type": "word", "content": "wealth"},
        {"type": "punctuation", "content": ","}
      ],
      [
        {"type": "word", "content": "Gold"},
        {"type": "word", "content": "cannot"},
        {"type": "word", "content": "buy"},
        {"type": "word", "content": "you"},
        {"type": "word", "content": "health;"}
      ],
      [
        {"type": "word", "content": "Physic"},
        {"type": "word", "content": "himself"},
        {"type": "word", "content": "must"},
        {"type": "word", "content": "fade"},
        {"type": "punctuation", "content": "."}
      ],
      [
        {"type": "word", "content": "All"},
        {"type": "word", "content": "things"},
        {"type": "word", "content": "to"},
        {"type": "word", "content": "end"},
        {"type": "word", "content": "are"},
        {"type": "word", "content": "made"},
        {"type": "punctuation", "content": ","}
      ],
      [
        {"type": "word", "content": "The"},
        {"type": "word", "content": "plague"},
        {"type": "word", "content": "full"},
        {"type": "word", "content": "swift"},
        {"type": "word", "content": "goes"},
        {"type": "word", "content": "by;"}
      ],
      [
        {"type": "word", "content": "I"},
        {"type": "word", "content": "am"},
        {"type": "word", "content": "sick"},
        {"type": "punctuation", "content": ","},
        {"type": "word", "content": "I"},
        {"type": "word", "content": "must"},
        {"type": "word", "content": "die"},
        {"type": "punctuation", "content": "."}
      ],
      [
        {"type": "indent", "content": "    "},
        {"type": "word", "content": "Lord"},
        {"type": "punctuation", "content": ","},
        {"type": "word", "content": "have"},
        {"type": "word", "content": "mercy"},
        {"type": "word", "content": "on"},
        {"type": "word", "content": "us!"}
      ]
    ],
    [
      [
        {"type": "word", "content": "Beauty"},
        {"type": "word", "content": "is"},
        {"type": "word", "content": "but"},
        {"type": "word", "content": "a"},
        {"type": "word", "content": "flower"}
      ],
      [
        {"type": "word", "content": "Which"},
        {"type": "word", "content": "wrinkles"},
        {"type": "word", "content": "will"},
        {"type": "word", "content": "devour;"}
      ],
      [
        {"type": "word", "content": "Brightness"},
        {"type": "word", "content": "falls"},
        {"type": "word", "content": "from"},
        {"type": "word", "content": "the"},
        {"type": "word", "content": "air;"}
      ],
      [
        {"type": "word", "content": "Queens"},
        {"type": "word", "content": "have"},
        {"type": "word", "content": "died"},
        {"type": "word", "content": "young"},
        {"type": "word", "content": "and"},
        {"type": "word", "content": "fair;"}
      ],
      [
        {"type": "word", "content": "Dust"},
        {"type": "word", "content": "hath"},
        {"type": "word", "content": "closed"},
        {"type": "word", "content": "Helen's"},
        {"type": "word", "content": "eye"},
        {"type": "punctuation", "content": "."}
      ],
      [
        {"type": "word", "content": "I"},
        {"type": "word", "content": "am"},
        {"type": "word", "content": "sick"},
        {"type": "punctuation", "content": ","},
        {"type": "word", "content": "I"},
        {"type": "word", "content": "must"},
        {"type": "word", "content": "die"},
        {"type": "punctuation", "content": "."}
      ],
      [
        {"type": "indent", "content": "    "},
        {"type": "word", "content": "Lord"},
        {"type": "punctuation", "content": ","},
        {"type": "word", "content": "have"},
        {"type": "word", "content": "mercy"},
        {"type": "word", "content": "on"},
        {"type": "word", "content": "us!"}
      ]
    ],
    [
      [
        {"type": "word", "content": "Strength"},
        {"type": "word", "content": "stoops"},
        {"type": "word", "content": "unto"},
        {"type": "word", "content": "the"},
        {"type": "word", "content": "grave"},
        {"type": "punctuation", "content": ","}
      ],
      [
        {"type": "word", "content": "Worms"},
        {"type": "word", "content": "feed"},
        {"type": "word", "content": "on"},
        {"type": "word", "content": "Hector"},
        {"type": "word", "content": "brave;"}
      ],
      [
        {"type": "word", "content": "Swords"},
        {"type": "word", "content": "may"},
        {"type": "word", "content": "not"},
        {"type": "word", "content": "fight"},
        {"type": "word", "content": "with"},
        {"type": "word", "content": "fate"},
        {"type": "punctuation", "content": ","}
      ],
      [
        {"type": "word", "content": "Earth"},
        {"type": "word", "content": "still"},
        {"type": "word", "content": "holds"},
        {"type": "word", "content": "open"},
        {"type": "word", "content": "her"},
        {"type": "word", "content": "gate"},
        {"type": "punctuation", "content": "."}
      ],
      [
        {"type": "word", "content": "\"Come"},
        {"type": "punctuation", "content": ","},
        {"type": "word", "content": "come!\""},
        {"type": "word", "content": "the"},
        {"type": "word", "content": "bells"},
        {"type": "word", "content": "do"},
        {"type": "word", "content": "cry"},
        {"type": "punctuation", "content": "."}
      ],
      [
        {"type": "word", "content": "I"},
        {"type": "word", "content": "am"},
        {"type": "word", "content": "sick"},
        {"type": "punctuation", "content": ","},
        {"type": "word", "content": "I"},
        {"type": "word", "content": "must"},
        {"type": "word", "content": "die"},
        {"type": "punctuation", "content": "."}
      ],
      [
        {"type": "indent", "content": "    "},
        {"type": "word", "content": "Lord"},
        {"type": "punctuation", "content": ","},
        {"type": "word", "content": "have"},
        {"type": "word", "content": "mercy"},
        {"type": "word", "content": "on"},
        {"type": "word", "content": "us!"}
      ]
    ],
    [],
    [
      [
        {"type": "word", "content": "Haste"},
        {"type": "punctuation", "content": ","},
        {"type": "word", "content": "therefore"},
        {"type": "punctuation", "content": ","},
        {"type": "word", "content": "each"},
        {"type": "word", "content": "degree"},
        {"type": "punctuation", "content": ","}
      ],
      [
        {"type": "word", "content": "To"},
        {"type": "word", "content": "welcome"},
        {"type": "word", "content": "destiny;"}
      ],
      [
        {"type": "word", "content": "Heaven"},
        {"type": "word", "content": "is"},
        {"type": "word", "content": "our"},
        {"type": "word", "content": "heritage"},
        {"type": "punctuation", "content": ","}
      ],
      [
        {"type": "word", "content": "Earth"},
        {"type": "word", "content": "but"},
        {"type": "word", "content": "a"},
        {"type": "word", "content": "player's"},
        {"type": "word", "content": "stage;"}
      ],
      [
        {"type": "word", "content": "Mount"},
        {"type": "word", "content": "we"},
        {"type": "word", "content": "unto"},
        {"type": "word", "content": "the"},
        {"type": "word", "content": "sky"},
        {"type": "punctuation", "content": "."}
      ],
      [
        {"type": "word", "content": "I"},
        {"type": "word", "content": "am"},
        {"type": "word", "content": "sick"},
        {"type": "punctuation", "content": ","},
        {"type": "word", "content": "I"},
        {"type": "word", "content": "must"},
        {"type": "word", "content": "die"},
        {"type": "punctuation", "content": "."}
      ],
      [
        {"type": "indent", "content": "    "},
        {"type": "word", "content": "Lord"},
        {"type": "punctuation", "content": ","},
        {"type": "word", "content": "have"},
        {"type": "word", "content": "mercy"},
        {"type": "word", "content": "on"},
        {"type": "word", "content": "us!"}
      ]
    ],
    []
  ]
}
